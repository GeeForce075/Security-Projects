"""
Nessus Professional / Tenable.io Scanner Connector
Fetches vulnerability scan results via the Nessus REST API.
Supports: Nessus Professional (on-prem), Tenable.io (cloud), Tenable.sc
"""

import asyncio
import logging
from typing import Optional

import aiohttp

logger = logging.getLogger("vuln.scanners.nessus")


class NessusScanner:
    """
    Async Nessus connector.
    Handles: scan listing, per-scan export, host/vulnerability details.
    """
    source_name = "nessus"

    def __init__(self, config: dict):
        self.base_url     = config["base_url"].rstrip("/")   # e.g. https://nessus.company.com:8834
        self.access_key   = config["access_key"]
        self.secret_key   = config["secret_key"]
        self.verify_ssl   = config.get("verify_ssl", True)
        self.scan_ids     = config.get("scan_ids", [])       # [] = all scans
        self.min_severity = config.get("min_severity", 1)    # 0=info 1=low 2=med 3=high 4=crit
        self.max_age_days = config.get("max_age_days", 30)

        self._headers = {
            "X-ApiKeys": f"accessKey={self.access_key}; secretKey={self.secret_key}",
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def fetch_findings(self) -> list[dict]:
        """Fetch all vulnerability findings from Nessus."""
        scans    = await self._list_scans()
        if self.scan_ids:
            scans = [s for s in scans if str(s.get("id")) in [str(x) for x in self.scan_ids]]

        logger.info("Nessus: processing %d scans", len(scans))

        findings  = []
        for scan in scans:
            scan_id  = scan["id"]
            scan_vulns = await self._fetch_scan_findings(scan_id)
            findings.extend(scan_vulns)

        logger.info("Nessus: retrieved %d total findings", len(findings))
        return findings

    # ------------------------------------------------------------------
    # API methods
    # ------------------------------------------------------------------

    async def _list_scans(self) -> list[dict]:
        data = await self._get("/scans")
        scans = data.get("scans", []) or []

        from datetime import datetime, timedelta, timezone
        cutoff   = datetime.now(timezone.utc) - timedelta(days=self.max_age_days)
        filtered = []
        for scan in scans:
            last_mod = scan.get("last_modification_date", 0)
            scan_dt  = datetime.fromtimestamp(last_mod, tz=timezone.utc)
            if scan_dt >= cutoff and scan.get("status") in ("completed", "running"):
                filtered.append(scan)
        return filtered

    async def _fetch_scan_findings(self, scan_id: int) -> list[dict]:
        """Export scan details and extract per-host vulnerabilities."""
        try:
            # Trigger export
            export_resp = await self._post(f"/scans/{scan_id}/export", {"format": "nessus"})
            file_id     = export_resp.get("file")
            if not file_id:
                # Fall back to in-memory JSON detail if no file export
                detail = await self._get(f"/scans/{scan_id}")
                return self._parse_scan_detail(scan_id, detail)

            # Wait for export to be ready
            await self._wait_for_export(scan_id, file_id)

            # Download and parse
            raw   = await self._download_export(scan_id, file_id)
            return self._parse_nessus_xml(raw, scan_id)

        except Exception as exc:
            logger.error("Nessus: failed to fetch scan %s: %s", scan_id, exc)
            return []

    def _parse_scan_detail(self, scan_id: int, detail: dict) -> list[dict]:
        """Parse in-memory JSON scan detail (simpler but less complete than XML export)."""
        hosts    = detail.get("hosts", [])
        vulns    = detail.get("vulnerabilities", [])
        findings = []

        for host in hosts:
            host_id   = host.get("host_id")
            hostname  = host.get("hostname", host.get("host-ip", ""))
            host_info = host.get("info", {})

            for vuln in vulns:
                if vuln.get("severity", 0) < self.min_severity:
                    continue
                sev_map = {0: "informational", 1: "low", 2: "medium", 3: "high", 4: "critical"}
                findings.append({
                    "_nessus_scan_id":    scan_id,
                    "_nessus_host_id":    host_id,
                    "plugin_id":          vuln.get("plugin_id", ""),
                    "plugin_name":        vuln.get("plugin_name", ""),
                    "severity":           sev_map.get(vuln.get("severity", 0), "informational"),
                    "severity_int":       vuln.get("severity", 0),
                    "affected_host":      hostname,
                    "count":              vuln.get("count", 1),
                    "family":             vuln.get("plugin_family", ""),
                })
        return findings

    def _parse_nessus_xml(self, xml_bytes: bytes, scan_id: int) -> list[dict]:
        """Parse full .nessus XML export for detailed CVE / CVSS data."""
        import xml.etree.ElementTree as ET
        findings = []

        try:
            root = ET.fromstring(xml_bytes)
            for report in root.iter("Report"):
                for host_elem in report.iter("ReportHost"):
                    hostname = host_elem.get("name", "")
                    host_props = {
                        p.get("name"): p.text
                        for p in host_elem.iter("HostProperties") and host_elem.findall("HostProperties/tag")
                    }
                    os_name  = host_props.get("operating-system", "")

                    for item in host_elem.iter("ReportItem"):
                        sev_int = int(item.get("severity", 0))
                        if sev_int < self.min_severity:
                            continue

                        cve_ids   = [c.text for c in item.findall("cve") if c.text]
                        cvss3     = item.findtext("cvss3_base_score", "0") or "0"
                        cvss2     = item.findtext("cvss_base_score", "0") or "0"
                        solution  = item.findtext("solution", "")
                        synopsis  = item.findtext("synopsis", "")
                        desc      = item.findtext("description", "")
                        patch_pub = item.findtext("patch_publication_date", "")

                        sev_map   = {0: "informational", 1: "low", 2: "medium", 3: "high", 4: "critical"}

                        findings.append({
                            "_nessus_scan_id":  scan_id,
                            "plugin_id":        item.get("pluginID", ""),
                            "plugin_name":      item.get("pluginName", ""),
                            "severity":         sev_map.get(sev_int, "informational"),
                            "severity_int":     sev_int,
                            "affected_host":    hostname,
                            "affected_port":    int(item.get("port", 0)),
                            "affected_service": item.get("svc_name", ""),
                            "protocol":         item.get("protocol", ""),
                            "cve_ids":          cve_ids,
                            "cvss_v3":          float(cvss3),
                            "cvss_v2":          float(cvss2),
                            "title":            synopsis or item.get("pluginName", ""),
                            "description":      desc,
                            "solution":         solution,
                            "patch_pub_date":   patch_pub,
                            "os":               os_name,
                            "family":           item.get("pluginFamily", ""),
                        })
        except ET.ParseError as exc:
            logger.error("Nessus XML parse error: %s", exc)

        return findings

    async def _wait_for_export(self, scan_id: int, file_id: int, max_wait: int = 120):
        for _ in range(max_wait // 5):
            status = await self._get(f"/scans/{scan_id}/export/{file_id}/status")
            if status.get("status") == "ready":
                return
            await asyncio.sleep(5)
        raise TimeoutError(f"Nessus export {file_id} timed out after {max_wait}s")

    async def _download_export(self, scan_id: int, file_id: int) -> bytes:
        connector = aiohttp.TCPConnector(ssl=self.verify_ssl)
        async with aiohttp.ClientSession(connector=connector) as sess:
            async with sess.get(
                f"{self.base_url}/scans/{scan_id}/export/{file_id}/download",
                headers=self._headers,
                timeout=aiohttp.ClientTimeout(total=120),
            ) as resp:
                resp.raise_for_status()
                return await resp.read()

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    async def _get(self, path: str) -> dict:
        connector = aiohttp.TCPConnector(ssl=self.verify_ssl)
        async with aiohttp.ClientSession(connector=connector) as sess:
            async with sess.get(
                f"{self.base_url}{path}",
                headers=self._headers,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def _post(self, path: str, payload: dict) -> dict:
        connector = aiohttp.TCPConnector(ssl=self.verify_ssl)
        async with aiohttp.ClientSession(connector=connector) as sess:
            async with sess.post(
                f"{self.base_url}{path}",
                headers=self._headers,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                resp.raise_for_status()
                return await resp.json()
