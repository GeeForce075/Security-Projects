"""
Unified Vulnerability Management Aggregator
Pulls scan results from Nessus, OpenVAS, Qualys, Rapid7 InsightVM, and Prowler,
normalises findings to a common schema, de-duplicates across scanners,
correlates with your asset inventory, and produces prioritised remediation plans.

Outputs:
  - JSON vulnerability feed (for Sentinel / Splunk ingestion)
  - CSV remediation plan sorted by CVSS × asset_criticality
  - HTML / PDF executive report
"""

import asyncio
import logging
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from scanners.nessus    import NessusScanner
from scanners.openvas   import OpenVASScanner
from scanners.qualys    import QualysScanner
from scanners.rapid7    import Rapid7Scanner
from scanners.prowler   import ProwlerScanner
from normalizer.vuln_normalizer import VulnNormalizer
from reporting.report_generator import ReportGenerator

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger("vuln.aggregator")


class VulnSeverity(str, Enum):
    CRITICAL = "critical"
    HIGH     = "high"
    MEDIUM   = "medium"
    LOW      = "low"
    INFO     = "informational"


@dataclass
class NormalizedVuln:
    vuln_id:          str
    source_scanner:   str
    cve_ids:          list[str]       = field(default_factory=list)
    cvss_v3:          float           = 0.0
    cvss_v2:          float           = 0.0
    severity:         str             = VulnSeverity.INFO
    title:            str             = ""
    description:      str             = ""
    solution:         str             = ""
    affected_host:    str             = ""
    affected_port:    int             = 0
    affected_service: str             = ""
    plugin_id:        str             = ""
    published_date:   str             = ""
    patch_available:  bool            = False
    epss_score:       float           = 0.0     # Exploit Prediction Scoring System
    exploit_public:   bool            = False
    asset_criticality:int             = 3        # 1(low)–5(critical)
    priority_score:   float           = 0.0     # computed: cvss × asset_crit × epss
    scan_timestamp:   str             = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    fingerprint:      str             = ""       # for deduplication
    tags:             list[str]       = field(default_factory=list)


class VulnAggregator:
    """
    Orchestrates all vulnerability scanners, normalises and deduplicates findings,
    scores and prioritises, and outputs to multiple destinations.
    """

    def __init__(self, config: dict):
        self.config    = config
        self.normalizer = VulnNormalizer()
        self.reporter   = ReportGenerator(config.get("reporting", {}))
        self.scanners   = self._init_scanners()
        self._seen_fingerprints: set[str] = set()

    def _init_scanners(self) -> list:
        scanners = []
        cfg      = self.config.get("scanners", {})

        if cfg.get("nessus", {}).get("enabled"):
            scanners.append(NessusScanner(cfg["nessus"]))
            logger.info("Scanner enabled: Nessus")

        if cfg.get("openvas", {}).get("enabled"):
            scanners.append(OpenVASScanner(cfg["openvas"]))
            logger.info("Scanner enabled: OpenVAS")

        if cfg.get("qualys", {}).get("enabled"):
            scanners.append(QualysScanner(cfg["qualys"]))
            logger.info("Scanner enabled: Qualys")

        if cfg.get("rapid7", {}).get("enabled"):
            scanners.append(Rapid7Scanner(cfg["rapid7"]))
            logger.info("Scanner enabled: Rapid7 InsightVM")

        if cfg.get("prowler", {}).get("enabled"):
            scanners.append(ProwlerScanner(cfg["prowler"]))
            logger.info("Scanner enabled: Prowler (Cloud Security)")

        return scanners

    # ------------------------------------------------------------------
    # Main aggregation run
    # ------------------------------------------------------------------

    async def run(self) -> list[NormalizedVuln]:
        """Pull from all scanners, normalise, deduplicate, score, and report."""
        logger.info("Starting vulnerability aggregation run — %d scanners", len(self.scanners))

        tasks   = [scanner.fetch_findings() for scanner in self.scanners]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        all_vulns: list[NormalizedVuln] = []
        for scanner, result in zip(self.scanners, results):
            if isinstance(result, Exception):
                logger.error("Scanner %s failed: %s", type(scanner).__name__, result)
                continue
            for raw in result:
                try:
                    vuln = self.normalizer.normalize(scanner.source_name, raw)
                    if not self._is_duplicate(vuln):
                        all_vulns.append(vuln)
                except Exception as exc:
                    logger.warning("Normalisation error: %s", exc)

        logger.info("Collected %d unique findings across all scanners", len(all_vulns))

        # Enrich with EPSS scores
        all_vulns = await self._enrich_epss(all_vulns)

        # Compute priority scores and sort
        all_vulns = self._score_and_sort(all_vulns)

        # Output
        await self._write_outputs(all_vulns)

        return all_vulns

    # ------------------------------------------------------------------
    # Deduplication
    # ------------------------------------------------------------------

    def _make_fingerprint(self, vuln: NormalizedVuln) -> str:
        """Fingerprint = CVE + host + port (scanner-agnostic)."""
        import hashlib
        parts = sorted(vuln.cve_ids) + [vuln.affected_host, str(vuln.affected_port), vuln.title[:50]]
        return hashlib.sha256("|".join(parts).lower().encode()).hexdigest()[:16]

    def _is_duplicate(self, vuln: NormalizedVuln) -> bool:
        fp = self._make_fingerprint(vuln)
        if fp in self._seen_fingerprints:
            return True
        self._seen_fingerprints.add(fp)
        vuln.fingerprint = fp
        return False

    # ------------------------------------------------------------------
    # EPSS enrichment (Exploit Prediction Scoring System)
    # ------------------------------------------------------------------

    async def _enrich_epss(self, vulns: list[NormalizedVuln]) -> list[NormalizedVuln]:
        """
        Fetch EPSS scores from FIRST.org API for all CVEs.
        EPSS probability indicates likelihood of exploitation in the wild.
        """
        import aiohttp

        cve_ids = list({cve for v in vulns for cve in v.cve_ids})
        if not cve_ids:
            return vulns

        epss_map: dict[str, float] = {}
        exploit_map: dict[str, bool] = {}

        # Batch CVEs in chunks of 100 (API limit)
        chunk_size = 100
        for i in range(0, len(cve_ids), chunk_size):
            chunk = cve_ids[i:i + chunk_size]
            params_str = "&".join(f"cve={c}" for c in chunk)
            url = f"https://api.first.org/data/1.0/epss?{params_str}"
            try:
                async with aiohttp.ClientSession() as sess:
                    async with sess.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            for item in data.get("data", []):
                                cve_id         = item.get("cve", "")
                                epss_map[cve_id]    = float(item.get("epss", 0))
                                exploit_map[cve_id] = float(item.get("epss", 0)) > 0.5
            except Exception as exc:
                logger.warning("EPSS API error: %s", exc)

        for vuln in vulns:
            for cve in vuln.cve_ids:
                if cve in epss_map:
                    vuln.epss_score    = max(vuln.epss_score, epss_map[cve])
                    vuln.exploit_public = vuln.exploit_public or exploit_map.get(cve, False)

        logger.info("EPSS enriched %d CVEs", len(epss_map))
        return vulns

    # ------------------------------------------------------------------
    # Prioritisation scoring
    # ------------------------------------------------------------------

    def _score_and_sort(self, vulns: list[NormalizedVuln]) -> list[NormalizedVuln]:
        """
        Priority score = CVSS_v3 × (asset_criticality / 5) × (1 + epss_score) × exploit_multiplier
        Range: ~0.0 – 20.0
        """
        for vuln in vulns:
            cvss            = vuln.cvss_v3 if vuln.cvss_v3 > 0 else vuln.cvss_v2
            asset_factor    = vuln.asset_criticality / 5.0
            epss_factor     = 1.0 + vuln.epss_score
            exploit_mult    = 1.5 if vuln.exploit_public else 1.0

            vuln.priority_score = round(cvss * asset_factor * epss_factor * exploit_mult, 3)

        vulns.sort(key=lambda v: v.priority_score, reverse=True)
        logger.info("Top vulnerability: %s (score=%.2f)", vulns[0].title if vulns else "N/A",
                    vulns[0].priority_score if vulns else 0)
        return vulns

    # ------------------------------------------------------------------
    # Output writing
    # ------------------------------------------------------------------

    async def _write_outputs(self, vulns: list[NormalizedVuln]):
        """Write JSON feed, CSV remediation plan, and summary report."""
        output_dir = self.config.get("output_dir", "output")
        import os; os.makedirs(output_dir, exist_ok=True)

        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

        # JSON feed
        json_path = f"{output_dir}/vulns_{ts}.json"
        with open(json_path, "w") as f:
            json.dump([asdict(v) for v in vulns], f, indent=2, default=str)
        logger.info("JSON feed written: %s (%d findings)", json_path, len(vulns))

        # CSV remediation plan
        await self._write_csv(vulns, f"{output_dir}/remediation_{ts}.csv")

        # Report
        await self.reporter.generate(vulns, f"{output_dir}/report_{ts}.html")

    async def _write_csv(self, vulns: list[NormalizedVuln], path: str):
        import csv
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=[
                "priority_score", "severity", "cvss_v3", "epss_score",
                "exploit_public", "cve_ids", "title", "affected_host",
                "affected_port", "affected_service", "solution",
                "source_scanner", "asset_criticality", "scan_timestamp"
            ])
            writer.writeheader()
            for v in vulns:
                row = asdict(v)
                row["cve_ids"] = ", ".join(v.cve_ids)
                writer.writerow({k: row.get(k, "") for k in writer.fieldnames})
        logger.info("CSV remediation plan written: %s", path)


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------

def load_config(path: str = "config/aggregator.yaml") -> dict:
    import yaml
    with open(path) as f:
        return yaml.safe_load(f)


if __name__ == "__main__":
    import asyncio
    cfg   = load_config()
    agg   = VulnAggregator(cfg)
    vulns = asyncio.run(agg.run())
    print(f"\n{'='*60}")
    print(f"Aggregation complete. {len(vulns)} unique findings.")
    print(f"Top 5 by priority:")
    for i, v in enumerate(vulns[:5], 1):
        print(f"  {i}. [{v.severity.upper()}] {v.title} | Host={v.affected_host} | Score={v.priority_score}")
