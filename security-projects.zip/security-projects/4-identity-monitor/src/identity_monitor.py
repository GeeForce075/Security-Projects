"""
Identity Threat Detection & Response System
Monitors Azure Active Directory (Entra ID), on-prem Active Directory,
Okta, Ping Identity, and Keycloak for identity-based attacks:
  - Account takeover (ATO) via credential stuffing / brute force
  - Impossible travel (geographic anomaly)
  - Suspicious OAuth app grants
  - Privilege escalation
  - Service account abuse
  - Token theft / session hijacking
  - Legacy protocol abuse (NTLM, Basic Auth)
  - MFA fatigue / push bombing

Integrates with:
  - Microsoft Defender for Identity
  - CrowdStrike Identity Protection
  - Microsoft Sentinel (risk signal forwarding)
  - Azure AD Identity Protection (Risk API)
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional
import uuid

from providers.azure_ad   import AzureADProvider
from providers.okta        import OktaProvider
from providers.ad_onprem   import OnPremADProvider
from providers.keycloak    import KeycloakProvider
from detectors.travel       import ImpossibleTravelDetector
from detectors.mfa_fatigue  import MFAFatigueDetector
from detectors.privilege    import PrivilegeEscalationDetector
from detectors.token_theft  import TokenTheftDetector
from alerts.identity_alert  import IdentityAlertEmitter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger("identity.monitor")


@dataclass
class IdentityThreatSignal:
    signal_id:       str   = field(default_factory=lambda: str(uuid.uuid4()))
    signal_type:     str   = ""
    user_id:         str   = ""
    user_upn:        str   = ""
    source_ip:       str   = ""
    source_country:  str   = ""
    source_platform: str   = ""
    confidence:      float = 0.0
    severity:        str   = "medium"
    description:     str   = ""
    mitre_tactic:    str   = ""
    mitre_technique: str   = ""
    raw_events:      list  = field(default_factory=list)
    recommended_actions: list[str] = field(default_factory=list)
    timestamp:       str   = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    auto_remediated: bool  = False


class IdentityThreatMonitor:
    """
    Cross-platform identity threat monitor.
    Correlates sign-in logs, audit events, and risk signals
    across all IdP platforms to detect identity-based attacks.
    """

    # MITRE ATT&CK identity technique mapping
    MITRE_MAP = {
        "impossible_travel":        ("TA0001", "T1078"),  # Initial Access / Valid Accounts
        "mfa_fatigue":              ("TA0006", "T1621"),  # Credential Access / MFA Request Gen.
        "brute_force":              ("TA0006", "T1110"),  # Credential Access / Brute Force
        "credential_stuffing":      ("TA0006", "T1110.004"),
        "privilege_escalation":     ("TA0004", "T1078.004"),
        "token_theft":              ("TA0006", "T1528"),  # Credential Access / Steal App Access Token
        "session_hijacking":        ("TA0006", "T1539"),
        "legacy_protocol_abuse":    ("TA0001", "T1078.002"),
        "suspicious_oauth":         ("TA0001", "T1550.001"),
        "service_account_abuse":    ("TA0004", "T1078.003"),
        "new_device_access":        ("TA0001", "T1078"),
        "admin_consent_grant":      ("TA0003", "T1098"),  # Persistence / Account Manipulation
    }

    def __init__(self, config: dict):
        self.config   = config
        self.emitter  = IdentityAlertEmitter(config.get("alerts", {}))
        self.providers = self._init_providers()
        self.detectors = self._init_detectors()
        self._user_sessions: dict[str, list] = {}  # user_id → recent sign-ins

    def _init_providers(self) -> dict:
        providers = {}
        cfg       = self.config.get("providers", {})

        if cfg.get("azure_ad", {}).get("enabled"):
            providers["azure_ad"] = AzureADProvider(cfg["azure_ad"])
            logger.info("Provider enabled: Azure AD (Entra ID)")

        if cfg.get("ad_onprem", {}).get("enabled"):
            providers["ad_onprem"] = OnPremADProvider(cfg["ad_onprem"])
            logger.info("Provider enabled: Active Directory (On-Prem)")

        if cfg.get("okta", {}).get("enabled"):
            providers["okta"] = OktaProvider(cfg["okta"])
            logger.info("Provider enabled: Okta")

        if cfg.get("keycloak", {}).get("enabled"):
            providers["keycloak"] = KeycloakProvider(cfg["keycloak"])
            logger.info("Provider enabled: Keycloak")

        return providers

    def _init_detectors(self) -> dict:
        return {
            "impossible_travel":    ImpossibleTravelDetector(self.config.get("travel", {})),
            "mfa_fatigue":          MFAFatigueDetector(self.config.get("mfa", {})),
            "privilege_escalation": PrivilegeEscalationDetector(self.config.get("privilege", {})),
            "token_theft":          TokenTheftDetector(self.config.get("token", {})),
        }

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    async def run(self):
        logger.info("Identity Threat Monitor starting — %d providers, %d detectors",
                    len(self.providers), len(self.detectors))
        poll_interval = self.config.get("poll_interval_seconds", 60)

        while True:
            tasks = [self._poll_provider(name, provider)
                     for name, provider in self.providers.items()]
            await asyncio.gather(*tasks, return_exceptions=True)
            await asyncio.sleep(poll_interval)

    async def _poll_provider(self, provider_name: str, provider):
        try:
            events = await provider.fetch_signin_logs()
            logger.info("%s: fetched %d sign-in events", provider_name, len(events))

            for event in events:
                normalized = self._normalize_event(provider_name, event)
                await self._process_event(normalized)

        except Exception as exc:
            logger.error("Provider %s polling error: %s", provider_name, exc)

    # ------------------------------------------------------------------
    # Event processing pipeline
    # ------------------------------------------------------------------

    async def _process_event(self, event: dict):
        user_id = event.get("user_id", "")
        if not user_id:
            return

        # Maintain per-user session history (last 200 events)
        if user_id not in self._user_sessions:
            self._user_sessions[user_id] = []
        history = self._user_sessions[user_id]
        history.append(event)
        if len(history) > 200:
            self._user_sessions[user_id] = history[-200:]

        # Run all detectors
        detection_tasks = [
            self._run_detector(name, detector, event, history)
            for name, detector in self.detectors.items()
        ]
        await asyncio.gather(*detection_tasks, return_exceptions=True)

        # Rule-based detections that don't need ML
        await self._rule_based_detections(event, history)

    async def _run_detector(self, name: str, detector, event: dict, history: list):
        try:
            signal = detector.detect(event, history)
            if signal and signal.get("confidence", 0) > 0.5:
                await self._emit_signal(name, event, signal)
        except Exception as exc:
            logger.debug("Detector %s error: %s", name, exc)

    # ------------------------------------------------------------------
    # Rule-based detections
    # ------------------------------------------------------------------

    async def _rule_based_detections(self, event: dict, history: list):
        """Fast, deterministic rules that complement the ML detectors."""

        # 1. Legacy protocol abuse (NTLM, Basic Auth, POP, IMAP)
        client_app = event.get("client_app", "").lower()
        if any(proto in client_app for proto in ["ntlm", "basic", "pop", "imap", "smtp", "exchange activesync"]):
            await self._emit_signal("legacy_protocol_abuse", event, {
                "confidence": 0.85,
                "description": f"Legacy protocol used: {event.get('client_app')}",
                "severity": "medium",
            })

        # 2. Successful login from Tor / known anonymous proxy
        if event.get("is_anonymous_ip") or event.get("is_tor_exit"):
            await self._emit_signal("suspicious_login", event, {
                "confidence": 0.90,
                "description": "Authentication from Tor exit node or anonymous proxy",
                "severity": "high",
            })

        # 3. Admin account used outside business hours from new location
        if event.get("user_is_admin") and self._is_off_hours(event.get("timestamp", "")):
            if not self._location_seen_before(event.get("user_id", ""), event.get("source_country", ""), history):
                await self._emit_signal("admin_after_hours_new_location", event, {
                    "confidence": 0.78,
                    "description": "Admin sign-in outside business hours from unrecognised location",
                    "severity": "high",
                })

        # 4. Service account interactive login
        upn = event.get("user_upn", "").lower()
        is_svc = any(prefix in upn for prefix in ["svc_", "sa-", "service-", "svcacct", "app_", "azuread-"])
        if is_svc and event.get("login_type") == "interactive":
            await self._emit_signal("service_account_abuse", event, {
                "confidence": 0.82,
                "description": f"Service account '{event.get('user_upn')}' used for interactive login",
                "severity": "high",
            })

        # 5. MFA disabled for user
        if event.get("mfa_disabled_event"):
            await self._emit_signal("mfa_disabled", event, {
                "confidence": 0.95,
                "description": f"MFA disabled for user '{event.get('user_upn')}'",
                "severity": "critical",
            })

        # 6. New device sign-in (first-time device fingerprint)
        if not self._device_seen_before(event.get("user_id", ""), event.get("device_id", ""), history):
            await self._emit_signal("new_device_access", event, {
                "confidence": 0.60,
                "description": f"First-time sign-in from device: {event.get('device_id', 'unknown')}",
                "severity": "low",
            })

    # ------------------------------------------------------------------
    # Automated response actions
    # ------------------------------------------------------------------

    async def _auto_remediate(self, signal_type: str, event: dict, provider_name: str):
        """
        Trigger automated containment for high-confidence signals.
        Actions are gated by the `auto_remediation` config block.
        """
        ar_config = self.config.get("auto_remediation", {})
        if not ar_config.get("enabled", False):
            return False

        user_id  = event.get("user_id", "")
        provider = self.providers.get(provider_name)
        if not provider or not user_id:
            return False

        if signal_type in ("impossible_travel", "token_theft", "mfa_fatigue") \
                and ar_config.get("revoke_sessions", False):
            await provider.revoke_user_sessions(user_id)
            logger.warning("AUTO-REMEDIATION: Revoked all sessions for user %s (%s)", user_id, signal_type)
            return True

        if signal_type in ("brute_force", "credential_stuffing") \
                and ar_config.get("block_user", False):
            await provider.block_signin(user_id, reason=signal_type)
            logger.warning("AUTO-REMEDIATION: Blocked sign-in for user %s (%s)", user_id, signal_type)
            return True

        return False

    # ------------------------------------------------------------------
    # Signal emission
    # ------------------------------------------------------------------

    async def _emit_signal(self, signal_type: str, event: dict, detection: dict):
        mitre    = self.MITRE_MAP.get(signal_type, ("", ""))
        sev_map  = {"critical": 4, "high": 3, "medium": 2, "low": 1}
        sev      = detection.get("severity", "medium")

        signal = IdentityThreatSignal(
            signal_type     = signal_type,
            user_id         = event.get("user_id", ""),
            user_upn        = event.get("user_upn", ""),
            source_ip       = event.get("source_ip", ""),
            source_country  = event.get("source_country", ""),
            source_platform = event.get("source_platform", ""),
            confidence      = detection.get("confidence", 0.0),
            severity        = sev,
            description     = detection.get("description", ""),
            mitre_tactic    = mitre[0],
            mitre_technique = mitre[1],
            raw_events      = [event],
            recommended_actions = self._get_recommended_actions(signal_type),
        )

        remediated = await self._auto_remediate(signal_type, event, event.get("source_platform", ""))
        signal.auto_remediated = remediated

        await self.emitter.emit(signal)
        logger.warning(
            "IDENTITY SIGNAL [%s] user=%s ip=%s confidence=%.2f sev=%s remediated=%s",
            signal_type, signal.user_upn, signal.source_ip,
            signal.confidence, sev, remediated
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _normalize_event(self, platform: str, raw: dict) -> dict:
        """Add source_platform tag to each event."""
        raw["source_platform"] = platform
        return raw

    def _is_off_hours(self, timestamp_str: str) -> bool:
        try:
            ts   = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
            hour = ts.hour
            return hour < 7 or hour >= 19
        except Exception:
            return False

    def _location_seen_before(self, user_id: str, country: str, history: list) -> bool:
        if not country:
            return True
        past_countries = {e.get("source_country", "") for e in history[:-1]}
        return country in past_countries

    def _device_seen_before(self, user_id: str, device_id: str, history: list) -> bool:
        if not device_id:
            return True
        past_devices = {e.get("device_id", "") for e in history[:-1]}
        return device_id in past_devices

    def _get_recommended_actions(self, signal_type: str) -> list[str]:
        actions = {
            "impossible_travel":      ["Revoke all user sessions", "Require MFA re-registration",
                                        "Contact user to verify travel"],
            "mfa_fatigue":            ["Temporarily block sign-in", "Switch to phishing-resistant MFA (FIDO2)",
                                        "Notify user of push bombing"],
            "brute_force":            ["Block source IP", "Lock account temporarily",
                                        "Reset credentials", "Enable CAPTCHA"],
            "token_theft":            ["Revoke all refresh tokens", "Force device compliance check",
                                        "Enable Conditional Access"],
            "privilege_escalation":   ["Audit recent role assignments", "Remove excess permissions",
                                        "Enable PIM for privileged roles"],
            "legacy_protocol_abuse":  ["Block legacy auth protocols in Conditional Access",
                                        "Enable modern auth for all clients"],
            "service_account_abuse":  ["Restrict service account to non-interactive login only",
                                        "Review service account permissions", "Rotate credentials"],
            "mfa_disabled":           ["Re-enable MFA immediately", "Audit who disabled MFA",
                                        "Review Conditional Access policies"],
        }
        return actions.get(signal_type, ["Investigate sign-in logs", "Contact user"])


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------

def load_config(path: str = "config/identity_monitor.yaml") -> dict:
    import yaml
    with open(path) as f:
        return yaml.safe_load(f)


if __name__ == "__main__":
    config  = load_config()
    monitor = IdentityThreatMonitor(config)
    asyncio.run(monitor.run())
