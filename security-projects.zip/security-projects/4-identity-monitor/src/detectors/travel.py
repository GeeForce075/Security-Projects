"""
Impossible Travel Detector
Detects geographically impossible sign-in sequences:
when a user appears in two locations that couldn't be reached
in the time elapsed between sign-ins, accounting for VPN / proxy tolerance.
"""

import logging
import math
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("identity.detectors.travel")


class ImpossibleTravelDetector:
    """
    Computes geographic distance and required travel speed between consecutive
    sign-ins. Flags sign-ins where the implied speed exceeds max_speed_kmh.

    Handles:
    - VPN / proxy IP addresses (configurable tolerance)
    - Federated / SSO re-use (token refresh doesn't imply physical travel)
    - Cloud Shell / service principal sign-ins (excluded by default)
    """

    EARTH_RADIUS_KM = 6371.0

    def __init__(self, config: dict):
        self.max_speed_kmh      = config.get("max_speed_kmh", 900)    # Commercial aircraft ~900 km/h
        self.min_distance_km    = config.get("min_distance_km", 100)  # Ignore micro-movements
        self.min_time_gap_min   = config.get("min_time_gap_minutes", 5)
        self.exclude_sso        = config.get("exclude_sso_refresh", True)
        self.risky_countries    = set(config.get("high_risk_countries", [
            "CN", "RU", "KP", "IR", "SY", "BY", "CU",  # examples — adjust per your threat model
        ]))

    def detect(self, current_event: dict, history: list[dict]) -> Optional[dict]:
        """
        Compare current event against the most recent sign-in from the same user.
        Returns a detection dict if impossible travel is detected, else None.
        """
        # Skip non-interactive / token refresh sign-ins
        if self.exclude_sso and self._is_token_refresh(current_event):
            return None

        # Need coordinates for current event
        curr_lat = current_event.get("source_lat")
        curr_lon = current_event.get("source_lon")
        curr_ts  = self._parse_ts(current_event.get("timestamp", ""))

        if curr_lat is None or curr_lon is None or curr_ts is None:
            return None

        # Find most recent prior event with valid coordinates
        prior = self._find_prior_event(current_event, history)
        if prior is None:
            return None

        prior_lat = prior.get("source_lat")
        prior_lon = prior.get("source_lon")
        prior_ts  = self._parse_ts(prior.get("timestamp", ""))

        if prior_lat is None or prior_lon is None or prior_ts is None:
            return None

        # Calculate distance and time delta
        distance_km  = self._haversine(curr_lat, curr_lon, prior_lat, prior_lon)
        time_gap_min = (curr_ts - prior_ts).total_seconds() / 60.0

        if time_gap_min < self.min_time_gap_min:
            return None

        if distance_km < self.min_distance_km:
            return None

        required_speed = distance_km / max(time_gap_min / 60.0, 0.0001)

        if required_speed <= self.max_speed_kmh:
            return None

        # Impossible travel confirmed
        confidence = self._compute_confidence(required_speed, distance_km, time_gap_min, current_event)

        return {
            "confidence":     confidence,
            "severity":       "critical" if confidence > 0.90 else "high",
            "description": (
                f"Impossible travel: {distance_km:.0f} km in {time_gap_min:.0f} min "
                f"({required_speed:.0f} km/h required). "
                f"Previous: {prior.get('source_country','')} {prior.get('source_city','')}. "
                f"Current: {current_event.get('source_country','')} {current_event.get('source_city','')}."
            ),
            "details": {
                "distance_km":     round(distance_km, 1),
                "time_gap_minutes":round(time_gap_min, 1),
                "required_speed_kmh": round(required_speed, 0),
                "prior_country":   prior.get("source_country", ""),
                "current_country": current_event.get("source_country", ""),
                "risky_country":   current_event.get("source_country", "") in self.risky_countries,
            },
        }

    # ------------------------------------------------------------------
    # Confidence calculation
    # ------------------------------------------------------------------

    def _compute_confidence(
        self,
        speed: float,
        distance: float,
        time_gap: float,
        event: dict,
    ) -> float:
        """
        Base confidence from speed excess, boosted by contextual signals.
        """
        # Base: linear scale from max_speed → 2× max_speed → 1.0
        speed_excess = (speed - self.max_speed_kmh) / self.max_speed_kmh
        base         = min(0.50 + speed_excess * 0.40, 0.90)

        boost = 0.0

        # Short time gap → less time to "explain" the gap (VPN, etc.)
        if time_gap < 30:
            boost += 0.05

        # Sign-in from high-risk country
        if event.get("source_country", "") in self.risky_countries:
            boost += 0.08

        # First-time country for this user
        if not event.get("_country_seen_before", True):
            boost += 0.05

        # Anonymous IP / Tor
        if event.get("is_anonymous_ip") or event.get("is_tor_exit"):
            boost += 0.06

        # Successful login (failed logins may be probes, not actual travel)
        if not event.get("login_success", True):
            boost -= 0.15

        return round(min(base + boost, 0.99), 3)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _find_prior_event(self, current: dict, history: list[dict]) -> Optional[dict]:
        """Find the most recent event from the same user with coordinates."""
        user_id     = current.get("user_id", "")
        curr_ts     = self._parse_ts(current.get("timestamp", ""))
        device_id   = current.get("device_id", "")

        for event in reversed(history[:-1]):
            if event.get("user_id") != user_id:
                continue
            if self.exclude_sso and self._is_token_refresh(event):
                continue
            if event.get("source_lat") is None:
                continue
            # Skip events from the same device (token refresh from same device ≠ travel)
            if device_id and event.get("device_id") == device_id:
                continue
            return event

        return None

    def _is_token_refresh(self, event: dict) -> bool:
        """Detect non-interactive token refresh / SSO re-use sign-ins."""
        client_app = (event.get("client_app") or "").lower()
        auth_req   = (event.get("auth_requirement") or "").lower()
        return (
            "token" in client_app or
            "refresh" in client_app or
            auth_req == "none"
        )

    def _parse_ts(self, ts_str: str) -> Optional[datetime]:
        if not ts_str:
            return None
        try:
            return datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        except Exception:
            return None

    @staticmethod
    def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Great-circle distance between two lat/lon points in kilometres."""
        R  = ImpossibleTravelDetector.EARTH_RADIUS_KM
        φ1 = math.radians(lat1)
        φ2 = math.radians(lat2)
        Δφ = math.radians(lat2 - lat1)
        Δλ = math.radians(lon2 - lon1)

        a  = math.sin(Δφ / 2) ** 2 + math.cos(φ1) * math.cos(φ2) * math.sin(Δλ / 2) ** 2
        c  = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c
