"""
Azure Active Directory (Entra ID) Identity Provider
Fetches sign-in logs, audit events, and risk detections via Microsoft Graph API.
Supports automated response: session revocation, account blocking, risk confirmation.
"""

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

import aiohttp
from azure.identity.aio import ClientSecretCredential, DefaultAzureCredential

logger = logging.getLogger("identity.providers.azure_ad")

GRAPH_BASE   = "https://graph.microsoft.com/v1.0"
GRAPH_BETA   = "https://graph.microsoft.com/beta"
GRAPH_SCOPE  = "https://graph.microsoft.com/.default"


class AzureADProvider:
    """
    Microsoft Azure Active Directory (Entra ID) connector via Microsoft Graph API.
    Reads: signInLogs, auditLogs, Identity Protection risk events.
    Writes: session revocation, sign-in blocking, risk state updates.
    """

    def __init__(self, config: dict):
        self.tenant_id      = config["tenant_id"]
        self.lookback_min   = config.get("lookback_minutes", 30)
        self.high_risk_only = config.get("high_risk_only", False)

        if all(k in config for k in ("client_id", "client_secret")):
            self.credential = ClientSecretCredential(
                tenant_id     = self.tenant_id,
                client_id     = config["client_id"],
                client_secret = config["client_secret"],
            )
        else:
            self.credential = DefaultAzureCredential()

    # ------------------------------------------------------------------
    # Sign-in log ingestion
    # ------------------------------------------------------------------

    async def fetch_signin_logs(self) -> list[dict]:
        """
        Fetch sign-in logs from Azure AD via Graph API.
        Includes: interactive, non-interactive, service-principal sign-ins.
        """
        since = (datetime.now(timezone.utc) - timedelta(minutes=self.lookback_min)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        filter_str = f"createdDateTime ge {since}"
        if self.high_risk_only:
            filter_str += " and riskLevelAggregated ne 'none'"

        endpoint = f"{GRAPH_BASE}/auditLogs/signIns?$filter={filter_str}&$top=500"
        raw_logs = await self._paginate(endpoint)
        normalized = [self._normalize_signin(log) for log in raw_logs]
        logger.info("Azure AD: fetched %d sign-in events", len(normalized))
        return normalized

    def _normalize_signin(self, raw: dict) -> dict:
        """Map Azure AD sign-in log to common identity event schema."""
        loc         = raw.get("location", {}) or {}
        geo         = loc.get("geoCoordinates", {}) or {}
        risk_det    = raw.get("riskEventTypes", []) or []
        mfa_detail  = raw.get("mfaDetail", {}) or {}

        return {
            "source_platform":    "azure_ad",
            "event_id":           raw.get("id", ""),
            "event_type":         "signin",
            "user_id":            raw.get("userId", ""),
            "user_upn":           raw.get("userPrincipalName", ""),
            "user_display_name":  raw.get("userDisplayName", ""),
            "timestamp":          raw.get("createdDateTime", ""),
            "source_ip":          raw.get("ipAddress", ""),
            "source_country":     loc.get("countryOrRegion", ""),
            "source_city":        loc.get("city", ""),
            "source_lat":         geo.get("latitude"),
            "source_lon":         geo.get("longitude"),
            "device_id":          raw.get("deviceDetail", {}).get("deviceId", ""),
            "device_name":        raw.get("deviceDetail", {}).get("displayName", ""),
            "device_os":          raw.get("deviceDetail", {}).get("operatingSystem", ""),
            "device_compliant":   raw.get("deviceDetail", {}).get("isCompliant", None),
            "app_id":             raw.get("appId", ""),
            "app_name":           raw.get("appDisplayName", ""),
            "resource_id":        raw.get("resourceId", ""),
            "resource_name":      raw.get("resourceDisplayName", ""),
            "client_app":         raw.get("clientAppUsed", ""),
            "auth_protocol":      raw.get("authenticationProtocol", ""),
            "auth_requirement":   raw.get("authenticationRequirement", ""),
            "login_success":      raw.get("status", {}).get("errorCode", 1) == 0,
            "error_code":         raw.get("status", {}).get("errorCode", 0),
            "failure_reason":     raw.get("status", {}).get("failureReason", ""),
            "conditional_access": raw.get("appliedConditionalAccessPolicies", []),
            "mfa_method":         mfa_detail.get("authMethod", ""),
            "mfa_detail":         mfa_detail.get("authDetail", ""),
            "risk_level_signin":  raw.get("riskLevelDuringSignIn", "none"),
            "risk_level_user":    raw.get("riskLevelAggregated", "none"),
            "risk_state":         raw.get("riskState", "none"),
            "risk_event_types":   risk_det,
            "is_anonymous_ip":    "anonymizedIPAddress" in risk_det,
            "is_tor_exit":        "maliciousIPAddress" in risk_det,
            "user_is_admin":      False,  # enriched separately
            "mfa_disabled_event": False,
        }

    # ------------------------------------------------------------------
    # Audit log ingestion
    # ------------------------------------------------------------------

    async def fetch_audit_logs(self, categories: Optional[list] = None) -> list[dict]:
        """Fetch directory audit logs (role changes, MFA changes, etc.)."""
        since      = (datetime.now(timezone.utc) - timedelta(minutes=self.lookback_min)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        filter_str = f"activityDateTime ge {since}"
        if categories:
            cat_filter = " or ".join(f"category eq '{c}'" for c in categories)
            filter_str += f" and ({cat_filter})"

        endpoint   = f"{GRAPH_BASE}/auditLogs/directoryAudits?$filter={filter_str}&$top=200"
        events     = await self._paginate(endpoint)
        logger.info("Azure AD: fetched %d audit events", len(events))
        return events

    async def fetch_risk_detections(self) -> list[dict]:
        """Fetch Azure AD Identity Protection risk detections."""
        since      = (datetime.now(timezone.utc) - timedelta(minutes=self.lookback_min)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        endpoint   = (f"{GRAPH_BASE}/identityProtection/riskDetections"
                      f"?$filter=detectedDateTime ge {since}&$top=200")
        detections = await self._paginate(endpoint)
        logger.info("Azure AD: fetched %d risk detections", len(detections))
        return detections

    # ------------------------------------------------------------------
    # Automated response
    # ------------------------------------------------------------------

    async def revoke_user_sessions(self, user_id: str) -> bool:
        """Revoke all refresh tokens and active sessions for a user."""
        token = await self._get_token()
        url   = f"{GRAPH_BASE}/users/{user_id}/revokeSignInSessions"
        async with aiohttp.ClientSession() as sess:
            async with sess.post(
                url,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                success = resp.status in (200, 204)
                logger.warning("Azure AD: session revocation for %s: %s", user_id, "OK" if success else "FAILED")
                return success

    async def block_signin(self, user_id: str, reason: str = "Security policy") -> bool:
        """Block a user's ability to sign in."""
        token   = await self._get_token()
        url     = f"{GRAPH_BASE}/users/{user_id}"
        payload = {"accountEnabled": False}
        async with aiohttp.ClientSession() as sess:
            async with sess.patch(
                url,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json=payload,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                success = resp.status in (200, 204)
                logger.warning("Azure AD: sign-in block for %s (%s): %s",
                               user_id, reason, "OK" if success else "FAILED")
                return success

    async def confirm_user_compromised(self, user_id: str) -> bool:
        """Mark user risk state as 'confirmedCompromised' in Identity Protection."""
        token   = await self._get_token()
        url     = f"{GRAPH_BASE}/identityProtection/riskyUsers/confirmCompromised"
        payload = {"userIds": [user_id]}
        async with aiohttp.ClientSession() as sess:
            async with sess.post(
                url,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json=payload,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                success = resp.status in (200, 204)
                logger.warning("Azure AD: confirmed compromised %s: %s", user_id, "OK" if success else "FAILED")
                return success

    async def get_user_roles(self, user_id: str) -> list[str]:
        """Fetch directory roles assigned to a user."""
        token  = await self._get_token()
        url    = f"{GRAPH_BASE}/users/{user_id}/transitiveMemberOf/microsoft.graph.directoryRole"
        data   = await self._get_with_token(url, token)
        return [r.get("displayName", "") for r in data.get("value", [])]

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    async def _get_token(self) -> str:
        token = await self.credential.get_token(GRAPH_SCOPE)
        return token.token

    async def _paginate(self, url: str) -> list[dict]:
        """Handle OData @odata.nextLink pagination."""
        token   = await self._get_token()
        results = []
        next_url = url

        while next_url:
            data     = await self._get_with_token(next_url, token)
            results.extend(data.get("value", []))
            next_url = data.get("@odata.nextLink")
            if len(results) >= 10_000:
                logger.warning("Azure AD: pagination limit reached (10k events)")
                break

        return results

    async def _get_with_token(self, url: str, token: str) -> dict:
        async with aiohttp.ClientSession() as sess:
            async with sess.get(
                url,
                headers={"Authorization": f"Bearer {token}"},
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def close(self):
        await self.credential.close()
