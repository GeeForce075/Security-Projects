# Enterprise Security Platform – GitHub Project Suite

A suite of five production-grade security engineering projects designed for
enterprise IT infrastructure protection. Each project is independently deployable
and integrates with your existing security stack.

---

## 📁 Project Index

| # | Project | Purpose | Key Integrations |
|---|---------|---------|-----------------|
| 1 | [SOAR Orchestration](#1-soar-orchestration) | Unified cross-platform alert routing | Sentinel, Splunk SOAR, Cortex XSOAR, Shuffle |
| 2 | [ML Threat Detection](#2-ml-threat-detection) | Network anomaly & C2 beacon detection | Wireshark, CrowdStrike, SentinelOne, Elastic |
| 3 | [Vulnerability Aggregator](#3-vulnerability-aggregator) | Unified vuln management & prioritisation | Nessus, OpenVAS, Qualys, Rapid7, Prowler |
| 4 | [Identity Monitor](#4-identity-monitor) | IAM threat detection & automated response | Azure AD, Okta, AD On-Prem, Keycloak |
| 5 | [CI/CD Security Pipeline](#5-cicd-security-pipeline) | DevSecOps pipeline (GitHub Actions + GitLab CI) | Semgrep, Trivy, Checkov, ZAP, tfsec |

---

## Stack Coverage

```
SIEM/SOAR    │ Microsoft Sentinel  Splunk SOAR  Cortex XSOAR  Shuffle SOAR
EDR          │ CrowdStrike Falcon  SentinelOne  MS Defender   Sophos
Firewall     │ Palo Alto  Fortinet  Cisco ASA  Azure Firewall  AWS Network FW
IAM          │ Azure AD (Entra)  AD On-Prem  Okta  Ping Identity  Keycloak
Vuln Mgmt    │ Nessus  OpenVAS  Qualys  Rapid7 InsightVM  Prowler
Cloud        │ Azure  AWS  GCP  Huawei Cloud  OCI  IBM Cloud
IaC          │ Terraform  Ansible
CI/CD        │ GitHub Actions  GitLab CI/CD  Jenkins
Containers   │ Docker  Kubernetes  VMware  Hyper-V
OS           │ Ubuntu  RHEL  CentOS  Windows Server  Windows 10/11  macOS
```

---

## 1. SOAR Orchestration

**Path:** `1-soar-orchestration/`

Polls all connected SOAR/SIEM platforms every 30 seconds, normalises alerts to
a unified schema, deduplicates, scores with an ML model, and routes to playbooks.

### Architecture
```
[Sentinel] ──┐
[Splunk SOAR]─┤
[Cortex XSOAR]┼──► AlertNormalizer ──► Deduplicator ──► MLScorer ──► PlaybookEngine
[Shuffle] ───┤                                                         │
[CrowdStrike]─┘                                              ┌─────────┘
                                                             ▼
                                              Route to platforms + emit incidents
```

### Key Files
```
src/
  orchestrator.py          Main async event loop
  connectors/
    sentinel.py            Microsoft Sentinel (Graph API + Log Analytics)
    splunk_soar.py         Splunk SOAR / Phantom REST API
    cortex_xsoar.py        Cortex XSOAR REST API
    shuffle.py             Shuffle SOAR webhook integration
  utils/
    alert_normalizer.py    10-platform normaliser with IOC extraction
    severity_scorer.py     ML risk scorer (GradientBoosting + heuristic fallback)
    deduplicator.py        TTL-based fingerprint deduplication
config/
  orchestrator.yaml        Full configuration with env var substitution
```

### Quick Start
```bash
cd 1-soar-orchestration
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp config/orchestrator.yaml.example config/orchestrator.yaml
# Edit config with your credentials (or use Key Vault / Secrets Manager)
python src/orchestrator.py
```

---

## 2. ML Threat Detection

**Path:** `2-ml-threat-detection/`

Multi-model network anomaly detection engine. Processes flow data from
Zeek/Suricata/Wireshark/PCAP and endpoint telemetry to detect attacks in real time.

### Detection Models

| Model | Detects | Algorithm |
|-------|---------|-----------|
| Isolation Forest | Global network anomalies | sklearn IsolationForest |
| Autoencoder | Deep protocol anomalies | TF/Keras |
| LSTM Beacon | C2 beaconing / periodic callbacks | TF/Keras LSTM |
| Statistical | Port scans, exfiltration, brute force, DNS tunneling | Heuristic |

### MITRE ATT&CK Coverage
- T1046 Network Service Scanning (port scan)
- T1048 Exfiltration over Alternative Protocol
- T1071 Application Layer Protocol (C2)
- T1071.004 DNS (DNS tunneling)
- T1110 Brute Force
- T1021 Remote Services (lateral movement)

### Kubernetes Deployment
```bash
cd 2-ml-threat-detection
kubectl apply -f k8s/deployment.yaml
```

---

## 3. Vulnerability Aggregator

**Path:** `3-vuln-aggregator/`

Pulls scan results from all configured vulnerability scanners, normalises,
deduplicates across platforms, enriches with EPSS scores, and produces
prioritised remediation plans.

### Priority Scoring Formula
```
priority = CVSS_v3 × (asset_criticality/5) × (1 + EPSS_score) × exploit_multiplier
exploit_multiplier = 1.5 if public exploit exists, else 1.0
```

### Outputs
- `vulns_{timestamp}.json` – Full vulnerability feed (ingest to Sentinel/Splunk)
- `remediation_{timestamp}.csv` – Prioritised remediation plan
- `report_{timestamp}.html` – Executive summary report

### Cloud Posture (Prowler)
```bash
# Azure
prowler azure --checks cis_2.0

# AWS
prowler aws --checks cis_1.5 --output-formats json-asff

# GCP
prowler gcp --checks cis_2.0
```

---

## 4. Identity Monitor

**Path:** `4-identity-monitor/`

Continuously monitors all identity platforms for account takeover, privilege
escalation, and session-based attacks. Includes optional automated response.

### Detection Coverage

| Signal | Confidence | Auto-Remediation |
|--------|-----------|-----------------|
| Impossible Travel | 0.70–0.99 | Session revocation |
| MFA Fatigue / Push Bombing | 0.85–0.99 | Sign-in block |
| Brute Force / Credential Stuffing | 0.80–0.99 | Sign-in block |
| Token Theft / Session Hijacking | 0.75–0.99 | Token revocation |
| Privilege Escalation | 0.70–0.95 | Alert only |
| Legacy Protocol Abuse | 0.85 | Alert only |
| Service Account Interactive Login | 0.82 | Alert only |
| MFA Disabled for User | 0.95 | Alert only |
| Admin Sign-in – New Country – Off Hours | 0.78 | Alert only |

### Automated Response (disabled by default)
```yaml
# config/identity_monitor.yaml
auto_remediation:
  enabled: true
  revoke_sessions: true    # For: impossible_travel, token_theft, mfa_fatigue
  block_user: false        # For: brute_force, credential_stuffing
```

---

## 5. CI/CD Security Pipeline

**Path:** `5-cicd-security-pipeline/`

Full DevSecOps pipeline with security gates that block deployment on findings.

### Pipeline Stages

```
Secrets Scan ──► SAST ──► SCA ──► Container Scan ──► IaC ──► DAST ──► Gate ──► Deploy
    │               │        │           │               │       │        │
 Gitleaks       Semgrep   Trivy      Trivy Image    Checkov    ZAP   Blocks if
 TruffleHog     CodeQL    OWASP DC   Grype          tfsec             any fail
                Bandit    pip-audit  Dockle         Prowler
```

### Tools Included
- **Secrets:** Gitleaks, TruffleHog, detect-secrets
- **SAST:** Semgrep (OWASP Top 10), CodeQL, Bandit
- **SCA:** OWASP Dependency-Check, Trivy FS, pip-audit, npm audit
- **Container:** Trivy image, Grype, Dockle
- **IaC:** Checkov, tfsec, Terrascan, Prowler
- **DAST:** OWASP ZAP baseline + full scan
- **Ansible:** CIS Benchmark hardening for Linux and Windows Server

---

## Requirements

```
Python          3.12+
aiohttp         3.9+
azure-identity  1.16+
azure-mgmt-*    latest
scikit-learn    1.4+
pandas          2.2+
numpy           1.26+
tensorflow      2.15+    (optional – for LSTM beacon model)
pyyaml          6.0+
```

Install all:
```bash
pip install -r requirements.txt
```

---

## Security Configuration

All secrets are loaded from environment variables. **Never commit credentials.**

Recommended secret storage:
- **Azure:** Azure Key Vault + CSI driver (manifests included)
- **AWS:** AWS Secrets Manager + IRSA
- **Self-hosted:** HashiCorp Vault

---

## Architecture Notes

- All network I/O is async (`asyncio` + `aiohttp`)
- Kubernetes deployments use restricted Pod Security Standards
- Network Policies enforce zero-trust between pods
- Workload Identity / OIDC used for all cloud auth (no long-lived keys)
- All containers run as non-root with read-only root filesystems
