import logging
import threading
import time
from typing import Any, Callable, Optional

log = logging.getLogger("secrets.rotation")


class RotationHandler:
    """
    Handles what actually happens after a secret rotates.
    Register handlers per secret key type.
    The SecretsManager calls these when it detects a value change at refresh time.
    """

    def __init__(self, secrets_manager):
        self._sm      = secrets_manager
        self._handlers: dict[str, list[Callable]] = {}

    def register_db_pool(self, key: str, get_pool_fn: Callable, rebuild_fn: Callable):
        """
        Reconnect a database pool after credential rotation.
        get_pool_fn: returns the current pool object
        rebuild_fn: called with (new_connection_string) → new pool
        """
        def handler(secret_key: str, new_value: str):
            log.info("DB pool rotation triggered for '%s'", secret_key)
            try:
                old_pool = get_pool_fn()
                new_pool = rebuild_fn(new_value)
                # Drain old pool gracefully — wait up to 30s for in-flight queries
                self._drain_pool(old_pool, timeout=30)
                log.info("DB pool rotated for '%s'", secret_key)
                return new_pool
            except Exception as exc:
                log.error("DB pool rotation failed for '%s': %s", secret_key, exc)

        self._sm.on_rotation(key, handler)

    def register_http_client(self, key: str, rebuild_fn: Callable):
        """
        Rebuild an HTTP client/session after API key rotation.
        rebuild_fn: called with (new_api_key) → new client
        """
        def handler(secret_key: str, new_value: str):
            log.info("HTTP client rotation triggered for '%s'", secret_key)
            try:
                new_client = rebuild_fn(new_value)
                log.info("HTTP client rebuilt for '%s'", secret_key)
                return new_client
            except Exception as exc:
                log.error("HTTP client rotation failed for '%s': %s", secret_key, exc)

        self._sm.on_rotation(key, handler)

    def register_azure_credential(self, key: str, rebuild_fn: Callable):
        """Refresh Azure SDK credential object after client secret rotation."""
        def handler(secret_key: str, new_value: str):
            log.info("Azure credential rotation for '%s'", secret_key)
            try:
                from azure.identity import ClientSecretCredential
                tenant_id = self._sm.require("AZURE_TENANT_ID")
                client_id = self._sm.require("AZURE_CLIENT_ID")
                new_cred  = ClientSecretCredential(
                    tenant_id     = tenant_id,
                    client_id     = client_id,
                    client_secret = new_value,
                )
                rebuild_fn(new_cred)
                log.info("Azure credential rebuilt for '%s'", secret_key)
            except Exception as exc:
                log.error("Azure credential rotation failed: %s", exc)

        self._sm.on_rotation(key, handler)

    def register_aws_client(self, key: str, service: str, rebuild_fn: Callable):
        """Rebuild a boto3 client after IAM key rotation."""
        def handler(secret_key: str, new_value: str):
            log.info("AWS client rotation for '%s' (%s)", secret_key, service)
            try:
                import boto3
                access_key = self._sm.get("AWS_ACCESS_KEY_ID")
                new_client = boto3.client(
                    service,
                    aws_access_key_id     = access_key,
                    aws_secret_access_key = new_value,
                )
                rebuild_fn(new_client)
                log.info("AWS %s client rebuilt", service)
            except Exception as exc:
                log.error("AWS client rotation failed: %s", exc)

        self._sm.on_rotation(key, handler)

    def register_webhook(self, key: str, url: str, headers: dict = None):
        """
        POST a notification to a webhook when a secret rotates.
        Useful for notifying downstream services of credential changes.
        """
        def handler(secret_key: str, new_value: str):
            import urllib.request
            import json as _json
            payload = _json.dumps({
                "event":      "secret_rotated",
                "key":        secret_key,
                "timestamp":  time.time(),
            }).encode()
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={
                    "Content-Type": "application/json",
                    **(headers or {}),
                }
            )
            try:
                with urllib.request.urlopen(req, timeout=10) as resp:
                    log.info("Rotation webhook for '%s': HTTP %d", secret_key, resp.status)
            except Exception as exc:
                log.warning("Rotation webhook failed for '%s': %s", secret_key, exc)

        self._sm.on_rotation(key, handler)

    @staticmethod
    def _drain_pool(pool: Any, timeout: int = 30):
        deadline = time.monotonic() + timeout
        try:
            if hasattr(pool, "dispose"):         # SQLAlchemy
                pool.dispose()
            elif hasattr(pool, "closeall"):      # psycopg2
                pool.closeall()
            elif hasattr(pool, "close"):
                pool.close()
        except Exception as exc:
            log.warning("Pool drain error: %s", exc)


# ─────────────────────────────────────────────────────────────────────────────
# Scheduled rotation enforcer
# Forces specific secrets to rotate on a calendar schedule (e.g. every 90 days)
# even if the vault backend hasn't flagged them as expired.
# ─────────────────────────────────────────────────────────────────────────────

class ScheduledRotationEnforcer:
    def __init__(self, secrets_manager):
        self._sm        = secrets_manager
        self._schedule: dict[str, int] = {}   # key → max age in seconds
        self._last_seen: dict[str, float] = {}
        self._running   = False
        self._thread:   Optional[threading.Thread] = None

    def enforce(self, key: str, max_age_days: int):
        """Register a secret that must be rotated within max_age_days."""
        self._schedule[key] = max_age_days * 86400
        if not self._running:
            self._start()

    def _start(self):
        self._running = True
        self._thread  = threading.Thread(
            target=self._loop, daemon=True, name="rotation-enforcer"
        )
        self._thread.start()

    def _loop(self):
        while self._running:
            time.sleep(3600)   # check hourly
            now = time.monotonic()
            for key, max_age in self._schedule.items():
                last = self._last_seen.get(key, 0)
                if now - last >= max_age:
                    log.warning(
                        "Secret '%s' has exceeded max age of %d days — forcing rotation",
                        key, max_age // 86400
                    )
                    self._sm.invalidate(key)   # next get() will re-fetch from vault
                    self._sm.get(key)          # trigger immediate re-fetch + callbacks
                    self._last_seen[key] = now

    def mark_rotated(self, key: str):
        self._last_seen[key] = time.monotonic()

    def stop(self):
        self._running = False
