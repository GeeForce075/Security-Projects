import json
import logging
import os
import time
from typing import Optional

log = logging.getLogger("secrets.backends")


# ──────────────────────────────────────────────────────────────────────────────
# Azure Key Vault
# ──────────────────────────────────────────────────────────────────────────────

class _AzureKeyVaultBackend:
    def __init__(self, cfg: dict):
        from azure.keyvault.secrets import SecretClient
        from azure.identity import (
            DefaultAzureCredential,
            ClientSecretCredential,
            ManagedIdentityCredential,
            WorkloadIdentityCredential,
        )

        self.vault_url = cfg["vault_url"]   # https://my-vault.vault.azure.net/

        # Auth precedence: Workload Identity → Managed Identity → SP → Default
        if cfg.get("use_workload_identity"):
            cred = WorkloadIdentityCredential()
        elif cfg.get("use_managed_identity"):
            mid = cfg.get("managed_identity_client_id")
            cred = ManagedIdentityCredential(client_id=mid) if mid else ManagedIdentityCredential()
        elif all(k in cfg for k in ("tenant_id", "client_id", "client_secret")):
            cred = ClientSecretCredential(
                tenant_id     = cfg["tenant_id"],
                client_id     = cfg["client_id"],
                client_secret = cfg["client_secret"],
            )
        else:
            cred = DefaultAzureCredential()

        self._client      = SecretClient(vault_url=self.vault_url, credential=cred)
        self._key_prefix  = cfg.get("key_prefix", "")   # e.g. "soar-prod-"
        self._retry_count = cfg.get("retry_count", 3)
        self._retry_delay = cfg.get("retry_delay_seconds", 2)

    def fetch(self, key: str) -> Optional[str]:
        vault_key = f"{self._key_prefix}{key.lower().replace('_', '-')}"
        last_exc  = None

        for attempt in range(self._retry_count):
            try:
                secret = self._client.get_secret(vault_key)
                return secret.value
            except Exception as exc:
                last_exc = exc
                if attempt < self._retry_count - 1:
                    time.sleep(self._retry_delay * (attempt + 1))

        log.debug("Azure KV: '%s' not found — %s", vault_key, last_exc)
        return None

    def store(self, key: str, value: str, tags: dict = None, expires_on=None):
        vault_key = f"{self._key_prefix}{key.lower().replace('_', '-')}"
        kwargs    = {"tags": tags or {}}
        if expires_on:
            from azure.keyvault.secrets import SecretProperties
            kwargs["expires_on"] = expires_on
        self._client.set_secret(vault_key, value, **kwargs)
        log.info("Azure KV: stored '%s'", vault_key)

    def delete(self, key: str):
        vault_key = f"{self._key_prefix}{key.lower().replace('_', '-')}"
        self._client.begin_delete_secret(vault_key)


# ──────────────────────────────────────────────────────────────────────────────
# AWS Secrets Manager
# ──────────────────────────────────────────────────────────────────────────────

class _AWSSecretsBackend:
    def __init__(self, cfg: dict):
        import boto3
        from botocore.config import Config

        region = cfg.get("region", os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))

        session_kwargs: dict = {"region_name": region}

        # Support explicit role assumption (cross-account, least-privilege)
        if cfg.get("assume_role_arn"):
            sts = boto3.client("sts", region_name=region)
            resp = sts.assume_role(
                RoleArn         = cfg["assume_role_arn"],
                RoleSessionName = "soar-secrets-manager",
                DurationSeconds = 3600,
            )
            c = resp["Credentials"]
            session_kwargs.update({
                "aws_access_key_id":     c["AccessKeyId"],
                "aws_secret_access_key": c["SecretAccessKey"],
                "aws_session_token":     c["SessionToken"],
            })

        boto_cfg   = Config(retries={"max_attempts": 3, "mode": "adaptive"})
        self._sm   = boto3.client("secretsmanager", config=boto_cfg, **session_kwargs)
        self._prefix = cfg.get("key_prefix", "")

    def fetch(self, key: str) -> Optional[str]:
        secret_id = f"{self._prefix}{key}"
        try:
            resp = self._sm.get_secret_value(SecretId=secret_id)
            raw  = resp.get("SecretString") or resp.get("SecretBinary", b"").decode()

            # Some secrets are stored as JSON {"key": "value"}
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict) and key in parsed:
                    return parsed[key]
                # If it's a flat JSON string, return the whole thing
                return raw
            except (json.JSONDecodeError, TypeError):
                return raw

        except self._sm.exceptions.ResourceNotFoundException:
            return None
        except Exception as exc:
            log.debug("AWS SM: error fetching '%s': %s", secret_id, exc)
            return None

    def store(self, key: str, value: str, description: str = "", tags: list = None):
        secret_id = f"{self._prefix}{key}"
        try:
            self._sm.put_secret_value(SecretId=secret_id, SecretString=value)
        except self._sm.exceptions.ResourceNotFoundException:
            self._sm.create_secret(
                Name        = secret_id,
                SecretString= value,
                Description = description or key,
                Tags        = tags or [],
            )
        log.info("AWS SM: stored '%s'", secret_id)

    def rotate(self, key: str, lambda_arn: str):
        secret_id = f"{self._prefix}{key}"
        self._sm.rotate_secret(
            SecretId            = secret_id,
            RotationLambdaARN   = lambda_arn,
            RotationRules       = {"AutomaticallyAfterDays": 30},
        )


# ──────────────────────────────────────────────────────────────────────────────
# GCP Secret Manager
# ──────────────────────────────────────────────────────────────────────────────

class _GCPSecretBackend:
    def __init__(self, cfg: dict):
        from google.cloud import secretmanager
        from google.oauth2 import service_account

        self._project_id = cfg["project_id"]
        self._prefix     = cfg.get("key_prefix", "")

        if cfg.get("service_account_json"):
            svc_info = json.loads(cfg["service_account_json"])
            creds    = service_account.Credentials.from_service_account_info(
                svc_info,
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
            )
            self._client = secretmanager.SecretManagerServiceClient(credentials=creds)
        else:
            # Uses ADC (Workload Identity on GKE, metadata server on GCE)
            self._client = secretmanager.SecretManagerServiceClient()

    def fetch(self, key: str, version: str = "latest") -> Optional[str]:
        secret_id = f"{self._prefix}{key.lower().replace('_', '-')}"
        name      = (
            f"projects/{self._project_id}"
            f"/secrets/{secret_id}/versions/{version}"
        )
        try:
            resp = self._client.access_secret_version(request={"name": name})
            return resp.payload.data.decode()
        except Exception as exc:
            log.debug("GCP SM: '%s' not found — %s", secret_id, exc)
            return None

    def store(self, key: str, value: str, labels: dict = None):
        from google.cloud import secretmanager
        secret_id  = f"{self._prefix}{key.lower().replace('_', '-')}"
        parent     = f"projects/{self._project_id}"
        secret_ref = f"{parent}/secrets/{secret_id}"

        try:
            self._client.get_secret(request={"name": secret_ref})
        except Exception:
            self._client.create_secret(
                request={
                    "parent": parent,
                    "secret_id": secret_id,
                    "secret": {
                        "replication": {"automatic": {}},
                        "labels": labels or {},
                    },
                }
            )

        payload = value.encode()
        self._client.add_secret_version(
            request={
                "parent": secret_ref,
                "payload": {"data": payload},
            }
        )


# ──────────────────────────────────────────────────────────────────────────────
# HashiCorp Vault (KV v2)
# ──────────────────────────────────────────────────────────────────────────────

class _HashiCorpVaultBackend:
    def __init__(self, cfg: dict):
        import hvac

        self._mount   = cfg.get("mount", "secret")
        self._prefix  = cfg.get("key_prefix", "soar/")

        self._client  = hvac.Client(
            url       = cfg["url"],
            namespace = cfg.get("namespace"),   # Vault Enterprise namespaces
        )

        # Auth: token → approle → kubernetes → aws iam
        auth_method = cfg.get("auth_method", "token")

        if auth_method == "token":
            self._client.token = cfg["token"]

        elif auth_method == "approle":
            self._client.auth.approle.login(
                role_id   = cfg["role_id"],
                secret_id = cfg["secret_id"],
            )

        elif auth_method == "kubernetes":
            jwt_path = cfg.get("jwt_path", "/var/run/secrets/kubernetes.io/serviceaccount/token")
            with open(jwt_path) as f:
                jwt = f.read().strip()
            self._client.auth.kubernetes.login(
                role = cfg["role"],
                jwt  = jwt,
            )

        elif auth_method == "aws_iam":
            self._client.auth.aws.iam_login(
                access_key   = cfg.get("aws_access_key_id"),
                secret_key   = cfg.get("aws_secret_access_key"),
                session_token= cfg.get("aws_session_token"),
                role         = cfg.get("role"),
            )

        if not self._client.is_authenticated():
            raise RuntimeError("HashiCorp Vault authentication failed")

        log.info("HashiCorp Vault: authenticated via %s", auth_method)

    def fetch(self, key: str) -> Optional[str]:
        path = f"{self._prefix}{key}"
        try:
            resp  = self._client.secrets.kv.v2.read_secret_version(
                path  = path,
                mount_point = self._mount,
                raise_on_deleted_version = True,
            )
            data  = resp["data"]["data"]
            return data.get(key) or data.get("value") or json.dumps(data)
        except Exception as exc:
            log.debug("HCV: '%s' not found — %s", path, exc)
            return None

    def store(self, key: str, value: str):
        path = f"{self._prefix}{key}"
        self._client.secrets.kv.v2.create_or_update_secret(
            path        = path,
            secret      = {key: value},
            mount_point = self._mount,
        )

    def renew_token(self):
        try:
            self._client.auth.token.renew_self()
            log.debug("HCV: token renewed")
        except Exception as exc:
            log.warning("HCV: token renewal failed — %s", exc)


# ──────────────────────────────────────────────────────────────────────────────
# Local Encrypted Store (AES-256-GCM via Fernet, offline/air-gapped fallback)
# ──────────────────────────────────────────────────────────────────────────────

class _LocalEncryptedBackend:
    """
    AES-256 encrypted JSON file on disk.
    Master key read from env var SECRETS_MASTER_KEY (base64url-encoded 32 bytes)
    or derived from a hardware token / TPM if available.

    Only use this for air-gapped environments or local dev.
    Production should always use a proper vault backend above.
    """

    def __init__(self, cfg: dict):
        from cryptography.fernet import Fernet, InvalidToken

        self._Fernet      = Fernet
        self._InvalidToken = InvalidToken
        self._store_path  = Path(cfg.get("store_path", ".secrets.enc"))

        master_key = (
            cfg.get("master_key")
            or os.environ.get("SECRETS_MASTER_KEY")
        )
        if not master_key:
            raise RuntimeError(
                "LocalEncryptedBackend requires SECRETS_MASTER_KEY env var "
                "(base64url-encoded 32 bytes, generate with: python -c "
                "\"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\")"
            )

        self._fernet  = Fernet(master_key.encode() if isinstance(master_key, str) else master_key)
        self._secrets = self._load()

    def _load(self) -> dict:
        if not self._store_path.exists():
            return {}
        try:
            raw = self._store_path.read_bytes()
            decrypted = self._fernet.decrypt(raw)
            return json.loads(decrypted)
        except self._InvalidToken:
            log.error("Local store: master key mismatch — cannot decrypt store")
            return {}
        except Exception as exc:
            log.error("Local store: failed to load — %s", exc)
            return {}

    def _save(self):
        plaintext = json.dumps(self._secrets).encode()
        encrypted = self._fernet.encrypt(plaintext)
        self._store_path.write_bytes(encrypted)
        os.chmod(self._store_path, 0o600)

    def fetch(self, key: str) -> Optional[str]:
        return self._secrets.get(key)

    def store(self, key: str, value: str):
        self._secrets[key] = value
        self._save()
        log.info("Local store: wrote '%s'", key)

    def delete(self, key: str):
        self._secrets.pop(key, None)
        self._save()

    def list_keys(self) -> list[str]:
        return list(self._secrets.keys())
