"""
SOAR Orchestrator — startup with secrets bootstrap.
This replaces the orchestrator.py entry point with a crash-safe,
credential-aware startup sequence.
"""

import asyncio
import logging
import signal
import sys

log = logging.getLogger("soar")


def configure_logging(level: str = "INFO"):
    import json as _json

    class JSONFormatter(logging.Formatter):
        def format(self, record):
            return _json.dumps({
                "ts":      self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
                "level":   record.levelname,
                "logger":  record.name,
                "msg":     record.getMessage(),
                **({"exc": self.formatException(record.exc_info)} if record.exc_info else {}),
            })

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO), handlers=[handler])


def build_connector_config(creds: dict) -> dict:
    """Map raw credential keys into the nested config structure each connector expects."""
    return {
        "connectors": {
            "sentinel": {
                "enabled":           bool(creds.get("AZURE_CLIENT_SECRET")),
                "subscription_id":   creds.get("AZURE_SUBSCRIPTION_ID", ""),
                "resource_group":    creds.get("AZURE_RESOURCE_GROUP", ""),
                "workspace_name":    creds.get("SENTINEL_WORKSPACE_NAME", ""),
                "workspace_id":      creds.get("SENTINEL_WORKSPACE_ID", ""),
                "tenant_id":         creds.get("AZURE_TENANT_ID", ""),
                "client_id":         creds.get("AZURE_CLIENT_ID", ""),
                "client_secret":     creds.get("AZURE_CLIENT_SECRET", ""),
                "lookback_minutes":  30,
            },
            "splunk_soar": {
                "enabled":     bool(creds.get("SPLUNK_SOAR_URL") and creds.get("SPLUNK_SOAR_API_TOKEN")),
                "base_url":    creds.get("SPLUNK_SOAR_URL", ""),
                "api_token":   creds.get("SPLUNK_SOAR_API_TOKEN", ""),
                "verify_ssl":  True,
            },
            "cortex_xsoar": {
                "enabled":   bool(creds.get("CORTEX_XSOAR_URL") and creds.get("CORTEX_XSOAR_API_KEY")),
                "base_url":  creds.get("CORTEX_XSOAR_URL", ""),
                "api_key":   creds.get("CORTEX_XSOAR_API_KEY", ""),
                "verify_ssl": True,
            },
            "shuffle": {
                "enabled":  bool(creds.get("SHUFFLE_URL") and creds.get("SHUFFLE_API_KEY")),
                "base_url": creds.get("SHUFFLE_URL", ""),
                "api_key":  creds.get("SHUFFLE_API_KEY", ""),
            },
        },
        "poll_interval_seconds": 30,
        "dedup_ttl_hours":       24,
        "primary_soar":          "microsoft_sentinel",
        "ml_model_path":         "models/severity_model.pkl",
        "playbook_dir":          "playbooks/definitions",
        "threat_intel": {
            "virustotal": {
                "enabled": bool(creds.get("VIRUSTOTAL_API_KEY")),
                "api_key": creds.get("VIRUSTOTAL_API_KEY", ""),
            },
            "misp": {
                "enabled": bool(creds.get("MISP_URL")),
                "url":     creds.get("MISP_URL", ""),
                "api_key": creds.get("MISP_API_KEY", ""),
            },
            "alienvault_otx": {
                "enabled": bool(creds.get("OTX_API_KEY")),
                "api_key": creds.get("OTX_API_KEY", ""),
            },
        },
    }


async def run(config: dict):
    from orchestrator import SOAROrchestrator

    orch = SOAROrchestrator(config)

    loop = asyncio.get_running_loop()

    def _shutdown(sig):
        log.info("Signal %s received — shutting down", sig.name)
        loop.stop()

    for s in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(s, lambda s=s: _shutdown(s))

    log.info("SOAR Orchestrator started")
    await orch.run()


def main():
    configure_logging()

    import os
    from bootstrap import init_secrets, bootstrap_soar, setup_rotation_handlers

    sm   = init_secrets(os.environ.get("SECRETS_CONFIG"))
    creds = bootstrap_soar(sm)

    config     = build_connector_config(creds)
    connectors = {}   # populated by SOAROrchestrator internals; passed for rotation wiring

    setup_rotation_handlers(sm, connectors)

    asyncio.run(run(config))


if __name__ == "__main__":
    main()
