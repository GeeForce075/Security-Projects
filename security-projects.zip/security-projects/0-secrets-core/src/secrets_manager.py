import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

log = logging.getLogger("secrets")


class SecretBackend(Enum):
    AZURE_KEYVAULT   = "azure_keyvault"
    AWS_SECRETS      = "aws_secretsmanager"
    GCP_SECRET       = "gcp_secretmanager"
    HASHICORP_VAULT  = "hashicorp_vault"
    LOCAL_ENCRYPTED  = "local_encrypted"


@dataclass
class SecretMeta:
    key:          str
    backend:      str
    version:      str       = "latest"
    fetched_at:   float     = field(default_factory=time.monotonic)
    expires_at:   float     = 0.0
    rotation_cb:  Optional[Callable] = field(default=None, repr=False)
    tags:         dict      = field(default_factory=dict)


@dataclass
class _CacheEntry:
    value:      str
    meta:       SecretMeta
    checksum:   str
    pinned:     bool = False   # never evict if True


class SecretsManager:
    """
    Multi-backend secrets manager with in-memory caching, auto-rotation,
    and zero-crash startup guarantees.

    Backends tried in order: env vars → configured vault → local encrypted fallback.
    All values live in memory only — nothing written to disk after initial fetch.
    """

    # Rotation checked every 60s; secrets refreshed when within this window of expiry
    _ROTATION_CHECK_INTERVAL = 60
    _REFRESH_BEFORE_EXPIRY   = 300   # 5 min

    def __init__(self, config: dict):
        self._cfg       = config
        self._cache:    dict[str, _CacheEntry] = {}
        self._lock      = threading.RLock()
        self._backends: dict[str, Any] = {}
        self._rotation_registry: dict[str, list[Callable]] = defaultdict(list)
        self._failed_keys: set[str] = set()
        self._stats = {"hits": 0, "misses": 0, "rotations": 0, "errors": 0}

        self._init_backends()
        self._rotation_thread = threading.Thread(
            target=self._rotation_loop, daemon=True, name="secrets-rotation"
        )
        self._rotation_thread.start()
        log.info("SecretsManager ready — backends: %s", list(self._backends.keys()))

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """
        Fetch secret. Priority: cache → env → vault.
        Returns default (not raises) if unavailable — callers decide how to handle.
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry and not self._is_stale(entry):
                self._stats["hits"] += 1
                return entry.value

        # env var shortcut — useful in dev/test
        env_val = os.environ.get(key) or os.environ.get(key.upper())
        if env_val:
            self._put_cache(key, env_val, backend="env", ttl=0, pinned=False)
            return env_val

        val = self._fetch_from_backends(key)
        if val is not None:
            self._stats["misses"] += 1
            return val

        self._stats["errors"] += 1
        self._failed_keys.add(key)

        if default is not None:
            return default

        log.error("Secret unavailable: %s", key)
        return None

    def require(self, key: str) -> str:
        """Like get() but raises immediately if secret is missing. Use at startup."""
        val = self.get(key)
        if val is None:
            raise RuntimeError(
                f"Required secret '{key}' could not be loaded from any backend. "
                f"Check vault connectivity and IAM permissions."
            )
        return val

    def get_many(self, *keys: str) -> dict[str, Optional[str]]:
        return {k: self.get(k) for k in keys}

    def require_many(self, *keys: str) -> dict[str, str]:
        missing = []
        result  = {}
        for k in keys:
            try:
                result[k] = self.require(k)
            except RuntimeError:
                missing.append(k)
        if missing:
            raise RuntimeError(
                f"Startup aborted — required secrets unavailable: {missing}"
            )
        return result

    def pin(self, key: str):
        """Pin a secret so it's never evicted from cache (e.g. DB connection strings)."""
        with self._lock:
            if key in self._cache:
                self._cache[key].pinned = True

    def on_rotation(self, key: str, callback: Callable[[str, str], None]):
        """
        Register a callback invoked when `key` is rotated.
        Signature: callback(key: str, new_value: str)
        Useful for reconnecting DB pools, refreshing HTTP clients, etc.
        """
        self._rotation_registry[key].append(callback)

    def invalidate(self, key: str):
        with self._lock:
            self._cache.pop(key, None)

    def health(self) -> dict:
        with self._lock:
            stale = [k for k, e in self._cache.items() if self._is_stale(e) and not e.pinned]
        return {
            "backends":    list(self._backends.keys()),
            "cached":      len(self._cache),
            "stale":       len(stale),
            "failed_keys": list(self._failed_keys),
            "stats":       dict(self._stats),
        }

    # ------------------------------------------------------------------
    # Backend initialisation
    # ------------------------------------------------------------------

    def _init_backends(self):
        cfg = self._cfg.get("backends", {})

        if cfg.get("azure_keyvault", {}).get("enabled"):
            try:
                self._backends[SecretBackend.AZURE_KEYVAULT.value] = _AzureKeyVaultBackend(
                    cfg["azure_keyvault"]
                )
                log.info("Backend ready: Azure Key Vault")
            except Exception as exc:
                log.warning("Azure Key Vault backend failed to init: %s", exc)

        if cfg.get("aws_secretsmanager", {}).get("enabled"):
            try:
                self._backends[SecretBackend.AWS_SECRETS.value] = _AWSSecretsBackend(
                    cfg["aws_secretsmanager"]
                )
                log.info("Backend ready: AWS Secrets Manager")
            except Exception as exc:
                log.warning("AWS Secrets Manager backend failed to init: %s", exc)

        if cfg.get("gcp_secretmanager", {}).get("enabled"):
            try:
                self._backends[SecretBackend.GCP_SECRET.value] = _GCPSecretBackend(
                    cfg["gcp_secretmanager"]
                )
                log.info("Backend ready: GCP Secret Manager")
            except Exception as exc:
                log.warning("GCP Secret Manager backend failed to init: %s", exc)

        if cfg.get("hashicorp_vault", {}).get("enabled"):
            try:
                self._backends[SecretBackend.HASHICORP_VAULT.value] = _HashiCorpVaultBackend(
                    cfg["hashicorp_vault"]
                )
                log.info("Backend ready: HashiCorp Vault")
            except Exception as exc:
                log.warning("HashiCorp Vault backend failed to init: %s", exc)

        # Local encrypted store always available as last resort
        local_cfg = cfg.get("local_encrypted", {})
        if local_cfg.get("enabled") or not self._backends:
            try:
                self._backends[SecretBackend.LOCAL_ENCRYPTED.value] = _LocalEncryptedBackend(
                    local_cfg
                )
                log.info("Backend ready: Local encrypted store")
            except Exception as exc:
                log.warning("Local encrypted backend failed: %s", exc)

        if not self._backends:
            log.critical(
                "No secret backends could be initialised — "
                "secrets will fall through to environment variables only"
            )

    # ------------------------------------------------------------------
    # Fetching
    # ------------------------------------------------------------------

    def _fetch_from_backends(self, key: str) -> Optional[str]:
        backend_order = self._cfg.get("backend_priority", list(self._backends.keys()))

        for name in backend_order:
            backend = self._backends.get(name)
            if not backend:
                continue
            try:
                result = backend.fetch(key)
                if result is not None:
                    ttl = self._cfg.get("default_ttl_seconds", 3600)
                    self._put_cache(key, result, backend=name, ttl=ttl)
                    self._failed_keys.discard(key)
                    log.debug("Fetched '%s' from %s", key, name)
                    return result
            except Exception as exc:
                log.warning("Backend '%s' failed fetching '%s': %s", name, key, exc)

        return None

    # ------------------------------------------------------------------
    # Cache management
    # ------------------------------------------------------------------

    def _put_cache(self, key: str, value: str, backend: str, ttl: int, pinned: bool = False):
        meta = SecretMeta(
            key       = key,
            backend   = backend,
            fetched_at= time.monotonic(),
            expires_at= time.monotonic() + ttl if ttl > 0 else 0.0,
        )
        checksum = self._checksum(value)
        with self._lock:
            self._cache[key] = _CacheEntry(
                value    = value,
                meta     = meta,
                checksum = checksum,
                pinned   = pinned,
            )

    def _is_stale(self, entry: _CacheEntry) -> bool:
        if entry.pinned:
            return False
        if entry.meta.expires_at == 0:
            return False
        return time.monotonic() >= entry.meta.expires_at

    @staticmethod
    def _checksum(value: str) -> str:
        return hashlib.sha256(value.encode()).hexdigest()[:16]

    # ------------------------------------------------------------------
    # Rotation loop (runs in background thread)
    # ------------------------------------------------------------------

    def _rotation_loop(self):
        while True:
            try:
                time.sleep(self._ROTATION_CHECK_INTERVAL)
                self._check_rotations()
            except Exception as exc:
                log.error("Rotation loop error: %s", exc)

    def _check_rotations(self):
        with self._lock:
            candidates = [
                (k, e) for k, e in self._cache.items()
                if e.meta.expires_at > 0
                and time.monotonic() >= e.meta.expires_at - self._REFRESH_BEFORE_EXPIRY
                and not e.pinned
            ]

        for key, old_entry in candidates:
            try:
                new_val = self._fetch_from_backends(key)
                if new_val is None:
                    log.warning("Rotation failed for '%s' — keeping old value", key)
                    continue

                new_checksum = self._checksum(new_val)
                if new_checksum == old_entry.checksum:
                    # Value unchanged — just push the TTL forward
                    with self._lock:
                        if key in self._cache:
                            ttl = self._cfg.get("default_ttl_seconds", 3600)
                            self._cache[key].meta.expires_at = time.monotonic() + ttl
                    continue

                # Value actually changed — fire callbacks
                log.info("Secret rotated: %s", key)
                self._stats["rotations"] += 1

                for cb in self._rotation_registry.get(key, []):
                    try:
                        cb(key, new_val)
                    except Exception as exc:
                        log.error("Rotation callback failed for '%s': %s", key, exc)

            except Exception as exc:
                log.error("Rotation check error for '%s': %s", key, exc)

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def evict_stale(self):
        with self._lock:
            stale = [k for k, e in self._cache.items() if self._is_stale(e)]
            for k in stale:
                del self._cache[k]
        if stale:
            log.debug("Evicted %d stale cache entries", len(stale))
        return len(stale)

    def __repr__(self):
        return (
            f"SecretsManager(backends={list(self._backends.keys())}, "
            f"cached={len(self._cache)}, failed={len(self._failed_keys)})"
        )
