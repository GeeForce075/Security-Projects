import logging
import sys
import time
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("secrets.health")


@dataclass
class CheckResult:
    key:     str
    ok:      bool
    backend: str  = ""
    latency: float = 0.0
    error:   str  = ""


@dataclass
class ValidationReport:
    passed:   list[CheckResult] = field(default_factory=list)
    failed:   list[CheckResult] = field(default_factory=list)
    warnings: list[str]         = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return len(self.failed) == 0

    def print_summary(self):
        total = len(self.passed) + len(self.failed)
        print(f"\n{'='*60}")
        print(f"  Secrets Validation — {len(self.passed)}/{total} OK")
        print(f"{'='*60}")

        if self.passed:
            print("\n  ✓ Available:")
            for r in self.passed:
                print(f"      {r.key:<40} [{r.backend}]  {r.latency*1000:.0f}ms")

        if self.failed:
            print("\n  ✗ MISSING / UNREACHABLE:")
            for r in self.failed:
                print(f"      {r.key:<40} {r.error}")

        if self.warnings:
            print("\n  ⚠ Warnings:")
            for w in self.warnings:
                print(f"      {w}")

        print(f"\n{'='*60}\n")


class StartupValidator:
    """
    Run before the app starts accepting connections.
    Checks all required secrets are reachable and optionally validates their format.
    Exits the process cleanly on failure rather than crashing mid-operation.
    """

    def __init__(self, secrets_manager, config: dict):
        self._sm   = secrets_manager
        self._cfg  = config

    def validate(self, required_keys: list, optional_keys: list = None) -> ValidationReport:
        """
        Validate all required and optional secrets.
        Blocks until results are in. Call this during __main__ before starting servers.
        """
        report = ValidationReport()
        optional_keys = optional_keys or []

        all_checks = [
            (k, True) for k in required_keys
        ] + [
            (k, False) for k in optional_keys
        ]

        for key, is_required in all_checks:
            result = self._check_key(key)

            if result.ok:
                report.passed.append(result)
            else:
                if is_required:
                    report.failed.append(result)
                else:
                    report.warnings.append(
                        f"Optional secret '{key}' unavailable — "
                        f"related features will be disabled"
                    )

        # Extra sanity checks
        self._check_backend_health(report)
        self._check_cert_expiry(report)

        return report

    def validate_or_exit(self, required_keys: list, optional_keys: list = None):
        """
        Convenience wrapper. Prints report and calls sys.exit(1) on failure.
        Use in __main__ before starting anything.
        """
        report = self.validate(required_keys, optional_keys)
        report.print_summary()

        if not report.ok:
            log.critical(
                "Startup validation failed — %d required secrets unavailable. "
                "Refusing to start.", len(report.failed)
            )
            sys.exit(1)

        log.info(
            "Startup validation passed — %d secrets loaded, %d warnings",
            len(report.passed), len(report.warnings)
        )
        return report

    def _check_key(self, key: str) -> CheckResult:
        t0 = time.monotonic()
        try:
            val     = self._sm.get(key)
            elapsed = time.monotonic() - t0
            if val is None:
                return CheckResult(key=key, ok=False, latency=elapsed,
                                   error="Not found in any backend")

            backend = self._sm._cache.get(key)
            bname   = backend.meta.backend if backend else "env"

            # Format validators
            fmt_error = self._validate_format(key, val)
            if fmt_error:
                return CheckResult(key=key, ok=False, latency=elapsed,
                                   error=f"Format invalid: {fmt_error}")

            return CheckResult(key=key, ok=True, backend=bname, latency=elapsed)

        except Exception as exc:
            return CheckResult(key=key, ok=False, error=str(exc),
                               latency=time.monotonic() - t0)

    def _validate_format(self, key: str, value: str) -> Optional[str]:
        """Basic format validation for known secret types."""
        key_lower = key.lower()

        if not value or not value.strip():
            return "empty value"

        if "url" in key_lower or "endpoint" in key_lower:
            if not (value.startswith("http://") or value.startswith("https://")):
                return "expected URL (http:// or https://)"

        if "client_id" in key_lower or "app_id" in key_lower:
            import re
            # Azure GUIDs
            if re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
                        value, re.I):
                return None
            # AWS format (20-char alphanumeric starting with AKIA)
            if re.match(r"^[A-Z0-9]{20}$", value):
                return None

        if "subscription_id" in key_lower or "tenant_id" in key_lower:
            import re
            if not re.match(
                r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
                value, re.I
            ):
                return "expected UUID format"

        if "api_key" in key_lower or "api_token" in key_lower:
            if len(value) < 16:
                return "suspiciously short for an API key"

        return None

    def _check_backend_health(self, report: ValidationReport):
        health = self._sm.health()
        if health["failed_keys"]:
            report.warnings.append(
                f"Backends returned errors for: {health['failed_keys']}"
            )
        if not health["backends"]:
            report.warnings.append(
                "No vault backends active — running on environment variables only"
            )

    def _check_cert_expiry(self, report: ValidationReport):
        """Check TLS cert expiry for configured endpoints."""
        import ssl
        import socket
        from datetime import datetime, timezone

        endpoints = self._cfg.get("health_check_endpoints", [])
        for endpoint in endpoints:
            try:
                host, _, port = endpoint.partition(":")
                port          = int(port) if port else 443
                ctx           = ssl.create_default_context()
                with socket.create_connection((host, port), timeout=5) as sock:
                    with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                        cert      = ssock.getpeercert()
                        not_after = datetime.strptime(
                            cert["notAfter"], "%b %d %H:%M:%S %Y %Z"
                        ).replace(tzinfo=timezone.utc)
                        days_left = (not_after - datetime.now(timezone.utc)).days
                        if days_left < 30:
                            report.warnings.append(
                                f"TLS cert for {host} expires in {days_left} days"
                            )
            except Exception as exc:
                report.warnings.append(f"Could not check TLS cert for {endpoint}: {exc}")
