"""
Platform credential bootstrap.
Import this in each project's __main__ before instantiating any connectors.
Handles secret loading, validation, rotation registration, and graceful failure.
"""

import logging
import os
import sys
from pathlib import Path
from typing import Optional

log = logging.getLogger("secrets.bootstrap")


def load_config(config_path: str = None) -> dict:
    import yaml

    paths = [
        config_path,
        os.environ.get("SECRETS_CONFIG"),
        "config/secrets.yaml",
        "/etc/soar/secrets.yaml",
        str(Path.home() / ".soar" / "secrets.yaml"),
    ]

    for p in paths:
        if p and Path(p).exists():
            with open(p) as f:
                cfg = yaml.safe_load(f)
                log.info("Secrets config loaded from %s", p)
                return cfg or {}

    log.warning("No secrets config found — using env vars and defaults")
    return {}


def init_secrets(config_path: str = None):
    """
    Main entry point. Call once at startup.
    Returns a fully initialised SecretsManager.
    """
    from secrets_manager import SecretsManager

    cfg = load_config(config_path)
    sm  = SecretsManager(cfg)
    return sm


def bootstrap_soar(sm, skip_validation: bool = False) -> dict:
    """
    Load and validate all credentials needed by the SOAR orchestration engine.
    Returns a credentials dict passed directly to connector constructors.
    """
    from health.startup_validator import StartupValidator

    required = [
        "AZURE_SUBSCRIPTION_ID",
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
        "SENTINEL_WORKSPACE_NAME",
        "SENTINEL_WORKSPACE_ID",
    ]

    optional = [
        "SPLUNK_SOAR_URL",
        "SPLUNK_SOAR_API_TOKEN",
        "CORTEX_XSOAR_URL",
        "CORTEX_XSOAR_API_KEY",
        "SHUFFLE_URL",
        "SHUFFLE_API_KEY",
        "VIRUSTOTAL_API_KEY",
        "MISP_URL",
        "MISP_API_KEY",
        "OTX_API_KEY",
        "PAGERDUTY_API_KEY",
    ]

    if not skip_validation:
        validator = StartupValidator(sm, cfg={})
        report    = validator.validate_or_exit(required, optional)

    creds = sm.get_many(*required, *optional)

    # Pin long-lived infra credentials so they're never evicted mid-operation
    for k in ["AZURE_SUBSCRIPTION_ID", "AZURE_TENANT_ID", "AZURE_CLIENT_ID"]:
        sm.pin(k)

    return creds


def bootstrap_ml_detection(sm, skip_validation: bool = False) -> dict:
    """Credentials for the ML threat detection engine."""
    from health.startup_validator import StartupValidator

    required = []   # ML engine reads network flows; credentials are optional enrichment

    optional = [
        "CROWDSTRIKE_CLIENT_ID",
        "CROWDSTRIKE_CLIENT_SECRET",
        "CROWDSTRIKE_BASE_URL",
        "SENTINELONE_API_KEY",
        "SENTINELONE_MANAGEMENT_URL",
        "ELASTIC_API_KEY",
        "ELASTIC_ENDPOINT",
        "QRADAR_SEC_TOKEN",
        "QRADAR_HOST",
    ]

    if not skip_validation:
        validator = StartupValidator(sm, cfg={})
        validator.validate_or_exit(required, optional)

    return sm.get_many(*optional)


def bootstrap_vuln_aggregator(sm, skip_validation: bool = False) -> dict:
    """Credentials for the vulnerability aggregation engine."""
    from health.startup_validator import StartupValidator

    required = []   # At least one scanner must be configured

    optional = [
        "NESSUS_BASE_URL",
        "NESSUS_ACCESS_KEY",
        "NESSUS_SECRET_KEY",
        "OPENVAS_HOST",
        "OPENVAS_USERNAME",
        "OPENVAS_PASSWORD",
        "QUALYS_API_URL",
        "QUALYS_USERNAME",
        "QUALYS_PASSWORD",
        "RAPID7_BASE_URL",
        "RAPID7_API_KEY",
        "AWS_PROWLER_ACCESS_KEY_ID",
        "AWS_PROWLER_SECRET_ACCESS_KEY",
        "AZURE_PROWLER_CLIENT_ID",
        "AZURE_PROWLER_CLIENT_SECRET",
    ]

    if not skip_validation:
        validator = StartupValidator(sm, cfg={})
        report    = validator.validate(required, optional)
        report.print_summary()

        # Require at least one scanner credential
        scanner_sets = [
            ("NESSUS_ACCESS_KEY", "NESSUS_SECRET_KEY"),
            ("QUALYS_USERNAME", "QUALYS_PASSWORD"),
            ("RAPID7_API_KEY",),
            ("OPENVAS_USERNAME", "OPENVAS_PASSWORD"),
        ]
        configured = any(
            all(sm.get(k) for k in s)
            for s in scanner_sets
        )
        if not configured:
            log.critical(
                "No vulnerability scanner credentials configured. "
                "Configure at least one of: Nessus, OpenVAS, Qualys, Rapid7."
            )
            sys.exit(1)

    return sm.get_many(*optional)


def bootstrap_identity_monitor(sm, skip_validation: bool = False) -> dict:
    """Credentials for the identity threat monitor."""
    from health.startup_validator import StartupValidator

    required = [
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
    ]

    optional = [
        "OKTA_ORG_URL",
        "OKTA_API_TOKEN",
        "PING_ENVIRONMENT_ID",
        "PING_CLIENT_ID",
        "PING_CLIENT_SECRET",
        "KEYCLOAK_URL",
        "KEYCLOAK_REALM",
        "KEYCLOAK_CLIENT_ID",
        "KEYCLOAK_CLIENT_SECRET",
        "AD_LDAP_URL",
        "AD_BIND_DN",
        "AD_BIND_PASSWORD",
    ]

    if not skip_validation:
        validator = StartupValidator(sm, cfg={})
        validator.validate_or_exit(required, optional)

    creds = sm.get_many(*required, *optional)
    for k in required:
        sm.pin(k)

    return creds


def setup_rotation_handlers(sm, connectors: dict):
    """
    Wire up rotation callbacks so live connectors reconnect
    automatically when credentials rotate — no downtime, no restart.
    """
    from rotation.handlers import RotationHandler, ScheduledRotationEnforcer

    rh      = RotationHandler(sm)
    enforcer = ScheduledRotationEnforcer(sm)

    # Enforce rotation schedules
    enforcer.enforce("AZURE_CLIENT_SECRET",     max_age_days=90)
    enforcer.enforce("SPLUNK_SOAR_API_TOKEN",   max_age_days=90)
    enforcer.enforce("CORTEX_XSOAR_API_KEY",    max_age_days=90)
    enforcer.enforce("NESSUS_ACCESS_KEY",        max_age_days=90)
    enforcer.enforce("RAPID7_API_KEY",           max_age_days=90)
    enforcer.enforce("OKTA_API_TOKEN",           max_age_days=90)
    enforcer.enforce("AD_BIND_PASSWORD",         max_age_days=60)
    enforcer.enforce("VIRUSTOTAL_API_KEY",       max_age_days=180)

    # Wire Sentinel rebuild on Azure client secret rotation
    if "sentinel" in connectors:
        rh.register_azure_credential(
            key        = "AZURE_CLIENT_SECRET",
            rebuild_fn = lambda new_cred: setattr(connectors["sentinel"], "credential", new_cred),
        )

    # Wire Splunk SOAR HTTP session rebuild
    if "splunk_soar" in connectors:
        rh.register_http_client(
            key        = "SPLUNK_SOAR_API_TOKEN",
            rebuild_fn = lambda new_token: connectors["splunk_soar"].rebuild_session(new_token),
        )

    # Wire Okta rebuild
    if "okta" in connectors:
        rh.register_http_client(
            key        = "OKTA_API_TOKEN",
            rebuild_fn = lambda new_token: connectors["okta"].rebuild_session(new_token),
        )

    log.info("Rotation handlers registered for %d connectors", len(connectors))
    return enforcer
