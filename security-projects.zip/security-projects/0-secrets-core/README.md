# Secrets Core

Credential management layer shared across all 5 security platform projects.
Loads secrets from vault at startup, caches in memory, rotates automatically,
and rebuilds live connections when credentials change — no downtime, no restarts.

---

## How it works

```
App starts
    │
    ▼
init_secrets()          Load config, connect to vault backends
    │
    ▼
bootstrap_<project>()   Fetch required secrets, validate formats, pin critical keys
    │
    ├── All required secrets present?  → continue
    └── Any missing?                   → print clear error, exit(1)
    │
    ▼
setup_rotation_handlers()   Register callbacks for each connector
    │
    ▼
App runs normally
    │
    ▼ (background thread, every 60s)
_rotation_loop()        Check for secrets near expiry or past scheduled rotation age
    │
    ├── Value unchanged?  → push TTL forward
    └── Value changed?    → call registered callbacks (rebuild connector, reconnect pool, etc.)
```

---

## Backends (tried in order)

| Backend | Auth method | Best for |
|---------|-------------|----------|
| Azure Key Vault | Workload Identity / Managed Identity / SP | Azure / AKS |
| AWS Secrets Manager | IRSA / IAM role assumption | AWS / EKS |
| GCP Secret Manager | Workload Identity / ADC | GCP / GKE |
| HashiCorp Vault | Kubernetes auth / AppRole / token | Multi-cloud / on-prem |
| Local encrypted | AES-256-GCM (Fernet) | Air-gapped / dev only |
| Environment vars | — | Dev / CI override |

---

## Quick start

```bash
# Generate a local encrypted store master key (dev/air-gapped only)
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
export SECRETS_MASTER_KEY=<output>

# Store a secret locally
python -c "
from src.vault.backends import _LocalEncryptedBackend
b = _LocalEncryptedBackend({'store_path': '.secrets.enc'})
b.store('AZURE_CLIENT_SECRET', 'your-value-here')
"

# Run with Azure Key Vault
export AZURE_TENANT_ID=...
export AZURE_CLIENT_ID=...
export AZURE_CLIENT_SECRET=...   # only needed to bootstrap if not using managed identity
python src/main.py
```

---

## Startup output

```
============================================================
  Secrets Validation — 8/10 OK
============================================================

  ✓ Available:
      AZURE_SUBSCRIPTION_ID            [azure_keyvault]  42ms
      AZURE_TENANT_ID                  [azure_keyvault]  38ms
      AZURE_CLIENT_ID                  [azure_keyvault]  41ms
      AZURE_CLIENT_SECRET              [azure_keyvault]  39ms
      SENTINEL_WORKSPACE_NAME          [azure_keyvault]  40ms
      SENTINEL_WORKSPACE_ID            [azure_keyvault]  43ms
      SPLUNK_SOAR_URL                  [azure_keyvault]  37ms
      SPLUNK_SOAR_API_TOKEN            [azure_keyvault]  44ms

  ⚠ Warnings:
      Optional secret 'SHUFFLE_URL' unavailable — related features will be disabled
      Optional secret 'OTX_API_KEY' unavailable — related features will be disabled

============================================================
```

---

## Rotation schedules (enforced automatically)

| Secret | Max age |
|--------|---------|
| AZURE_CLIENT_SECRET | 90 days |
| AD_BIND_PASSWORD | 60 days |
| SPLUNK_SOAR_API_TOKEN | 90 days |
| VIRUSTOTAL_API_KEY | 180 days |
| SECRETS_MASTER_KEY | 365 days |

When a secret exceeds its max age the cache entry is invalidated,
the vault is re-queried, and all registered rotation callbacks fire.

---

## Files

```
src/
  secrets_manager.py      Core manager with caching, dedup, rotation loop
  bootstrap.py            Per-project credential loading and validation
  main.py                 Crash-safe SOAR startup entry point
  vault/
    backends.py           Azure KV / AWS SM / GCP SM / HashiCorp / Local
  rotation/
    handlers.py           DB pool, HTTP client, Azure/AWS connector rebuilders
  health/
    startup_validator.py  Pre-flight checks, format validation, cert expiry
config/
  secrets.yaml            Backend config + full secret key registry
```
