"""
LSTM Beacon Detector
Detects C2 beaconing behaviour by learning the temporal pattern of
connection sequences per (src_ip, dest_ip) pair.
Beacons appear as highly regular / periodic connection intervals.
"""

import logging
from typing import Optional

import numpy as np
import pandas as pd

logger = logging.getLogger("ml.detectors.lstm_beacon")


class LSTMBeaconDetector:
    """
    Two-stage beacon detector:
    1. Statistical pre-filter (jitter, periodicity, connection regularity)
    2. LSTM sequence model for precise beacon classification

    Designed for connections data indexed by (src_ip, dest_ip, dest_port).
    """

    def __init__(
        self,
        sequence_length: int   = 60,    # Time-steps (e.g., 60 observations)
        threshold:       float = 0.80,  # Beacon confidence cutoff
        model_path:      str   = "models/lstm_beacon.keras",
        min_connections: int   = 10,    # Minimum connections before scoring
    ):
        self.sequence_length = sequence_length
        self.threshold       = threshold
        self.model_path      = model_path
        self.min_connections = min_connections
        self._model          = None
        self._load_model()

    # ------------------------------------------------------------------
    # Model management
    # ------------------------------------------------------------------

    def _load_model(self):
        import os
        if not os.path.isfile(self.model_path):
            logger.info("LSTM beacon model not found at %s — will use statistical detector only", self.model_path)
            return
        try:
            import tensorflow as tf
            self._model = tf.keras.models.load_model(self.model_path)
            logger.info("LSTM beacon model loaded from %s", self.model_path)
        except Exception as exc:
            logger.warning("Could not load LSTM model: %s", exc)

    def build_and_train(self, training_flows: pd.DataFrame, epochs: int = 30):
        """
        Build and train the LSTM model.
        training_flows must have columns: [src_ip, dest_ip, dest_port, timestamp]
        and labels: is_beacon (bool).
        """
        try:
            import tensorflow as tf
            from tensorflow.keras import layers, Model

            sequences, labels = self._prepare_sequences(training_flows)
            if sequences is None:
                return

            # Build LSTM model
            inp = tf.keras.Input(shape=(self.sequence_length, sequences.shape[2]))
            x   = layers.LSTM(64, return_sequences=True)(inp)
            x   = layers.Dropout(0.2)(x)
            x   = layers.LSTM(32)(x)
            x   = layers.Dense(16, activation="relu")(x)
            out = layers.Dense(1, activation="sigmoid")(x)

            model = Model(inputs=inp, outputs=out)
            model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy", "AUC"])
            model.summary()

            model.fit(
                sequences, labels,
                epochs          = epochs,
                batch_size      = 64,
                validation_split= 0.15,
                callbacks       = [
                    tf.keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True),
                    tf.keras.callbacks.ModelCheckpoint(self.model_path, save_best_only=True),
                ]
            )
            self._model = model
            logger.info("LSTM beacon model trained and saved to %s", self.model_path)

        except ImportError:
            logger.error("TensorFlow not installed — cannot train LSTM beacon model")

    # ------------------------------------------------------------------
    # Detection
    # ------------------------------------------------------------------

    def detect(self, df: pd.DataFrame) -> list[dict]:
        """
        Analyse connection sequences per (src_ip, dest_ip) pair.
        Returns list of beacon signal dicts.
        """
        if "timestamp" not in df.columns:
            return []

        df      = df.copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
        df      = df.dropna(subset=["timestamp"])
        signals = []

        group_cols = [c for c in ["src_ip", "dest_ip", "dest_port"] if c in df.columns]
        if len(group_cols) < 2:
            return []

        for key, group in df.groupby(group_cols):
            if len(group) < self.min_connections:
                continue

            group   = group.sort_values("timestamp")
            intervals = group["timestamp"].diff().dt.total_seconds().dropna().values

            if len(intervals) < 5:
                continue

            # Stage 1: Statistical beacon score
            stat_score = self._statistical_beacon_score(intervals)

            # Stage 2: LSTM score (if model available)
            if self._model is not None and stat_score > 0.4:
                lstm_score = self._lstm_score(intervals)
                final_score = 0.4 * stat_score + 0.6 * lstm_score
            else:
                final_score = stat_score

            if final_score >= self.threshold:
                src  = key[0] if isinstance(key, tuple) else key
                dst  = key[1] if isinstance(key, tuple) and len(key) > 1 else ""
                port = key[2] if isinstance(key, tuple) and len(key) > 2 else 0

                signals.append({
                    "source_ip":   str(src),
                    "dest_ip":     str(dst),
                    "dest_port":   int(port),
                    "confidence":  round(float(final_score), 3),
                    "explanation": self._explain(intervals, stat_score),
                    "conn_count":  len(group),
                    "avg_interval_s": float(np.mean(intervals)),
                })

        logger.info("LSTM Beacon: %d beacon signals detected", len(signals))
        return signals

    # ------------------------------------------------------------------
    # Statistical beacon scoring
    # ------------------------------------------------------------------

    def _statistical_beacon_score(self, intervals: np.ndarray) -> float:
        """
        Score regularity of connection intervals.
        Lower coefficient of variation → higher beacon score.
        """
        if len(intervals) < 3:
            return 0.0

        mean_i  = np.mean(intervals)
        std_i   = np.std(intervals)

        if mean_i <= 0:
            return 0.0

        # Coefficient of variation: lower = more regular = more likely beacon
        cv      = std_i / mean_i

        # Periodicity check via autocorrelation
        if len(intervals) >= 10:
            autocorr = np.corrcoef(intervals[:-1], intervals[1:])[0, 1]
        else:
            autocorr = 0.0

        # Jitter tolerance: real beacons have some jitter (cv 0.01–0.25)
        regularity_score = max(0.0, 1.0 - cv) if cv < 1.0 else 0.0
        period_score     = max(0.0, float(autocorr))

        # Penalise very high-frequency (< 1s) or very low-frequency (> 1 hour)
        freq_penalty = 0.0
        if mean_i < 1.0 or mean_i > 3600:
            freq_penalty = 0.3

        score = 0.6 * regularity_score + 0.4 * period_score - freq_penalty
        return max(0.0, min(1.0, score))

    def _lstm_score(self, intervals: np.ndarray) -> float:
        """Run interval sequence through LSTM for beacon probability."""
        try:
            seq = self._normalise_intervals(intervals)
            if seq is None:
                return 0.0
            pred = self._model.predict(seq[np.newaxis, ...], verbose=0)
            return float(pred[0][0])
        except Exception as exc:
            logger.debug("LSTM inference error: %s", exc)
            return 0.0

    def _normalise_intervals(self, intervals: np.ndarray) -> Optional[np.ndarray]:
        """Pad/truncate to sequence_length and normalise."""
        n   = self.sequence_length
        arr = intervals[-n:] if len(intervals) >= n else np.pad(intervals, (n - len(intervals), 0))
        if arr.max() == 0:
            return None
        arr = arr / arr.max()
        return arr.reshape(n, 1).astype(np.float32)

    def _explain(self, intervals: np.ndarray, score: float) -> str:
        mean_i = np.mean(intervals)
        std_i  = np.std(intervals)
        cv     = std_i / (mean_i + 1e-9)
        return (
            f"Beacon score={score:.2f} | "
            f"avg_interval={mean_i:.1f}s | "
            f"std={std_i:.1f}s | "
            f"CoV={cv:.3f} | "
            f"connections={len(intervals)+1}"
        )

    # ------------------------------------------------------------------
    # Sequence preparation for training
    # ------------------------------------------------------------------

    def _prepare_sequences(self, df: pd.DataFrame):
        """Build fixed-length interval sequences and labels for training."""
        group_cols = [c for c in ["src_ip", "dest_ip", "dest_port"] if c in df.columns]
        sequences  = []
        labels     = []

        for _, group in df.groupby(group_cols):
            group   = group.sort_values("timestamp")
            intervals = group["timestamp"].diff().dt.total_seconds().dropna().values
            label   = int(group["is_beacon"].iloc[-1]) if "is_beacon" in group.columns else 0

            seq = self._normalise_intervals(intervals)
            if seq is not None:
                sequences.append(seq)
                labels.append(label)

        if not sequences:
            logger.warning("No valid sequences for LSTM training")
            return None, None

        return np.array(sequences), np.array(labels)
