"""
Isolation Forest Anomaly Detector
Trained on your network's baseline traffic profile to flag statistical outliers.
Supports incremental re-training as new normal traffic is observed.
"""

import logging
import os
import pickle
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

logger = logging.getLogger("ml.detectors.isolation_forest")

FEATURE_COLS = [
    "unique_dests", "unique_ports", "total_bytes_out", "total_bytes_in",
    "avg_bytes_out", "max_bytes_out", "flow_count", "avg_duration_ms",
    "bytes_ratio", "flows_per_min",
]


class IsolationForestDetector:
    """
    Wraps sklearn IsolationForest with:
    - Automatic model persistence
    - Incremental partial-fit via reservoir sampling of seen data
    - SHAP-based feature importance for explainability
    """

    def __init__(
        self,
        contamination:  float = 0.01,
        n_estimators:   int   = 200,
        max_features:   float = 0.8,
        model_path:     str   = "models/iso_forest.pkl",
        retrain_every:  int   = 10_000,   # records
    ):
        self.contamination = contamination
        self.n_estimators  = n_estimators
        self.max_features  = max_features
        self.model_path    = model_path
        self.retrain_every = retrain_every

        self.model:   Optional[IsolationForest] = None
        self.scaler:  Optional[StandardScaler]  = None
        self._seen:   int                        = 0
        self._buffer: list[np.ndarray]           = []

        self._load_or_init()

    # ------------------------------------------------------------------
    # Model management
    # ------------------------------------------------------------------

    def _load_or_init(self):
        if os.path.isfile(self.model_path):
            try:
                with open(self.model_path, "rb") as f:
                    bundle       = pickle.load(f)
                    self.model   = bundle["model"]
                    self.scaler  = bundle["scaler"]
                    self._seen   = bundle.get("seen", 0)
                logger.info("IsolationForest model loaded (%d training samples)", self._seen)
                return
            except Exception as exc:
                logger.warning("Could not load IsolationForest model: %s", exc)

        logger.info("Initialising new IsolationForest model")
        self.model  = IsolationForest(
            contamination = self.contamination,
            n_estimators  = self.n_estimators,
            max_features  = self.max_features,
            n_jobs        = -1,
            random_state  = 42,
        )
        self.scaler = StandardScaler()

    def _save(self):
        os.makedirs(os.path.dirname(self.model_path) or ".", exist_ok=True)
        with open(self.model_path, "wb") as f:
            pickle.dump({"model": self.model, "scaler": self.scaler, "seen": self._seen}, f)
        logger.debug("IsolationForest model saved")

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def fit(self, df: pd.DataFrame):
        """Full (re-)training on a DataFrame of flow records."""
        X = self._prepare_features(df)
        if X is None or len(X) < 100:
            logger.warning("Not enough data to train IsolationForest (need ≥100 rows)")
            return

        self.scaler = StandardScaler()
        X_scaled    = self.scaler.fit_transform(X)
        self.model.fit(X_scaled)
        self._seen  = len(X)
        self._save()
        logger.info("IsolationForest trained on %d flow records", self._seen)

    def partial_update(self, df: pd.DataFrame):
        """
        Buffer new data and retrain when buffer reaches retrain_every.
        Simulates incremental learning for IsolationForest.
        """
        X = self._prepare_features(df)
        if X is None:
            return

        self._buffer.extend(X.tolist())
        if len(self._buffer) >= self.retrain_every:
            X_new = np.array(self._buffer)
            self.scaler.fit(X_new)
            X_scaled = self.scaler.transform(X_new)
            self.model.fit(X_scaled)
            self._seen  += len(self._buffer)
            self._buffer = []
            self._save()
            logger.info("IsolationForest retrained on %d cumulative records", self._seen)

    # ------------------------------------------------------------------
    # Detection
    # ------------------------------------------------------------------

    def detect(self, df: pd.DataFrame, threshold_score: float = -0.1) -> pd.DataFrame:
        """
        Return rows predicted as anomalies.
        IsolationForest.score_samples() returns negative values for anomalies.
        threshold_score: lower = stricter. -0.0 to -0.5 typical range.
        """
        X = self._prepare_features(df)
        if X is None or self.model is None or self._seen == 0:
            return pd.DataFrame()

        try:
            X_scaled        = self.scaler.transform(X)
            raw_scores      = self.model.score_samples(X_scaled)
            # Normalise to [0,1] anomaly score: higher = more anomalous
            min_s, max_s    = raw_scores.min(), raw_scores.max()
            norm_scores     = 1.0 - (raw_scores - min_s) / max(max_s - min_s, 1e-9)

            df = df.copy()
            df["anomaly_score"] = norm_scores
            df["is_anomaly"]    = raw_scores < threshold_score

            anomalies = df[df["is_anomaly"]].copy()
            logger.info(
                "IsolationForest: %d/%d flows flagged as anomalies",
                len(anomalies), len(df)
            )
            return anomalies

        except Exception as exc:
            logger.error("IsolationForest detection error: %s", exc)
            return pd.DataFrame()

    # ------------------------------------------------------------------
    # Feature preparation
    # ------------------------------------------------------------------

    def _prepare_features(self, df: pd.DataFrame) -> Optional[np.ndarray]:
        available = [c for c in FEATURE_COLS if c in df.columns]
        if len(available) < 3:
            logger.debug("Insufficient feature columns: %s", available)
            return None

        X = df[available].fillna(0).replace([np.inf, -np.inf], 0)
        return X.values.astype(np.float32)

    # ------------------------------------------------------------------
    # Explainability
    # ------------------------------------------------------------------

    def explain_anomaly(self, row: pd.Series) -> dict:
        """Return per-feature anomaly contribution estimates."""
        available = [c for c in FEATURE_COLS if c in row.index]
        values    = {col: float(row[col]) for col in available}

        # Heuristic: compare each feature to known typical ranges
        TYPICAL_RANGES = {
            "unique_dests":   (1, 20),
            "unique_ports":   (1, 10),
            "total_bytes_out":(100, 5_000_000),
            "bytes_ratio":    (0.1, 5.0),
            "flows_per_min":  (0.1, 100),
            "flow_count":     (1, 500),
        }
        contributors = {}
        for feat, val in values.items():
            if feat in TYPICAL_RANGES:
                lo, hi = TYPICAL_RANGES[feat]
                if val < lo or val > hi:
                    contributors[feat] = {"value": val, "typical_range": f"{lo}–{hi}", "anomalous": True}
            else:
                contributors[feat] = {"value": val}

        return contributors
