"""
ML-Based Network Anomaly Detection Engine
Processes network flow data (from Zeek/Suricata/Wireshark/Nmap scans) and host
telemetry to detect: port scans, lateral movement, C2 beaconing, data exfiltration,
brute force, and protocol anomalies using unsupervised and supervised ML.

Integrates with:
  - CrowdStrike Falcon / SentinelOne (endpoint telemetry)
  - Palo Alto / Fortinet / Cisco ASA (firewall logs)
  - Microsoft Sentinel / Splunk / Elastic SIEM (log forwarding)
  - Wireshark PCAP files (offline analysis)
  - Kubernetes (containerised deployment via k8s/)
"""

import asyncio
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

from models.isolation_forest import IsolationForestDetector
from models.autoencoder import AutoencoderDetector
from models.lstm_beacon import LSTMBeaconDetector
from ingestion.flow_processor import FlowProcessor
from ingestion.endpoint_processor import EndpointProcessor
from api.alert_emitter import AlertEmitter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger("ml.threat_detection")


@dataclass
class ThreatSignal:
    signal_id:      str
    signal_type:    str        # e.g. "port_scan", "beaconing", "lateral_movement"
    confidence:     float      # 0.0–1.0
    source_ip:      str
    dest_ip:        str        = ""
    dest_port:      int        = 0
    protocol:       str        = ""
    bytes_out:      int        = 0
    bytes_in:       int        = 0
    packet_count:   int        = 0
    timestamp:      str        = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    raw_features:   dict       = field(default_factory=dict)
    explanation:    str        = ""
    mitre_tactic:   str        = ""
    mitre_technique:str        = ""


class ThreatDetectionEngine:
    """
    Orchestrates multiple ML detectors over network flow and endpoint data.
    Each detector is independently tuned and operates on feature-engineered windows.
    """

    DETECTOR_CONFIG = {
        "isolation_forest": {
            "contamination": 0.01,
            "n_estimators":  200,
            "max_features":  0.8,
        },
        "autoencoder": {
            "encoding_dim":   16,
            "epochs":         50,
            "batch_size":     256,
            "threshold_pct":  95,     # anomaly if reconstruction error > 95th pct
        },
        "lstm_beacon": {
            "sequence_length": 60,    # 60 time-steps (e.g. 60 min of connections)
            "threshold":       0.80,  # beacon confidence
        },
    }

    # MITRE ATT&CK mapping for each detection type
    MITRE_MAP = {
        "port_scan":         ("TA0007", "T1046"),   # Discovery / Network Service Scanning
        "lateral_movement":  ("TA0008", "T1021"),   # Lateral Movement / Remote Services
        "beaconing":         ("TA0011", "T1071"),   # C2 / Application Layer Protocol
        "exfiltration":      ("TA0010", "T1048"),   # Exfiltration over Alternative Protocol
        "brute_force":       ("TA0006", "T1110"),   # Credential Access / Brute Force
        "dns_tunneling":     ("TA0011", "T1071.004"),# C2 / DNS
        "protocol_anomaly":  ("TA0005", "T1036"),   # Defense Evasion / Masquerading
        "new_connection":    ("TA0001", "T1078"),   # Initial Access / Valid Accounts
    }

    def __init__(self, config: dict):
        self.config    = config
        self.window_s  = config.get("analysis_window_seconds", 300)
        self.emitter   = AlertEmitter(config.get("emitter", {}))

        # Initialise detectors
        self.iso_forest = IsolationForestDetector(**self.DETECTOR_CONFIG["isolation_forest"])
        self.autoenc    = AutoencoderDetector(**self.DETECTOR_CONFIG["autoencoder"])
        self.lstm       = LSTMBeaconDetector(**self.DETECTOR_CONFIG["lstm_beacon"])

        # Data processors
        self.flow_proc     = FlowProcessor(config.get("flow", {}))
        self.endpoint_proc = EndpointProcessor(config.get("endpoint", {}))

        self._flow_buffer: list[dict]     = []
        self._endpoint_buffer: list[dict] = []

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    async def run(self):
        logger.info("Threat Detection Engine starting")
        ingest_task  = asyncio.create_task(self._ingest_loop())
        detect_task  = asyncio.create_task(self._detection_loop())
        await asyncio.gather(ingest_task, detect_task)

    async def _ingest_loop(self):
        """Continuously pull flow records and endpoint events."""
        while True:
            flows     = await self.flow_proc.fetch()
            endpoints = await self.endpoint_proc.fetch()
            self._flow_buffer.extend(flows)
            self._endpoint_buffer.extend(endpoints)
            # Keep last 10 min of data in memory
            self._trim_buffers(max_records=50_000)
            await asyncio.sleep(5)

    async def _detection_loop(self):
        """Run detection every window_s seconds."""
        while True:
            await asyncio.sleep(self.window_s)
            if self._flow_buffer:
                await self._run_flow_detectors()
            if self._endpoint_buffer:
                await self._run_endpoint_detectors()

    # ------------------------------------------------------------------
    # Flow-based detectors
    # ------------------------------------------------------------------

    async def _run_flow_detectors(self):
        df = pd.DataFrame(self._flow_buffer)
        if df.empty:
            return

        df = self._engineer_flow_features(df)

        # 1. Isolation Forest – global anomaly detection
        anomalies = self.iso_forest.detect(df)
        for _, row in anomalies.iterrows():
            await self._emit_signal("protocol_anomaly", row, confidence=row.get("anomaly_score", 0.6))

        # 2. Port scan heuristic
        port_scans = self._detect_port_scans(df)
        for sig in port_scans:
            await self._emit_signal("port_scan", sig, confidence=sig.get("confidence", 0.8))

        # 3. Exfiltration heuristic (large outbound bytes to rare external IPs)
        exfil = self._detect_exfiltration(df)
        for sig in exfil:
            await self._emit_signal("exfiltration", sig, confidence=sig.get("confidence", 0.75))

        # 4. DNS tunneling (high entropy / long subdomain queries)
        dns_tunnel = self._detect_dns_tunneling(df)
        for sig in dns_tunnel:
            await self._emit_signal("dns_tunneling", sig, confidence=sig.get("confidence", 0.7))

        # 5. Autoencoder deep anomaly
        ae_anomalies = self.autoenc.detect(df)
        for _, row in ae_anomalies.iterrows():
            await self._emit_signal("protocol_anomaly", row, confidence=row.get("ae_score", 0.65))

    async def _run_endpoint_detectors(self):
        df = pd.DataFrame(self._endpoint_buffer)
        if df.empty:
            return

        df = self._engineer_endpoint_features(df)

        # Brute force (many failed auths from same source)
        brute = self._detect_brute_force(df)
        for sig in brute:
            await self._emit_signal("brute_force", sig, confidence=sig.get("confidence", 0.85))

        # Lateral movement (same user → many different hosts)
        lateral = self._detect_lateral_movement(df)
        for sig in lateral:
            await self._emit_signal("lateral_movement", sig, confidence=sig.get("confidence", 0.80))

    # ------------------------------------------------------------------
    # Feature engineering
    # ------------------------------------------------------------------

    def _engineer_flow_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Build statistical flow features per src_ip / time bucket."""
        numeric_cols = ["bytes_out", "bytes_in", "duration_ms", "packet_count", "dest_port"]
        for col in numeric_cols:
            if col not in df.columns:
                df[col] = 0

        # Per-src aggregates (5-min window)
        agg = df.groupby("src_ip").agg(
            unique_dests       = ("dest_ip",   "nunique"),
            unique_ports       = ("dest_port", "nunique"),
            total_bytes_out    = ("bytes_out",  "sum"),
            total_bytes_in     = ("bytes_in",   "sum"),
            avg_bytes_out      = ("bytes_out",  "mean"),
            max_bytes_out      = ("bytes_out",  "max"),
            flow_count         = ("dest_ip",    "count"),
            avg_duration_ms    = ("duration_ms","mean"),
        ).reset_index()

        # Byte ratio (high ratio → potential exfil)
        agg["bytes_ratio"] = agg["total_bytes_out"] / (agg["total_bytes_in"] + 1)

        # Connection rate (flows per minute)
        agg["flows_per_min"] = agg["flow_count"] / max(self.window_s / 60, 1)

        return df.merge(agg, on="src_ip", how="left")

    def _engineer_endpoint_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Feature engineering for endpoint telemetry."""
        if "event_type" not in df.columns:
            df["event_type"] = "unknown"

        auth_df = df[df["event_type"].isin(["auth_success", "auth_failure"])]
        if auth_df.empty:
            return df

        agg = auth_df.groupby(["src_ip", "username"]).agg(
            failure_count  = ("event_type", lambda x: (x == "auth_failure").sum()),
            success_count  = ("event_type", lambda x: (x == "auth_success").sum()),
            unique_hosts   = ("dest_host", "nunique"),
        ).reset_index()

        agg["failure_rate"] = agg["failure_count"] / (agg["failure_count"] + agg["success_count"] + 1)
        return df.merge(agg, on=["src_ip", "username"], how="left")

    # ------------------------------------------------------------------
    # Heuristic detectors
    # ------------------------------------------------------------------

    def _detect_port_scans(self, df: pd.DataFrame) -> list[dict]:
        """Flag src IPs that touched > threshold unique ports in the window."""
        threshold = self.config.get("port_scan_threshold", 50)
        if "unique_ports" not in df.columns:
            return []
        scanners = df[df["unique_ports"] > threshold][["src_ip", "unique_ports", "flow_count"]].drop_duplicates("src_ip")
        signals  = []
        for _, row in scanners.iterrows():
            conf = min(0.50 + (row["unique_ports"] - threshold) / 200, 0.99)
            signals.append({
                "source_ip":   row["src_ip"],
                "confidence":  round(conf, 3),
                "explanation": f"Touched {row['unique_ports']} unique ports in {self.window_s}s window",
                "unique_ports": int(row["unique_ports"]),
            })
        return signals

    def _detect_exfiltration(self, df: pd.DataFrame) -> list[dict]:
        """Flag high outbound byte ratios to external / rare destinations."""
        threshold_bytes = self.config.get("exfil_bytes_threshold", 100 * 1024 * 1024)  # 100 MB
        threshold_ratio = self.config.get("exfil_ratio_threshold", 10.0)
        if "total_bytes_out" not in df.columns:
            return []
        candidates = df[
            (df["total_bytes_out"] > threshold_bytes) &
            (df["bytes_ratio"] > threshold_ratio)
        ][["src_ip", "total_bytes_out", "bytes_ratio", "unique_dests"]].drop_duplicates("src_ip")

        signals = []
        for _, row in candidates.iterrows():
            conf = min(0.60 + row["bytes_ratio"] / 100, 0.99)
            signals.append({
                "source_ip":   row["src_ip"],
                "confidence":  round(conf, 3),
                "explanation": f"Outbound {row['total_bytes_out'] / 1e6:.1f} MB, ratio={row['bytes_ratio']:.1f}",
                "bytes_out":   int(row["total_bytes_out"]),
            })
        return signals

    def _detect_dns_tunneling(self, df: pd.DataFrame) -> list[dict]:
        """Detect DNS tunneling via high-entropy / long subdomain query analysis."""
        if "query" not in df.columns:
            return []
        dns_df   = df[df.get("protocol", "") == "dns"] if "protocol" in df.columns else df
        signals  = []
        for src_ip, group in dns_df.groupby("src_ip"):
            queries = group["query"].dropna().astype(str)
            if len(queries) < 10:
                continue
            avg_len     = queries.str.len().mean()
            subdomain_d = queries.apply(lambda q: len(q.split(".")) - 2).mean()
            if avg_len > 50 or subdomain_d > 4:
                signals.append({
                    "source_ip":    src_ip,
                    "confidence":   min(0.55 + avg_len / 200, 0.95),
                    "explanation":  f"DNS query avg length={avg_len:.1f}, subdomain depth={subdomain_d:.1f}",
                })
        return signals

    def _detect_brute_force(self, df: pd.DataFrame) -> list[dict]:
        """Flag auth failure spikes."""
        threshold = self.config.get("brute_force_failure_threshold", 20)
        if "failure_count" not in df.columns:
            return []
        attackers = df[df["failure_count"] > threshold][["src_ip", "username", "failure_count"]].drop_duplicates()
        signals   = []
        for _, row in attackers.iterrows():
            conf = min(0.60 + row["failure_count"] / 200, 0.99)
            signals.append({
                "source_ip":   row["src_ip"],
                "confidence":  round(conf, 3),
                "explanation": f"{int(row['failure_count'])} auth failures for user '{row['username']}'",
                "username":    row["username"],
            })
        return signals

    def _detect_lateral_movement(self, df: pd.DataFrame) -> list[dict]:
        """Flag users/IPs accessing many distinct internal hosts."""
        threshold = self.config.get("lateral_movement_host_threshold", 5)
        if "unique_hosts" not in df.columns:
            return []
        movers = df[df["unique_hosts"] > threshold][["src_ip", "username", "unique_hosts"]].drop_duplicates()
        signals = []
        for _, row in movers.iterrows():
            conf = min(0.55 + row["unique_hosts"] / 50, 0.95)
            signals.append({
                "source_ip":   row["src_ip"],
                "confidence":  round(conf, 3),
                "explanation": f"User '{row['username']}' accessed {int(row['unique_hosts'])} unique hosts",
                "username":    row.get("username", ""),
            })
        return signals

    # ------------------------------------------------------------------
    # Signal emission
    # ------------------------------------------------------------------

    async def _emit_signal(self, signal_type: str, data: Any, confidence: float):
        if confidence < self.config.get("min_confidence", 0.55):
            return

        mitre = self.MITRE_MAP.get(signal_type, ("", ""))
        import uuid

        signal = ThreatSignal(
            signal_id       = str(uuid.uuid4()),
            signal_type     = signal_type,
            confidence      = confidence,
            source_ip       = str(data.get("src_ip", data.get("source_ip", "")) if isinstance(data, dict) else getattr(data, "src_ip", "")),
            dest_ip         = str(data.get("dest_ip", "") if isinstance(data, dict) else getattr(data, "dest_ip", "")),
            explanation     = str(data.get("explanation", "") if isinstance(data, dict) else ""),
            mitre_tactic    = mitre[0],
            mitre_technique = mitre[1],
            raw_features    = dict(data) if isinstance(data, dict) else {},
        )

        logger.warning(
            "THREAT SIGNAL [%s] type=%s confidence=%.2f src=%s → %s",
            signal.signal_id, signal_type, confidence, signal.source_ip, signal.dest_ip
        )
        await self.emitter.emit(signal)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _trim_buffers(self, max_records: int):
        if len(self._flow_buffer) > max_records:
            self._flow_buffer = self._flow_buffer[-max_records:]
        if len(self._endpoint_buffer) > max_records:
            self._endpoint_buffer = self._endpoint_buffer[-max_records:]


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------

def load_config(path: str = "config/detector.yaml") -> dict:
    import yaml
    with open(path) as f:
        return yaml.safe_load(f)


if __name__ == "__main__":
    cfg    = load_config()
    engine = ThreatDetectionEngine(cfg)
    asyncio.run(engine.run())
