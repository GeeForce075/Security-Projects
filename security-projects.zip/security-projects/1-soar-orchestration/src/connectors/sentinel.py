"""
Microsoft Sentinel SOAR Connector
Interfaces with Azure Sentinel via the Azure Monitor / Security Insights REST API.
Supports: Alert ingestion, Incident creation, Watchlist lookups, Analytic rule triggers.
"""

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp
from azure.identity.aio import ClientSecretCredential, DefaultAzureCredential
from azure.mgmt.securityinsight.aio import SecurityInsights

logger = logging.getLogger("soar.connectors.sentinel")

SENTINEL_SCOPE = "https://management.azure.com/.default"


class SentinelConnector:
    """
    Async connector for Microsoft Sentinel.
    Authenticates via Service Principal (ClientSecretCredential) or
    DefaultAzureCredential (Managed Identity / CLI fallback).
    """

    def __init__(self, config: dict):
        self.subscription_id  = config["subscription_id"]
        self.resource_group   = config["resource_group"]
        self.workspace_name   = config["workspace_name"]
        self.workspace_id     = config.get("workspace_id", "")
        self.lookback_minutes = config.get("lookback_minutes", 30)
        self.filter_severity  = config.get("filter_severity", ["High", "Medium", "Low"])

        # Auth: prefer SP creds; fall back to DefaultAzureCredential
        if all(k in config for k in ("tenant_id", "client_id", "client_secret")):
            self.credential = ClientSecretCredential(
                tenant_id     = config["tenant_id"],
                client_id     = config["client_id"],
                client_secret = config["client_secret"],
            )
            logger.info("Sentinel auth: ClientSecretCredential")
        else:
            self.credential = DefaultAzureCredential()
            logger.info("Sentinel auth: DefaultAzureCredential")

        self._base_url = (
            f"https://management.azure.com/subscriptions/{self.subscription_id}"
            f"/resourceGroups/{self.resource_group}"
            f"/providers/Microsoft.OperationalInsights/workspaces/{self.workspace_name}"
        )
        self._si_base  = (
            f"https://management.azure.com/subscriptions/{self.subscription_id}"
            f"/resourceGroups/{self.resource_group}"
            f"/providers/Microsoft.SecurityInsights/workspaces/{self.workspace_name}"
        )

    # ------------------------------------------------------------------
    # Auth token helper
    # ------------------------------------------------------------------

    async def _get_token(self) -> str:
        token = await self.credential.get_token(SENTINEL_SCOPE)
        return token.token

    # ------------------------------------------------------------------
    # Alert ingestion
    # ------------------------------------------------------------------

    async def fetch_alerts(self) -> list[dict]:
        """Fetch SecurityAlerts from Sentinel via Log Analytics query."""
        since = (datetime.now(timezone.utc) - timedelta(minutes=self.lookback_minutes)).isoformat()
        severity_filter = " or ".join(f"AlertSeverity == '{s}'" for s in self.filter_severity)

        query = f"""
        SecurityAlert
        | where TimeGenerated >= datetime('{since}')
        | where {severity_filter}
        | where ProcessingEndTime > ago({self.lookback_minutes}m)
        | project AlertName, AlertSeverity, Description, Entities,
                  ExtendedProperties, SystemAlertId, TimeGenerated,
                  ProductName, ProviderName, Tactics, CompromisedEntity
        | order by TimeGenerated desc
        | take 500
        """

        token = await self._get_token()
        url   = f"{self._base_url}/api/query?api-version=2021-12-01-preview"

        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json={"query": query, "timespan": f"PT{self.lookback_minutes}M"},
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                resp.raise_for_status()
                data    = await resp.json()
                rows    = data.get("tables", [{}])[0].get("rows", [])
                columns = data.get("tables", [{}])[0].get("columns", [])
                col_names = [c["name"] for c in columns]
                alerts  = [dict(zip(col_names, row)) for row in rows]
                logger.info("Sentinel: retrieved %d alerts", len(alerts))
                return alerts

    # ------------------------------------------------------------------
    # Incident management
    # ------------------------------------------------------------------

    async def create_incident(self, alert: dict) -> dict:
        """Create a Sentinel incident from a normalized alert dict."""
        import uuid
        incident_id   = str(uuid.uuid4())
        token         = await self._get_token()
        url           = f"{self._si_base}/incidents/{incident_id}?api-version=2023-02-01"

        severity_map  = {"critical": "High", "high": "High", "medium": "Medium",
                         "low": "Low", "info": "Informational"}
        sentinel_sev  = severity_map.get(alert.get("severity", "low"), "Low")

        payload = {
            "properties": {
                "title":       alert.get("title", "SOAR-Generated Incident"),
                "description": alert.get("description", ""),
                "severity":    sentinel_sev,
                "status":      "New",
                "labels":      [{"labelName": "SOAR-Orchestrator"}],
                "additionalData": {
                    "sourceAlertId": alert.get("alert_id", ""),
                    "mlRiskScore":   str(alert.get("ml_risk_score", 0)),
                    "playbookId":    alert.get("playbook_id", ""),
                }
            }
        }

        async with aiohttp.ClientSession() as session:
            async with session.put(
                url,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json=payload,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                resp.raise_for_status()
                result = await resp.json()
                logger.info("Sentinel: incident created — %s", incident_id)
                return result

    # ------------------------------------------------------------------
    # Watchlist operations
    # ------------------------------------------------------------------

    async def query_watchlist(self, watchlist_alias: str, key: str, value: str) -> list[dict]:
        """Check if an IOC or entity appears on a Sentinel watchlist."""
        token = await self._get_token()
        url   = (f"{self._si_base}/watchlists/{watchlist_alias}/watchlistItems"
                 f"?api-version=2023-02-01&$filter=properties/itemsKeyValue/{key} eq '{value}'")

        async with aiohttp.ClientSession() as session:
            async with session.get(
                url,
                headers={"Authorization": f"Bearer {token}"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status == 404:
                    return []
                resp.raise_for_status()
                data  = await resp.json()
                items = data.get("value", [])
                logger.debug("Watchlist '%s' lookup for %s=%s: %d hits", watchlist_alias, key, value, len(items))
                return items

    # ------------------------------------------------------------------
    # Playbook / Logic App trigger
    # ------------------------------------------------------------------

    async def trigger_playbook(self, playbook_name: str, incident_arm_id: str) -> bool:
        """Trigger a Sentinel Automation Rule / Logic App playbook."""
        token = await self._get_token()
        url   = (f"{self._si_base}/incidents/"
                 f"{incident_arm_id.split('/')[-1]}/runPlaybook?api-version=2023-02-01")

        payload = {"LogicAppResourceId": f"/subscriptions/{self.subscription_id}/resourceGroups"
                   f"/{self.resource_group}/providers/Microsoft.Logic/workflows/{playbook_name}"}

        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json=payload,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                success = resp.status in (200, 202, 204)
                logger.info("Sentinel: playbook '%s' trigger %s", playbook_name, "OK" if success else "FAILED")
                return success

    async def close(self):
        await self.credential.close()
