"""
CrowdStrike Falcon Connector
Interfaces with the CrowdStrike Falcon platform via OAuth2 REST API.
Supports: Detection ingestion, incident management, host isolation,
          IOC management, threat graph queries, and real-time response.
"""

import asyncio
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp

logger = logging.getLogger("soar.connectors.crowdstrike")

# CrowdStrike API base URL per cloud region
REGION_URLS: dict[str, str] = {
    "us-1":    "https://api.crowdstrike.com",
    "us-2":    "https://api.us-2.crowdstrike.com",
    "eu-1":    "https://api.eu-1.crowdstrike.com",
    "us-gov-1":"https://api.laggar.gcw.crowdstrike.com",
}

SEVERITY_FROM_CS: dict[int, str] = {
    100: "info",
    200: "low",
    300: "medium",
    400: "high",
    500: "critical",
}


class CrowdStrikeConnector:
    """
    Async connector for CrowdStrike Falcon.
    Uses OAuth2 client credentials flow; token is automatically refreshed.
    """

    def __init__(self, config: dict):
        region        = config.get("region", "us-1")
        self.base_url = config.get("base_url", REGION_URLS.get(region, REGION_URLS["us-1"]))
        self.client_id     = config["client_id"]
        self.client_secret = config["client_secret"]
        self.member_cid    = config.get("member_cid")           # MSSP member CID
        self.verify_ssl    = config.get("verify_ssl", True)
        self.lookback_minutes = config.get("lookback_minutes", 30)
        self.filter_severity  = config.get("filter_severity", [3, 4])  # 3=High, 4=Critical

        self._access_token:  str | None = None
        self._token_expiry:  float      = 0.0
        self._session: aiohttp.ClientSession | None = None

    # ------------------------------------------------------------------
    # Session & OAuth2 token management
    # ------------------------------------------------------------------

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector     = aiohttp.TCPConnector(ssl=self.verify_ssl)
            self._session = aiohttp.ClientSession(connector=connector)
        return self._session

    async def _get_token(self) -> str:
        """Obtain or refresh the OAuth2 bearer token."""
        if self._access_token and time.monotonic() < self._token_expiry - 30:
            return self._access_token

        session = await self._get_session()
        url     = f"{self.base_url}/oauth2/token"
        data    = {
            "client_id":     self.client_id,
            "client_secret": self.client_secret,
        }
        if self.member_cid:
            data["member_cid"] = self.member_cid

        async with session.post(
            url,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            resp.raise_for_status()
            token_data         = await resp.json()
            self._access_token = token_data["access_token"]
            self._token_expiry = time.monotonic() + token_data.get("expires_in", 1799)
            logger.debug("CrowdStrike: OAuth2 token refreshed")
            return self._access_token

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        token   = await self._get_token()
        session = await self._get_session()
        url     = f"{self.base_url}{path}"

        async with session.request(
            method, url,
            headers={
                "Authorization":  f"Bearer {token}",
                "Content-Type":   "application/json",
                "Accept":         "application/json",
            },
            timeout=aiohttp.ClientTimeout(total=30),
            **kwargs,
        ) as resp:
            if resp.status == 401:
                # Force token refresh on next call
                self._token_expiry = 0
                resp.raise_for_status()
            resp.raise_for_status()
            return await resp.json()

    # ------------------------------------------------------------------
    # Detection ingestion
    # ------------------------------------------------------------------

    async def fetch_alerts(self) -> list[dict]:
        """Fetch recent CrowdStrike detections above configured severity threshold."""
        since = (datetime.now(timezone.utc) - timedelta(minutes=self.lookback_minutes)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        min_sev  = min(self.filter_severity) if self.filter_severity else 3
        fql      = (
            f"created_timestamp:>='{since}'"
            f"+max_severity_displayname:>={min_sev * 100}"
            f"+status:!['closed','ignored']"
        )

        # Step 1: get IDs
        id_resp = await self._request(
            "GET",
            "/detects/queries/detects/v1",
            params={"filter": fql, "limit": 200, "sort": "created_timestamp.desc"},
        )
        detect_ids = id_resp.get("resources", [])
        if not detect_ids:
            logger.info("CrowdStrike: no new detections in lookback window")
            return []

        # Step 2: fetch full detection details in batches of 1000
        all_detections = []
        for batch_start in range(0, len(detect_ids), 100):
            batch  = detect_ids[batch_start:batch_start + 100]
            detail = await self._request(
                "POST",
                "/detects/entities/summaries/GET/v1",
                json={"ids": batch},
            )
            all_detections.extend(detail.get("resources", []))

        logger.info("CrowdStrike: retrieved %d detections", len(all_detections))
        return all_detections

    async def fetch_incidents(self) -> list[dict]:
        """Fetch CrowdStrike incidents (correlated detections)."""
        since = (datetime.now(timezone.utc) - timedelta(minutes=self.lookback_minutes)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        fql = f"start:>='{since}'+status:!['Closed']"

        id_resp = await self._request(
            "GET",
            "/incidents/queries/incidents/v1",
            params={"filter": fql, "limit": 100, "sort": "start.desc"},
        )
        incident_ids = id_resp.get("resources", [])
        if not incident_ids:
            return []

        detail = await self._request(
            "POST",
            "/incidents/entities/incidents/GET/v1",
            json={"ids": incident_ids},
        )
        return detail.get("resources", [])

    # ------------------------------------------------------------------
    # Incident creation (CrowdStrike incident from detection)
    # ------------------------------------------------------------------

    async def create_incident(self, alert: dict) -> dict:
        """
        Update detection status and add a comment (CrowdStrike creates
        incidents internally from correlated detections; we annotate them).
        """
        alert_id = alert.get("alert_id", "")
        if not alert_id:
            return {}

        # Update detection status to "in_progress"
        try:
            await self._request(
                "PATCH",
                "/detects/entities/detects/v2",
                json={"ids": [alert_id], "status": "in_progress"},
            )
        except Exception as exc:
            logger.warning("CrowdStrike: could not update detection status for %s: %s", alert_id, exc)

        # Add comment with SOAR context
        try:
            await self._request(
                "PATCH",
                "/detects/entities/detects/v2",
                json={
                    "ids":     [alert_id],
                    "comment": (
                        f"SOAR Orchestrator — risk_score={alert.get('ml_risk_score', 0):.4f} "
                        f"playbook={alert.get('playbook_id', 'none')} "
                        f"mitre={','.join(alert.get('mitre_tactics') or [])}"
                    ),
                },
            )
        except Exception as exc:
            logger.warning("CrowdStrike: could not post comment for %s: %s", alert_id, exc)

        return {"id": alert_id, "status": "in_progress"}

    # ------------------------------------------------------------------
    # Host containment / isolation
    # ------------------------------------------------------------------

    async def contain_host(self, device_id: str) -> bool:
        """
        Isolate / contain a host via CrowdStrike Real-Time Response.
        Requires the 'Device Control' scope.
        """
        resp = await self._request(
            "POST",
            "/devices/entities/devices-actions/v2",
            params={"action_name": "contain"},
            json={"ids": [device_id]},
        )
        resources = resp.get("resources", [])
        success   = bool(resources and resources[0].get("id"))
        logger.info("CrowdStrike: contain_host %s — %s", device_id, "OK" if success else "FAILED")
        return success

    async def lift_containment(self, device_id: str) -> bool:
        """Lift network containment from a previously isolated host."""
        resp = await self._request(
            "POST",
            "/devices/entities/devices-actions/v2",
            params={"action_name": "lift_containment"},
            json={"ids": [device_id]},
        )
        return bool(resp.get("resources"))

    # ------------------------------------------------------------------
    # IOC management
    # ------------------------------------------------------------------

    async def upload_ioc(
        self,
        ioc_value: str,
        ioc_type: str,
        action: str = "detect",
        comment: str = "",
        platforms: list[str] | None = None,
        severity: str = "HIGH",
    ) -> dict:
        """
        Upload a custom IOC to CrowdStrike IOC Management.
        ioc_type: "ipv4" | "ipv6" | "domain" | "md5" | "sha256" | "url"
        action:   "no_action" | "detect" | "prevent" | "prevent_no_ui"
        """
        payload = {
            "indicators": [{
                "type":        ioc_type,
                "value":       ioc_value,
                "action":      action,
                "severity":    severity,
                "description": comment or "Uploaded by SOAR Orchestrator",
                "platforms":   platforms or ["windows", "linux", "mac"],
                "applied_globally": True,
            }]
        }
        return await self._request("POST", "/iocs/entities/indicators/v1", json=payload)

    async def bulk_upload_iocs(self, iocs: list[dict]) -> dict:
        """
        Upload up to 200 IOCs in a single API call.
        Each dict: {type, value, action, severity, comment}
        """
        indicators = [
            {
                "type":        i["type"],
                "value":       i["value"],
                "action":      i.get("action", "detect"),
                "severity":    i.get("severity", "HIGH"),
                "description": i.get("comment", "SOAR Orchestrator bulk upload"),
                "platforms":   i.get("platforms", ["windows", "linux", "mac"]),
                "applied_globally": True,
            }
            for i in iocs[:200]
        ]
        return await self._request(
            "POST", "/iocs/entities/indicators/v1",
            json={"indicators": indicators},
        )

    # ------------------------------------------------------------------
    # Threat Graph / intelligence
    # ------------------------------------------------------------------

    async def search_threat_graph(self, ioc: str) -> dict:
        """Query Threat Graph for connections to a known IOC."""
        return await self._request(
            "GET",
            "/intel/combined/indicators/v1",
            params={"q": ioc, "limit": 20, "sort": "last_updated.desc"},
        )

    async def get_actor_intel(self, actor_name: str) -> dict:
        """Return known adversary actor profile."""
        resp = await self._request(
            "GET",
            "/intel/combined/actors/v1",
            params={"q": actor_name, "limit": 5},
        )
        resources = resp.get("resources", [])
        return resources[0] if resources else {}

    # ------------------------------------------------------------------
    # Enrichment helpers used by orchestrator
    # ------------------------------------------------------------------

    async def get_device_details(self, device_id: str) -> dict:
        """Return full host / device record."""
        resp = await self._request(
            "GET",
            "/devices/entities/devices/v2",
            params={"ids": [device_id]},
        )
        resources = resp.get("resources", [])
        return resources[0] if resources else {}

    async def get_user_details(self, uid: str) -> dict:
        """Return Falcon user record."""
        resp = await self._request(
            "GET",
            "/user-management/entities/users/v1",
            params={"ids": [uid]},
        )
        resources = resp.get("resources", [])
        return resources[0] if resources else {}

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
