"""
Cortex XSOAR Connector
Interfaces with Palo Alto Cortex XSOAR (formerly Demisto) REST API.
Supports: Incident ingestion, incident creation, playbook execution,
          indicator enrichment, war room entry, and field updates.
"""

import asyncio
import logging
import hashlib
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp

logger = logging.getLogger("soar.connectors.cortex_xsoar")

# Cortex severity: 0=Unknown, 0.5=Informational, 1=Low, 2=Medium, 3=High, 4=Critical
SEVERITY_TO_XSOAR: dict[str, float] = {
    "critical": 4,
    "high":     3,
    "medium":   2,
    "low":      1,
    "info":     0.5,
}

XSOAR_TO_SEVERITY: dict[int, str] = {
    4: "critical",
    3: "high",
    2: "medium",
    1: "low",
    0: "info",
}


class CortexXSOARConnector:
    """
    Async connector for Cortex XSOAR.
    Authenticates via API key header (standard) or advanced API key (multi-tenant).
    """

    def __init__(self, config: dict):
        self.base_url         = config["base_url"].rstrip("/")
        self.verify_ssl       = config.get("verify_ssl", True)
        self.lookback_minutes = config.get("lookback_minutes", 30)
        self.default_type     = config.get("default_type", "Unclassified")

        # Auth: standard single-tenant key vs advanced multi-tenant key
        api_key   = config["api_key"]
        key_id    = config.get("api_key_id")
        if key_id:
            # Advanced auth: HMAC-signed nonce for multi-tenant / XSOAR 8+
            self._auth_header    = None
            self._api_key        = api_key
            self._api_key_id     = key_id
            self._advanced_auth  = True
        else:
            self._auth_header   = {"Authorization": api_key}
            self._advanced_auth = False

        self._session: aiohttp.ClientSession | None = None

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(ssl=self.verify_ssl)
            headers   = {"Content-Type": "application/json", "Accept": "application/json"}
            if not self._advanced_auth:
                headers.update(self._auth_header)
            self._session = aiohttp.ClientSession(headers=headers, connector=connector)
        return self._session

    def _build_auth_headers(self) -> dict:
        """Build HMAC auth headers for advanced (multi-tenant) API key mode."""
        if not self._advanced_auth:
            return {}
        import time
        nonce         = str(time.time_ns())
        string_to_sign = f"{self._api_key}{nonce}"
        auth_hash     = hashlib.sha256(string_to_sign.encode()).hexdigest()
        return {
            "x-xdr-auth-id":       str(self._api_key_id),
            "x-xdr-nonce":         nonce,
            "x-xdr-timestamp":     nonce[:13],
            "Authorization":        auth_hash,
        }

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        session  = await self._get_session()
        url      = f"{self.base_url}{path}"
        extra_hdrs = self._build_auth_headers()

        async with session.request(
            method, url,
            headers=extra_hdrs,
            timeout=aiohttp.ClientTimeout(total=30),
            **kwargs,
        ) as resp:
            resp.raise_for_status()
            if resp.content_type == "application/json":
                return await resp.json()
            return {"status": resp.status}

    # ------------------------------------------------------------------
    # Incident ingestion
    # ------------------------------------------------------------------

    async def fetch_alerts(self) -> list[dict]:
        """Fetch incidents from Cortex XSOAR created in the lookback window."""
        since_epoch_ms = int(
            (datetime.now(timezone.utc) - timedelta(minutes=self.lookback_minutes)).timestamp() * 1000
        )

        body = {
            "filter": {
                "query":     f"-status:Closed",
                "fromdate":  since_epoch_ms,
                "sort": [{"field": "created", "asc": False}],
                "size":      200,
            }
        }

        data = await self._request("POST", "/incidents/search", json=body)
        incidents = data.get("data") or []
        logger.info("Cortex XSOAR: retrieved %d incidents", len(incidents))
        return incidents

    # ------------------------------------------------------------------
    # Incident creation
    # ------------------------------------------------------------------

    async def create_incident(self, alert: dict) -> dict:
        """Create a Cortex XSOAR incident from a normalized alert dict."""
        sev = SEVERITY_TO_XSOAR.get(alert.get("severity", "low"), 1)

        payload = {
            "name":     alert.get("title", "SOAR Incident"),
            "type":     self.default_type,
            "severity": sev,
            "details":  alert.get("description", ""),
            "createInvestigation": True,
            "labels": [
                {"type": "source",        "value": alert.get("source", "soar-orchestrator")},
                {"type": "alert_id",      "value": alert.get("alert_id", "")},
                {"type": "ml_risk_score", "value": str(round(alert.get("ml_risk_score", 0), 4))},
                {"type": "playbook",      "value": alert.get("playbook_id", "")},
            ] + [
                {"type": "hostname", "value": h}
                for h in (alert.get("affected_hosts") or [])[:5]
            ] + [
                {"type": "username", "value": u}
                for u in (alert.get("affected_users") or [])[:5]
            ],
            "rawJSON": str(alert.get("raw_payload", {})),
        }

        # Attach IOCs as indicators if present
        if alert.get("iocs"):
            payload["CustomFields"] = {
                "relatedIncidents": "",
                "iocs": "\n".join((alert["iocs"] or [])[:50]),
                "mitretactics": ", ".join(alert.get("mitre_tactics") or []),
            }

        result = await self._request("POST", "/incident", json=payload)
        logger.info("Cortex XSOAR: incident created — id=%s", result.get("id"))
        return result

    # ------------------------------------------------------------------
    # Playbook execution
    # ------------------------------------------------------------------

    async def run_playbook(self, incident_id: str, playbook_name: str) -> dict:
        """Attach and run a named playbook on an existing incident."""
        payload = {
            "id":           incident_id,
            "playbookName": playbook_name,
        }
        result = await self._request("POST", "/incident/playbook", json=payload)
        logger.info("Cortex XSOAR: playbook '%s' triggered on incident %s", playbook_name, incident_id)
        return result

    async def get_playbook_status(self, incident_id: str) -> dict:
        """Return the current playbook run status for an incident."""
        return await self._request("GET", f"/inv-playbook/{incident_id}")

    # ------------------------------------------------------------------
    # War room / investigation entries
    # ------------------------------------------------------------------

    async def add_war_room_entry(self, incident_id: str, note: str, entry_type: int = 1) -> dict:
        """
        Post a note to the incident war room.
        entry_type: 1=note, 2=error, 3=pending, 4=debug, 9=widget
        """
        payload = {
            "id":       incident_id,
            "version":  -1,
            "entry": {
                "type":        entry_type,
                "contents":    note,
                "contentsFormat": "markdown",
            }
        }
        return await self._request("POST", "/entry/create", json=payload)

    # ------------------------------------------------------------------
    # Indicator / IOC operations
    # ------------------------------------------------------------------

    async def create_indicator(self, ioc_value: str, ioc_type: str, score: int = 2) -> dict:
        """
        Create or update a threat indicator.
        score: 0=Unknown, 1=Benign, 2=Suspicious, 3=Malicious
        """
        payload = {
            "indicator": {
                "value":  ioc_value,
                "indicator_type": ioc_type,  # e.g. "IP", "Domain", "SHA256", "URL"
                "score":  score,
                "comment": "Created by SOAR Orchestrator",
                "CustomFields": {
                    "trafficlightprotocol": "AMBER",
                },
            }
        }
        return await self._request("POST", "/indicator/create", json=payload)

    async def search_indicators(self, query: str, size: int = 50) -> list[dict]:
        """Search XSOAR indicator store."""
        body   = {"query": query, "size": size, "sort": [{"field": "modified", "asc": False}]}
        data   = await self._request("POST", "/indicators/search", json=body)
        return data.get("iocObjects") or []

    # ------------------------------------------------------------------
    # Field updates
    # ------------------------------------------------------------------

    async def update_incident(self, incident_id: str, fields: dict) -> dict:
        """Update arbitrary custom fields on an incident."""
        payload = {"id": incident_id, "version": -1, "CustomFields": fields}
        return await self._request("POST", "/incident/customfields", json=payload)

    async def close_incident(self, incident_id: str, close_reason: str = "Resolved", notes: str = "") -> dict:
        """Close an incident."""
        payload = {
            "id":          incident_id,
            "version":     -1,
            "closeReason": close_reason,
            "closeNotes":  notes,
        }
        return await self._request("POST", "/incident/close", json=payload)

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
