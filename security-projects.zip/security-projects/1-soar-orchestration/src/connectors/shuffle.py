"""
Shuffle SOAR Connector
Interfaces with Shuffle (shuffler.io) open-source SOAR platform.
Supports: Workflow execution via webhooks, execution results polling,
          alert forwarding, and app action invocation.
"""

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp

logger = logging.getLogger("soar.connectors.shuffle")

SHUFFLE_SEVERITY_MAP: dict[str, str] = {
    "critical": "critical",
    "high":     "high",
    "medium":   "medium",
    "low":      "low",
    "info":     "info",
}


class ShuffleConnector:
    """
    Async connector for Shuffle SOAR.
    Executes workflows via webhook triggers and the Shuffle REST API.
    Supports both cloud (shuffler.io) and self-hosted instances.
    """

    def __init__(self, config: dict):
        self.base_url         = config["base_url"].rstrip("/")
        self.api_key          = config["api_key"]
        self.verify_ssl       = config.get("verify_ssl", True)
        self.lookback_minutes = config.get("lookback_minutes", 30)

        # Workflow → webhook URL mappings, e.g.:
        # workflows:
        #   phishing_response:  https://shuffler.io/api/v1/hooks/webhook_abc123
        #   malware_triage:     https://shuffler.io/api/v1/hooks/webhook_def456
        self.workflow_webhooks: dict[str, str] = config.get("workflows", {})

        self._session: aiohttp.ClientSession | None = None

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(ssl=self.verify_ssl)
            self._session = aiohttp.ClientSession(
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type":  "application/json",
                },
                connector=connector,
            )
        return self._session

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        session = await self._get_session()
        url     = f"{self.base_url}{path}"
        async with session.request(
            method, url,
            timeout=aiohttp.ClientTimeout(total=30),
            **kwargs,
        ) as resp:
            resp.raise_for_status()
            try:
                return await resp.json()
            except Exception:
                return {"status": resp.status}

    # ------------------------------------------------------------------
    # Alert ingestion (Shuffle execution history)
    # ------------------------------------------------------------------

    async def fetch_alerts(self) -> list[dict]:
        """
        Fetch recent workflow executions from Shuffle.
        Returns executions that have actionable results (FINISHED / FAILED).
        """
        try:
            data       = await self._request("GET", "/api/v1/workflows/queue")
            executions = data if isinstance(data, list) else data.get("executions", [])
        except Exception as exc:
            logger.warning("Shuffle: could not fetch execution queue (%s)", exc)
            return []

        since = datetime.now(timezone.utc) - timedelta(minutes=self.lookback_minutes)
        recent = []
        for ex in executions:
            try:
                ts = datetime.fromisoformat(ex.get("started_at", "").replace("Z", "+00:00"))
                if ts >= since and ex.get("status") in ("FINISHED", "FAILED", "ABORTED"):
                    recent.append(ex)
            except Exception:
                continue

        logger.info("Shuffle: retrieved %d execution results", len(recent))
        return recent

    # ------------------------------------------------------------------
    # Webhook-triggered workflow execution
    # ------------------------------------------------------------------

    async def trigger_workflow(self, workflow_name: str, payload: dict) -> dict:
        """
        Trigger a named Shuffle workflow via its registered webhook URL.
        Workflow name must exist in config.workflows.
        """
        webhook_url = self.workflow_webhooks.get(workflow_name)
        if not webhook_url:
            logger.warning("Shuffle: no webhook registered for workflow '%s'", workflow_name)
            return {"error": f"no webhook for {workflow_name}"}

        session = await self._get_session()
        async with session.post(
            webhook_url,
            json=payload,
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            resp.raise_for_status()
            try:
                result = await resp.json()
            except Exception:
                result = {"status": resp.status, "execution_id": resp.headers.get("X-Execution-Id")}
            logger.info("Shuffle: workflow '%s' triggered — execution_id=%s",
                        workflow_name, result.get("execution_id", "?"))
            return result

    async def trigger_workflow_by_id(self, workflow_id: str, payload: dict) -> dict:
        """Trigger a workflow directly by its Shuffle workflow UUID."""
        return await self._request(
            "POST",
            f"/api/v1/workflows/{workflow_id}/execute",
            json={"execution_argument": payload},
        )

    # ------------------------------------------------------------------
    # Incident creation — maps to workflow trigger
    # ------------------------------------------------------------------

    async def create_incident(self, alert: dict) -> dict:
        """
        Forward a normalized alert to Shuffle as a workflow execution.
        Routes to the most appropriate registered workflow based on alert properties.
        """
        workflow_name = self._select_workflow(alert)
        payload = {
            "alert_id":      alert.get("alert_id", ""),
            "title":         alert.get("title", ""),
            "severity":      alert.get("severity", "low"),
            "description":   alert.get("description", ""),
            "source":        alert.get("source", ""),
            "ml_risk_score": alert.get("ml_risk_score", 0),
            "iocs":          alert.get("iocs", []),
            "affected_hosts":alert.get("affected_hosts", []),
            "affected_users":alert.get("affected_users", []),
            "mitre_tactics": alert.get("mitre_tactics", []),
            "timestamp":     alert.get("timestamp", ""),
            "enrichments":   alert.get("enrichments", {}),
        }
        return await self.trigger_workflow(workflow_name, payload)

    def _select_workflow(self, alert: dict) -> str:
        """Pick the most relevant registered workflow for an alert."""
        title    = (alert.get("title", "") + " " + alert.get("description", "")).lower()
        tactics  = [t.lower() for t in (alert.get("mitre_tactics") or [])]

        # Specific workflow mapping by content / tactic
        if any(k in title for k in ("phishing", "email", "smtp", "spear")):
            return "phishing_response"
        if any(k in title for k in ("malware", "ransomware", "trojan", "backdoor")):
            return "malware_triage"
        if any(k in title for k in ("brute force", "password spray", "credential stuffing")):
            return "brute_force_response"
        if "ta0010" in tactics or "exfiltration" in title:
            return "data_exfiltration"
        if "ta0008" in tactics or "lateral movement" in title:
            return "lateral_movement"

        # Fallback to severity-tiered generic workflows
        sev = alert.get("severity", "low")
        if sev in ("critical", "high"):
            return "high_severity_triage"
        return "generic_alert"

    # ------------------------------------------------------------------
    # Execution status polling
    # ------------------------------------------------------------------

    async def get_execution_status(self, execution_id: str) -> dict:
        """Poll a specific execution by ID."""
        return await self._request("GET", f"/api/v1/streams/results?execution_id={execution_id}")

    async def wait_for_completion(
        self, execution_id: str, timeout_seconds: int = 120, poll_interval: int = 5
    ) -> dict:
        """
        Poll an execution until FINISHED / FAILED or timeout.
        Returns the final execution object.
        """
        deadline = datetime.now(timezone.utc).timestamp() + timeout_seconds
        while datetime.now(timezone.utc).timestamp() < deadline:
            status_obj = await self.get_execution_status(execution_id)
            status     = status_obj.get("status", "EXECUTING")
            if status in ("FINISHED", "FAILED", "ABORTED"):
                logger.info("Shuffle: execution %s — %s", execution_id, status)
                return status_obj
            await asyncio.sleep(poll_interval)

        logger.warning("Shuffle: execution %s timed out after %ds", execution_id, timeout_seconds)
        return {"status": "TIMEOUT", "execution_id": execution_id}

    # ------------------------------------------------------------------
    # Workflow & app management
    # ------------------------------------------------------------------

    async def list_workflows(self) -> list[dict]:
        """Return all workflows visible to the authenticated user."""
        data = await self._request("GET", "/api/v1/workflows")
        return data if isinstance(data, list) else []

    async def get_workflow(self, workflow_id: str) -> dict:
        return await self._request("GET", f"/api/v1/workflows/{workflow_id}")

    async def list_apps(self) -> list[dict]:
        data = await self._request("GET", "/api/v1/apps")
        return data if isinstance(data, list) else []

    # ------------------------------------------------------------------
    # User / org management helpers
    # ------------------------------------------------------------------

    async def get_user_info(self) -> dict:
        return await self._request("GET", "/api/v1/users/getinfo")

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
