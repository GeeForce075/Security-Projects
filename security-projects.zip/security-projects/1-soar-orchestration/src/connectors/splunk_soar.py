"""
Splunk SOAR Connector
Interfaces with Splunk SOAR (formerly Phantom) REST API.
Supports: Container/event ingestion, artifact creation, playbook execution, action results.
"""

import logging
import asyncio
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp

logger = logging.getLogger("soar.connectors.splunk_soar")


class SplunkSOARConnector:
    """
    Async connector for Splunk SOAR.
    Authenticates via API token or username/password.
    """

    def __init__(self, config: dict):
        self.base_url        = config["base_url"].rstrip("/")   # e.g. https://soar.company.com
        self.verify_ssl      = config.get("verify_ssl", True)
        self.lookback_minutes = config.get("lookback_minutes", 30)
        self.default_label   = config.get("default_label", "events")

        # Auth
        if "api_token" in config:
            self._auth_header = {"ph-auth-token": config["api_token"]}
        else:
            import base64
            creds = base64.b64encode(f"{config['username']}:{config['password']}".encode()).decode()
            self._auth_header = {"Authorization": f"Basic {creds}"}

        self._session: aiohttp.ClientSession | None = None

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(ssl=self.verify_ssl)
            self._session = aiohttp.ClientSession(
                headers={**self._auth_header, "Content-Type": "application/json"},
                connector=connector,
            )
        return self._session

    # ------------------------------------------------------------------
    # Container / event ingestion
    # ------------------------------------------------------------------

    async def fetch_alerts(self) -> list[dict]:
        """Fetch recent containers (events) from Splunk SOAR."""
        since = (datetime.now(timezone.utc) - timedelta(minutes=self.lookback_minutes)).strftime(
            "%Y-%m-%dT%H:%M:%S.000000Z"
        )
        session  = await self._get_session()
        url      = f"{self.base_url}/rest/container"
        params   = {
            "_filter_create_time__gte": f'"{since}"',
            "sort":    "create_time",
            "order":   "desc",
            "page_size": 200,
        }

        async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            resp.raise_for_status()
            data = await resp.json()
            containers = data.get("data", [])
            logger.info("Splunk SOAR: retrieved %d containers", len(containers))
            return containers

    async def fetch_artifacts(self, container_id: int) -> list[dict]:
        """Fetch all artifacts (IOCs, events) from a given container."""
        session = await self._get_session()
        url     = f"{self.base_url}/rest/artifact"
        params  = {"_filter_container": container_id, "page_size": 500}

        async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            resp.raise_for_status()
            data = await resp.json()
            return data.get("data", [])

    # ------------------------------------------------------------------
    # Container / incident creation
    # ------------------------------------------------------------------

    async def create_incident(self, alert: dict) -> dict:
        """Create a Splunk SOAR container from a normalized alert."""
        session = await self._get_session()
        url     = f"{self.base_url}/rest/container"

        severity_map = {"critical": "high", "high": "high", "medium": "medium",
                        "low": "low", "info": "low"}
        status_map   = {"critical": "new", "high": "new", "medium": "new",
                        "low": "open", "info": "open"}

        sev    = severity_map.get(alert.get("severity", "low"), "medium")
        status = status_map.get(alert.get("severity", "low"), "new")

        container_payload = {
            "name":        alert.get("title", "SOAR Incident"),
            "description": alert.get("description", ""),
            "label":       self.default_label,
            "severity":    sev,
            "status":      status,
            "sensitivity": "amber",
            "tags":        ["soar-orchestrator", f"score-{alert.get('ml_risk_score', 0):.2f}"],
            "custom_fields": {
                "source_alert_id": alert.get("alert_id", ""),
                "source_platform": alert.get("source", ""),
                "ml_risk_score":   alert.get("ml_risk_score", 0),
                "mitre_tactics":   ", ".join(alert.get("mitre_tactics", [])),
            }
        }

        async with session.post(url, json=container_payload, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            resp.raise_for_status()
            result       = await resp.json()
            container_id = result.get("id")
            logger.info("Splunk SOAR: container created — id=%s", container_id)

            # Add artifacts for IOCs
            if container_id and alert.get("iocs"):
                await self._add_ioc_artifacts(container_id, alert["iocs"])

            return result

    async def _add_ioc_artifacts(self, container_id: int, iocs: list[str]):
        """Attach IOC artifacts to a container."""
        session   = await self._get_session()
        artifacts = []
        for ioc in iocs[:50]:  # Splunk SOAR recommends <50 artifacts per batch
            artifacts.append({
                "container_id": container_id,
                "name":         f"IOC: {ioc}",
                "label":        "artifact",
                "cef": {
                    "destinationDnsDomain": ioc if "." in ioc and not ioc.replace(".", "").isdigit() else None,
                    "destinationAddress":   ioc if ioc.replace(".", "").isdigit() else None,
                    "fileHash":             ioc if len(ioc) in (32, 40, 64) else None,
                },
                "tags": ["ioc", "soar-orchestrator"],
            })

        url = f"{self.base_url}/rest/artifact"
        async with session.post(url, json=artifacts, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            resp.raise_for_status()
            logger.debug("Splunk SOAR: %d IOC artifacts added to container %s", len(artifacts), container_id)

    # ------------------------------------------------------------------
    # Playbook execution
    # ------------------------------------------------------------------

    async def run_playbook(self, container_id: int, playbook_name: str) -> dict:
        """Trigger a named playbook on a container."""
        session = await self._get_session()
        url     = f"{self.base_url}/rest/playbook_run"
        payload = {
            "container_id": container_id,
            "playbook_id":  playbook_name,
            "scope":        "all",
            "run":          True,
        }
        async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            resp.raise_for_status()
            result = await resp.json()
            logger.info("Splunk SOAR: playbook '%s' triggered on container %s", playbook_name, container_id)
            return result

    async def get_action_results(self, action_run_id: int) -> dict:
        """Poll action run results."""
        session = await self._get_session()
        url     = f"{self.base_url}/rest/action_run/{action_run_id}"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
