"""
Alert Normalizer
Maps raw alert payloads from each platform into a unified NormalizedAlert schema.
Handles: Microsoft Sentinel, Splunk SOAR, Cortex XSOAR, Shuffle, CrowdStrike,
         SentinelOne, Microsoft Defender, Elastic SIEM, IBM QRadar, Palo Alto.
"""

import logging
import re
import json
from typing import Any
import uuid

logger = logging.getLogger("soar.utils.normalizer")


class AlertNormalizer:
    """
    Platform-agnostic normalization engine.
    Each platform has its own _normalize_* method.
    """

    SEVERITY_MAP: dict[str, str] = {
        # Sentinel
        "High":          "high",
        "Medium":        "medium",
        "Low":           "low",
        "Informational": "info",
        # CrowdStrike / SentinelOne
        "Critical":      "critical",
        "critical":      "critical",
        "high":          "high",
        "medium":        "medium",
        "low":           "low",
        # QRadar numeric
        "10": "critical", "9": "critical", "8": "high", "7": "high",
        "6":  "medium",   "5": "medium",   "4": "low",  "3": "low",
        "2":  "info",     "1": "info",
    }

    MITRE_TACTIC_PATTERNS: dict[str, str] = {
        r"lateral.movement":    "TA0008",
        r"exfiltration":        "TA0010",
        r"privilege.escal":     "TA0004",
        r"persistence":         "TA0003",
        r"defense.evasion":     "TA0005",
        r"discovery":           "TA0007",
        r"execution":           "TA0002",
        r"initial.access":      "TA0001",
        r"credential.access":   "TA0006",
        r"command.and.control": "TA0011",
        r"c2|c&c":              "TA0011",
        r"impact":              "TA0040",
    }

    # Regex patterns for IOC extraction
    IP_PATTERN   = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
    HASH_PATTERN = re.compile(r"\b[a-fA-F0-9]{32,64}\b")
    FQDN_PATTERN = re.compile(r"\b(?:[a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,}\b")
    URL_PATTERN  = re.compile(r"https?://[^\s\"'<>]+")

    def normalize(self, source: str, raw: dict) -> Any:
        """Dispatch to the correct normalizer based on source platform."""
        from orchestrator import NormalizedAlert

        normalizers = {
            "microsoft_sentinel": self._normalize_sentinel,
            "splunk_soar":        self._normalize_splunk_soar,
            "cortex_xsoar":       self._normalize_cortex_xsoar,
            "shuffle":            self._normalize_shuffle,
            "crowdstrike_falcon": self._normalize_crowdstrike,
            "sentinelone":        self._normalize_sentinelone,
            "microsoft_defender": self._normalize_defender,
            "elastic_siem":       self._normalize_elastic,
            "ibm_qradar":         self._normalize_qradar,
            "palo_alto_networks": self._normalize_palo_alto,
        }

        normalizer = normalizers.get(source, self._normalize_generic)
        alert      = normalizer(raw)
        alert.source = source

        # Universal IOC extraction from description if not already populated
        if not alert.iocs:
            alert.iocs = self._extract_iocs(alert.description + " " + json.dumps(raw))

        # MITRE tactic inference
        if not alert.mitre_tactics:
            alert.mitre_tactics = self._infer_mitre_tactics(alert.title + " " + alert.description)

        return alert

    # ------------------------------------------------------------------
    # Platform-specific normalizers
    # ------------------------------------------------------------------

    def _normalize_sentinel(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        entities     = self._parse_json_field(raw.get("Entities", "[]"))
        hosts        = [e.get("HostName", e.get("Address", "")) for e in entities if e.get("Type") in ("host", "ip")]
        users        = [e.get("Name", "") for e in entities if e.get("Type") == "account"]
        ext          = self._parse_json_field(raw.get("ExtendedProperties", "{}"))
        tactics      = [t.strip() for t in raw.get("Tactics", "").split(",") if t.strip()]

        return NormalizedAlert(
            alert_id       = raw.get("SystemAlertId", str(uuid.uuid4())),
            source         = "microsoft_sentinel",
            severity       = self.SEVERITY_MAP.get(raw.get("AlertSeverity", "Low"), "low"),
            title          = raw.get("AlertName", "Sentinel Alert"),
            description    = raw.get("Description", ""),
            raw_payload    = raw,
            affected_hosts = [h for h in hosts if h],
            affected_users = [u for u in users if u],
            mitre_tactics  = tactics,
        )

    def _normalize_splunk_soar(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        return NormalizedAlert(
            alert_id       = str(raw.get("id", uuid.uuid4())),
            source         = "splunk_soar",
            severity       = self.SEVERITY_MAP.get(raw.get("severity", "low"), "low"),
            title          = raw.get("name", "Splunk SOAR Container"),
            description    = raw.get("description", ""),
            raw_payload    = raw,
            affected_hosts = [],
            affected_users = [],
        )

    def _normalize_cortex_xsoar(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        labels     = {l["type"]: l["value"] for l in raw.get("labels", [])}
        severity   = {0: "info", 1: "low", 2: "medium", 3: "high", 4: "critical"}.get(
                        raw.get("severity", 1), "low")
        return NormalizedAlert(
            alert_id       = raw.get("id", str(uuid.uuid4())),
            source         = "cortex_xsoar",
            severity       = severity,
            title          = raw.get("name", "Cortex XSOAR Incident"),
            description    = raw.get("details", raw.get("name", "")),
            raw_payload    = raw,
            affected_hosts = [labels.get("hostname", "")] if labels.get("hostname") else [],
            affected_users = [labels.get("username", "")] if labels.get("username") else [],
        )

    def _normalize_crowdstrike(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        sev   = str(raw.get("max_severity", raw.get("severity", "50")))
        sev_n = "critical" if int(sev) >= 90 else "high" if int(sev) >= 70 else \
                "medium" if int(sev) >= 40 else "low"
        return NormalizedAlert(
            alert_id       = raw.get("composite_id", raw.get("id", str(uuid.uuid4()))),
            source         = "crowdstrike_falcon",
            severity       = sev_n,
            title          = raw.get("display_name", raw.get("name", "CrowdStrike Detection")),
            description    = raw.get("description", ""),
            raw_payload    = raw,
            affected_hosts = [raw["device"]["hostname"]] if raw.get("device", {}).get("hostname") else [],
            affected_users = [raw.get("user_name", "")] if raw.get("user_name") else [],
            iocs           = [b["indicator_value"] for b in raw.get("behaviors", []) if b.get("indicator_value")],
            mitre_tactics  = [raw.get("tactic_id", "")] if raw.get("tactic_id") else [],
        )

    def _normalize_sentinelone(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        data = raw.get("data", raw)
        sev_map = {"critical": "critical", "high": "high", "medium": "medium",
                   "low": "low", "suspicious": "medium"}
        return NormalizedAlert(
            alert_id       = data.get("id", str(uuid.uuid4())),
            source         = "sentinelone",
            severity       = sev_map.get(data.get("analystVerdictDescription", "low"), "low"),
            title          = data.get("threatInfo", {}).get("threatName", "SentinelOne Threat"),
            description    = data.get("threatInfo", {}).get("classification", ""),
            raw_payload    = raw,
            affected_hosts = [data.get("agentRealtimeInfo", {}).get("agentComputerName", "")],
            affected_users = [data.get("agentRealtimeInfo", {}).get("loggedInUserName", "")],
            iocs           = [data.get("threatInfo", {}).get("sha256", "")] if data.get("threatInfo", {}).get("sha256") else [],
        )

    def _normalize_defender(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        sev_map = {"Informational": "info", "Low": "low", "Medium": "medium",
                   "High": "high", "UnSpecified": "info"}
        entities = raw.get("entities", [])
        hosts    = [e.get("dnsName", e.get("hostName", "")) for e in entities if e.get("entityType") in ("Machine", "Ip")]
        users    = [e.get("accountName", "") for e in entities if e.get("entityType") == "User"]
        return NormalizedAlert(
            alert_id       = raw.get("id", str(uuid.uuid4())),
            source         = "microsoft_defender",
            severity       = sev_map.get(raw.get("severity", "Low"), "low"),
            title          = raw.get("title", "Defender Alert"),
            description    = raw.get("description", ""),
            raw_payload    = raw,
            affected_hosts = [h for h in hosts if h],
            affected_users = [u for u in users if u],
            mitre_tactics  = [raw.get("category", "")] if raw.get("category") else [],
        )

    def _normalize_elastic(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        src   = raw.get("_source", raw)
        sev   = src.get("kibana.alert.severity", src.get("signal.rule.severity", "low"))
        return NormalizedAlert(
            alert_id       = raw.get("_id", str(uuid.uuid4())),
            source         = "elastic_siem",
            severity       = self.SEVERITY_MAP.get(sev.capitalize(), "low"),
            title          = src.get("kibana.alert.rule.name", src.get("signal.rule.name", "Elastic Alert")),
            description    = src.get("kibana.alert.reason", src.get("signal.reason", "")),
            raw_payload    = raw,
            affected_hosts = [src.get("host.hostname", src.get("host.name", ""))],
            affected_users = [src.get("user.name", "")],
        )

    def _normalize_qradar(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        mag = str(raw.get("magnitude", "5"))
        sev = "critical" if int(mag) >= 9 else "high" if int(mag) >= 7 else \
              "medium" if int(mag) >= 5 else "low"
        return NormalizedAlert(
            alert_id       = str(raw.get("id", uuid.uuid4())),
            source         = "ibm_qradar",
            severity       = sev,
            title          = raw.get("description", "QRadar Offense"),
            description    = raw.get("offense_source", ""),
            raw_payload    = raw,
            affected_hosts = [raw.get("offense_source", "")],
            affected_users = [],
        )

    def _normalize_palo_alto(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        sev_map = {"critical": "critical", "high": "high", "medium": "medium",
                   "low": "low", "informational": "info"}
        return NormalizedAlert(
            alert_id       = raw.get("id", str(uuid.uuid4())),
            source         = "palo_alto_networks",
            severity       = sev_map.get(raw.get("severity", "low"), "low"),
            title          = raw.get("name", raw.get("alert_name", "Palo Alto Alert")),
            description    = raw.get("description", raw.get("details", "")),
            raw_payload    = raw,
            affected_hosts = [raw.get("src_ip", ""), raw.get("dst_ip", "")],
            affected_users = [raw.get("src_user", "")] if raw.get("src_user") else [],
        )

    def _normalize_generic(self, raw: dict) -> Any:
        from orchestrator import NormalizedAlert
        return NormalizedAlert(
            alert_id    = str(raw.get("id", uuid.uuid4())),
            source      = "unknown",
            severity    = self.SEVERITY_MAP.get(str(raw.get("severity", "low")), "low"),
            title       = str(raw.get("title", raw.get("name", raw.get("alert_name", "Unknown Alert")))),
            description = str(raw.get("description", raw.get("details", ""))),
            raw_payload = raw,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _parse_json_field(self, value: Any, default: Any = None):
        if isinstance(value, (dict, list)):
            return value
        if default is None:
            default = []
        try:
            return json.loads(value)
        except Exception:
            return default

    def _extract_iocs(self, text: str) -> list[str]:
        iocs = set()
        iocs.update(self.IP_PATTERN.findall(text))
        iocs.update(self.HASH_PATTERN.findall(text))
        iocs.update(self.URL_PATTERN.findall(text))
        # Exclude private RFC1918 ranges
        iocs = {ioc for ioc in iocs if not any(
            ioc.startswith(p) for p in ("10.", "192.168.", "172.16.", "127.")
        )}
        return list(iocs)[:100]

    def _infer_mitre_tactics(self, text: str) -> list[str]:
        text_lower = text.lower()
        tactics    = []
        for pattern, tactic_id in self.MITRE_TACTIC_PATTERNS.items():
            if re.search(pattern, text_lower):
                tactics.append(tactic_id)
        return list(set(tactics))
