"""
ML-Based Alert Severity Scorer
Uses a trained Random Forest model (with fallback heuristics) to compute
a continuous risk score [0.0 – 1.0] for each normalized alert.
Features include: IOC count, MITRE tactic coverage, asset criticality,
user privilege level, time-of-day anomaly, and historical alert frequency.
"""

import logging
import os
import pickle
import numpy as np
from datetime import datetime, timezone

logger = logging.getLogger("soar.utils.scorer")


class MLSeverityScorer:
    """
    Risk scorer that returns a float in [0.0, 1.0].
    Loads a pre-trained sklearn model if available; otherwise uses
    a weighted heuristic model that can be used for initial training data collection.
    """

    SEVERITY_BASE: dict[str, float] = {
        "critical": 0.90,
        "high":     0.70,
        "medium":   0.45,
        "low":      0.20,
        "info":     0.05,
    }

    # MITRE tactics ordered by typical attack-chain severity
    HIGH_IMPACT_TACTICS = {
        "TA0040",  # Impact
        "TA0010",  # Exfiltration
        "TA0006",  # Credential Access
        "TA0004",  # Privilege Escalation
        "TA0011",  # Command & Control
        "TA0008",  # Lateral Movement
    }

    PRIVILEGED_ROLES = {
        "admin", "administrator", "root", "sysadmin", "dba", "devops",
        "serviceaccount", "svc_", "azure-ad-admin", "global admin",
        "security admin", "privileged identity",
    }

    def __init__(self, model_path: str = "models/severity_model.pkl"):
        self.model = None
        self.scaler = None

        if os.path.isfile(model_path):
            try:
                with open(model_path, "rb") as f:
                    bundle      = pickle.load(f)
                    self.model  = bundle.get("model")
                    self.scaler = bundle.get("scaler")
                logger.info("ML severity model loaded from %s", model_path)
            except Exception as exc:
                logger.warning("Could not load ML model (%s) — using heuristic scorer", exc)
        else:
            logger.info("No ML model found at %s — using heuristic scorer", model_path)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def score(self, alert) -> float:
        """Return a risk score [0.0 – 1.0] for the given NormalizedAlert."""
        features = self._extract_features(alert)

        if self.model is not None:
            try:
                x = np.array(features).reshape(1, -1)
                if self.scaler:
                    x = self.scaler.transform(x)
                score = float(self.model.predict_proba(x)[0][1])
                return min(max(score, 0.0), 1.0)
            except Exception as exc:
                logger.warning("ML scoring failed (%s) — falling back to heuristic", exc)

        return self._heuristic_score(alert, features)

    # ------------------------------------------------------------------
    # Feature extraction  (shared by ML model and heuristic)
    # ------------------------------------------------------------------

    def _extract_features(self, alert) -> list[float]:
        """
        Returns a fixed-length feature vector:
        [0]  base_severity      (0.0–1.0 from severity string)
        [1]  ioc_count          (clamped 0–50 → 0.0–1.0)
        [2]  high_impact_tactic (1.0 if any TA0040/TA0010/TA0006/TA0004 present)
        [3]  tactic_count       (0.0–1.0 of up to 11 MITRE tactics)
        [4]  host_count         (clamped 0–10 → 0.0–1.0)
        [5]  user_count         (clamped 0–10 → 0.0–1.0)
        [6]  privileged_user    (1.0 if any affected user looks privileged)
        [7]  off_hours          (1.0 if alert triggered outside 08:00–18:00)
        [8]  enrichment_hits    (1.0 if threat intel marked IOCs as known-bad)
        [9]  lateral_movement   (1.0 if TA0008 in tactics)
        [10] exfiltration       (1.0 if TA0010 in tactics)
        """
        sev_base        = self.SEVERITY_BASE.get(getattr(alert, "severity", "low"), 0.2)
        iocs            = getattr(alert, "iocs", []) or []
        tactics         = set(getattr(alert, "mitre_tactics", []) or [])
        hosts           = getattr(alert, "affected_hosts", []) or []
        users           = getattr(alert, "affected_users", []) or []
        enrichments     = getattr(alert, "enrichments", {}) or {}
        timestamp_str   = getattr(alert, "timestamp", "")

        ioc_score       = min(len(iocs), 50) / 50.0
        high_impact     = 1.0 if (tactics & self.HIGH_IMPACT_TACTICS) else 0.0
        tactic_score    = min(len(tactics), 11) / 11.0
        host_score      = min(len(hosts), 10) / 10.0
        user_score      = min(len(users), 10) / 10.0
        privileged      = self._is_privileged_user(users)
        off_hours       = self._is_off_hours(timestamp_str)
        enrichment_hit  = 1.0 if enrichments.get("threat_intel", {}).get("malicious_count", 0) > 0 else 0.0
        lateral         = 1.0 if "TA0008" in tactics else 0.0
        exfil           = 1.0 if "TA0010" in tactics else 0.0

        return [sev_base, ioc_score, high_impact, tactic_score, host_score,
                user_score, privileged, off_hours, enrichment_hit, lateral, exfil]

    # ------------------------------------------------------------------
    # Heuristic fallback
    # ------------------------------------------------------------------

    def _heuristic_score(self, alert, features: list[float]) -> float:
        """
        Weighted linear combination of features.
        Weights tuned from empirical SOC triage data.
        """
        weights = [0.30, 0.08, 0.12, 0.06, 0.05, 0.05, 0.10, 0.04, 0.12, 0.05, 0.03]
        score   = sum(w * f for w, f in zip(weights, features))
        score   = min(max(score, 0.0), 1.0)

        logger.debug(
            "Heuristic score for alert [%s]: %.3f",
            getattr(alert, "alert_id", "?"), score
        )
        return round(score, 4)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _is_privileged_user(self, users: list[str]) -> float:
        if not users:
            return 0.0
        lowered = " ".join(u.lower() for u in users if u)
        for role in self.PRIVILEGED_ROLES:
            if role in lowered:
                return 1.0
        return 0.0

    def _is_off_hours(self, timestamp_str: str) -> float:
        try:
            ts   = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
            hour = ts.hour
            return 1.0 if (hour < 8 or hour >= 18) else 0.0
        except Exception:
            return 0.0

    # ------------------------------------------------------------------
    # Model training utilities
    # ------------------------------------------------------------------

    def train(self, labeled_alerts: list[tuple], save_path: str = "models/severity_model.pkl"):
        """
        Train a Random Forest classifier on labeled alert data.
        labeled_alerts: list of (NormalizedAlert, is_true_positive: bool)
        """
        from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
        from sklearn.preprocessing import StandardScaler
        from sklearn.model_selection import cross_val_score
        import pickle

        X = np.array([self._extract_features(a) for a, _ in labeled_alerts])
        y = np.array([int(label) for _, label in labeled_alerts])

        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        model  = GradientBoostingClassifier(
            n_estimators=200, max_depth=4, learning_rate=0.05, random_state=42
        )
        scores = cross_val_score(model, X_scaled, y, cv=5, scoring="roc_auc")
        model.fit(X_scaled, y)

        logger.info("Training complete. CV AUC: %.3f ± %.3f", scores.mean(), scores.std())

        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        with open(save_path, "wb") as f:
            pickle.dump({"model": model, "scaler": scaler, "cv_auc": scores.mean()}, f)

        self.model  = model
        self.scaler = scaler
        logger.info("Model saved to %s", save_path)
        return scores
