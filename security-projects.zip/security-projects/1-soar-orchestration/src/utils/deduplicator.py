"""
Alert Deduplicator
TTL-based fingerprint cache that prevents the same alert from being processed
multiple times within the configured window. Thread-safe and memory-bounded.
"""

import hashlib
import logging
import time
from collections import OrderedDict
from threading import Lock

logger = logging.getLogger("soar.utils.deduplicator")

# Maximum number of fingerprints held in memory regardless of TTL
_MAX_CACHE_SIZE = 50_000


class AlertDeduplicator:
    """
    Deduplicates normalized alerts using a SHA-256 fingerprint of key fields.
    Fingerprints expire after `ttl_hours` and are evicted LRU when the cache
    exceeds _MAX_CACHE_SIZE entries.

    Thread-safe: uses a lightweight lock; all operations are O(1) amortised.
    """

    def __init__(self, ttl_hours: float = 24):
        self._ttl_seconds = ttl_hours * 3600
        # OrderedDict preserves insertion order for LRU eviction
        self._cache: OrderedDict[str, float] = OrderedDict()
        self._lock  = Lock()
        self._total_seen       = 0
        self._total_duplicates = 0

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def is_duplicate(self, alert) -> bool:
        """
        Return True if this alert has been seen within the TTL window.
        Registers the fingerprint on first encounter.
        """
        fp = self._fingerprint(alert)
        with self._lock:
            self._total_seen += 1
            now = time.monotonic()

            if fp in self._cache:
                if now < self._cache[fp]:
                    # Still within TTL — genuine duplicate
                    self._total_duplicates += 1
                    logger.debug("Duplicate suppressed: %s (fp=%s…)", getattr(alert, "alert_id", "?"), fp[:12])
                    return True
                # TTL expired — treat as new and refresh
                del self._cache[fp]

            # Register new fingerprint
            self._cache[fp] = now + self._ttl_seconds
            self._cache.move_to_end(fp)
            self._evict_if_needed()
            return False

    def force_expire(self, alert) -> bool:
        """
        Immediately expire a fingerprint so the alert can be re-processed.
        Returns True if the fingerprint was present and removed.
        """
        fp = self._fingerprint(alert)
        with self._lock:
            if fp in self._cache:
                del self._cache[fp]
                return True
            return False

    def purge_expired(self) -> int:
        """Remove all expired entries. Returns count of removed entries."""
        now     = time.monotonic()
        removed = 0
        with self._lock:
            expired = [fp for fp, expiry in self._cache.items() if expiry <= now]
            for fp in expired:
                del self._cache[fp]
                removed += 1
        if removed:
            logger.debug("Deduplicator: purged %d expired fingerprints", removed)
        return removed

    @property
    def stats(self) -> dict:
        with self._lock:
            size = len(self._cache)
        return {
            "cache_size":       size,
            "total_seen":       self._total_seen,
            "total_duplicates": self._total_duplicates,
            "ttl_hours":        self._ttl_seconds / 3600,
        }

    # ------------------------------------------------------------------
    # Fingerprint construction
    # ------------------------------------------------------------------

    def _fingerprint(self, alert) -> str:
        """
        Build a stable SHA-256 fingerprint from the alert's key identity fields.
        Two alerts with the same source, title, and primary affected entity
        are considered the same event within the TTL window.
        """
        source  = str(getattr(alert, "source", ""))
        title   = str(getattr(alert, "title", "")).strip().lower()
        sev     = str(getattr(alert, "severity", ""))

        # Use alert_id if it looks like a real unique ID from the platform
        alert_id = str(getattr(alert, "alert_id", ""))

        # Primary affected entity (first host or user)
        hosts = getattr(alert, "affected_hosts", []) or []
        users = getattr(alert, "affected_users", []) or []
        primary_entity = (hosts[0] if hosts else users[0] if users else "").lower()

        # Primary IOC (first in list, if any)
        iocs       = getattr(alert, "iocs", []) or []
        primary_ioc = iocs[0] if iocs else ""

        key = "|".join([source, title, sev, primary_entity, primary_ioc, alert_id])
        return hashlib.sha256(key.encode()).hexdigest()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _evict_if_needed(self):
        """Evict the oldest entries when cache exceeds the size cap."""
        while len(self._cache) > _MAX_CACHE_SIZE:
            self._cache.popitem(last=False)
