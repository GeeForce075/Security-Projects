"""
SOAR Orchestration Engine
Unified connector for Microsoft Sentinel, Splunk SOAR, Cortex XSOAR, and Shuffle SOAR.
Routes alerts, triggers playbooks, and correlates incidents across platforms.
"""

import asyncio
import logging
import json
from datetime import datetime, timezone
from typing import Any
from dataclasses import dataclass, field, asdict
from enum import Enum

from connectors.sentinel import SentinelConnector
from connectors.splunk_soar import SplunkSOARConnector
from connectors.cortex_xsoar import CortexXSOARConnector
from connectors.shuffle import ShuffleConnector
from connectors.crowdstrike import CrowdStrikeConnector
from playbooks.playbook_engine import PlaybookEngine
from playbooks.action_handlers import register_all as register_playbook_handlers
from utils.alert_normalizer import AlertNormalizer
from utils.deduplicator import AlertDeduplicator
from utils.severity_scorer import MLSeverityScorer

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger("soar.orchestrator")


class AlertSeverity(Enum):
    CRITICAL = "critical"
    HIGH     = "high"
    MEDIUM   = "medium"
    LOW      = "low"
    INFO     = "info"


class AlertSource(Enum):
    SENTINEL       = "microsoft_sentinel"
    SPLUNK         = "splunk_soar"
    CORTEX         = "cortex_xsoar"
    SHUFFLE        = "shuffle"
    CROWDSTRIKE    = "crowdstrike_falcon"
    SENTINELONE    = "sentinelone"
    DEFENDER       = "microsoft_defender"
    ELASTIC        = "elastic_siem"
    QRADAR         = "ibm_qradar"
    PALO_ALTO      = "palo_alto_networks"


@dataclass
class NormalizedAlert:
    alert_id:      str
    source:        str
    severity:      str
    title:         str
    description:   str
    raw_payload:   dict
    timestamp:     str           = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    iocs:          list[str]     = field(default_factory=list)
    affected_hosts:list[str]     = field(default_factory=list)
    affected_users:list[str]     = field(default_factory=list)
    mitre_tactics: list[str]     = field(default_factory=list)
    ml_risk_score: float         = 0.0
    playbook_id:   str | None    = None
    enrichments:   dict          = field(default_factory=dict)
    deduplicated:  bool          = False


class SOAROrchestrator:
    """
    Central orchestration engine. Polls all connected SOAR/SIEM platforms,
    normalizes alerts, deduplicates, scores with ML, and routes to playbooks.
    """

    def __init__(self, config: dict):
        self.config     = config
        self.normalizer = AlertNormalizer()
        self.deduper    = AlertDeduplicator(ttl_hours=config.get("dedup_ttl_hours", 24))
        self.scorer     = MLSeverityScorer(model_path=config.get("ml_model_path", "models/severity_model.pkl"))
        self.playbooks  = PlaybookEngine(playbook_dir=config.get("playbook_dir", "playbooks/definitions"))

        self.connectors: dict[str, Any] = {}
        self._init_connectors()

    # ------------------------------------------------------------------
    # Connector initialisation
    # ------------------------------------------------------------------

    def _init_connectors(self):
        cfg = self.config.get("connectors", {})

        if cfg.get("sentinel", {}).get("enabled"):
            self.connectors[AlertSource.SENTINEL.value] = SentinelConnector(cfg["sentinel"])
            logger.info("Connector initialised: Microsoft Sentinel")

        if cfg.get("splunk_soar", {}).get("enabled"):
            self.connectors[AlertSource.SPLUNK.value] = SplunkSOARConnector(cfg["splunk_soar"])
            logger.info("Connector initialised: Splunk SOAR")

        if cfg.get("cortex_xsoar", {}).get("enabled"):
            self.connectors[AlertSource.CORTEX.value] = CortexXSOARConnector(cfg["cortex_xsoar"])
            logger.info("Connector initialised: Cortex XSOAR")

        if cfg.get("shuffle", {}).get("enabled"):
            self.connectors[AlertSource.SHUFFLE.value] = ShuffleConnector(cfg["shuffle"])
            logger.info("Connector initialised: Shuffle SOAR")

        if cfg.get("crowdstrike", {}).get("enabled"):
            self.connectors[AlertSource.CROWDSTRIKE.value] = CrowdStrikeConnector(cfg["crowdstrike"])
            logger.info("Connector initialised: CrowdStrike Falcon")

        # Wire all playbook action handlers to live connectors
        register_playbook_handlers(self.playbooks, self.connectors, self.config)
        logger.info("Playbook action handlers wired to live connectors")

    # ------------------------------------------------------------------
    # Main event loop
    # ------------------------------------------------------------------

    async def run(self):
        logger.info("SOAR Orchestrator starting — %d connectors active", len(self.connectors))
        poll_interval = self.config.get("poll_interval_seconds", 30)

        while True:
            tasks = [
                self._poll_and_process(name, connector)
                for name, connector in self.connectors.items()
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for name, result in zip(self.connectors.keys(), results):
                if isinstance(result, Exception):
                    logger.error("Error polling %s: %s", name, result)

            await asyncio.sleep(poll_interval)

    async def _poll_and_process(self, source_name: str, connector):
        raw_alerts = await connector.fetch_alerts()
        logger.info("Fetched %d raw alerts from %s", len(raw_alerts), source_name)

        for raw in raw_alerts:
            try:
                alert = self.normalizer.normalize(source_name, raw)
                if self.deduper.is_duplicate(alert):
                    alert.deduplicated = True
                    continue

                alert.ml_risk_score = self.scorer.score(alert)
                alert = await self._enrich_alert(alert)
                alert.playbook_id   = self.playbooks.select_playbook(alert)

                await self.playbooks.execute(alert)
                await self._route_to_platforms(alert)

                logger.info(
                    "Processed alert [%s] sev=%s score=%.2f playbook=%s",
                    alert.alert_id, alert.severity, alert.ml_risk_score, alert.playbook_id
                )

            except Exception as exc:
                logger.exception("Failed processing alert from %s: %s", source_name, exc)

    # ------------------------------------------------------------------
    # Enrichment
    # ------------------------------------------------------------------

    async def _enrich_alert(self, alert: NormalizedAlert) -> NormalizedAlert:
        """Enrich IOCs with threat intel, GeoIP, WHOIS, and asset context."""
        enrichment_tasks = []

        if alert.iocs:
            enrichment_tasks.append(self._enrich_threat_intel(alert.iocs))

        if alert.affected_hosts:
            enrichment_tasks.append(self._enrich_asset_context(alert.affected_hosts))

        if alert.affected_users:
            enrichment_tasks.append(self._enrich_identity_context(alert.affected_users))

        if enrichment_tasks:
            enrichments = await asyncio.gather(*enrichment_tasks, return_exceptions=True)
            for result in enrichments:
                if isinstance(result, dict):
                    alert.enrichments.update(result)

        return alert

    async def _enrich_threat_intel(self, iocs: list[str]) -> dict:
        """Query VirusTotal, MISP, AlienVault OTX for IOC reputation."""
        # Implemented in utils/threat_intel.py — pluggable per environment
        return {"threat_intel": {"ioc_count": len(iocs), "checked": True}}

    async def _enrich_asset_context(self, hosts: list[str]) -> dict:
        """Cross-reference hosts against CMDB / AD / cloud asset inventory."""
        return {"asset_context": {"hosts": hosts, "enriched": True}}

    async def _enrich_identity_context(self, users: list[str]) -> dict:
        """Fetch user risk score from Azure AD Identity Protection / Okta."""
        return {"identity_context": {"users": users, "enriched": True}}

    # ------------------------------------------------------------------
    # Cross-platform routing
    # ------------------------------------------------------------------

    async def _route_to_platforms(self, alert: NormalizedAlert):
        """Route processed alert back to relevant platforms as incidents."""
        severity = alert.severity
        score    = alert.ml_risk_score

        # Critical / High → all platforms get incident created
        if severity in (AlertSeverity.CRITICAL.value, AlertSeverity.HIGH.value) or score >= 0.75:
            tasks = [
                connector.create_incident(asdict(alert))
                for connector in self.connectors.values()
                if hasattr(connector, "create_incident")
            ]
            await asyncio.gather(*tasks, return_exceptions=True)

        # Medium → primary SOAR only
        elif severity == AlertSeverity.MEDIUM.value or score >= 0.50:
            primary = self.config.get("primary_soar", AlertSource.SENTINEL.value)
            if primary in self.connectors:
                await self.connectors[primary].create_incident(asdict(alert))


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------

def load_config(path: str = "config/orchestrator.yaml") -> dict:
    import yaml
    with open(path) as f:
        return yaml.safe_load(f)


if __name__ == "__main__":
    config = load_config()
    orchestrator = SOAROrchestrator(config)
    asyncio.run(orchestrator.run())
