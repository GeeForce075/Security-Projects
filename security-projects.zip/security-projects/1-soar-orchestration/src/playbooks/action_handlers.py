"""
Action Handlers
Wires every playbook action name to a real implementation.
Call register_all(engine, connectors, config) once at startup — after that
the PlaybookEngine dispatches live actions automatically.
"""

import asyncio
import json
import logging
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Any

import aiohttp

logger = logging.getLogger("soar.playbooks.handlers")


# ---------------------------------------------------------------------------
# Registration entry point
# ---------------------------------------------------------------------------

def register_all(engine, connectors: dict, config: dict):
    """
    Bind every action name used across all playbook definitions to a live
    implementation.

    engine     — PlaybookEngine instance
    connectors — dict of {source_name: ConnectorInstance} from SOAROrchestrator
    config     — full orchestrator config dict (for notification endpoints etc.)
    """
    notif  = config.get("notifications", {})
    ti     = config.get("threat_intel", {})
    assets = config.get("asset_tags", {})

    # ── Logging ────────────────────────────────────────────────────────
    engine.register_handler("log_alert",             _log_alert())

    # ── Notifications ──────────────────────────────────────────────────
    engine.register_handler("notify_slack",          _notify_slack(notif.get("slack", {})))
    engine.register_handler("notify_teams",          _notify_teams(notif.get("teams", {})))
    engine.register_handler("notify_pagerduty",      _notify_pagerduty(notif.get("pagerduty", {})))
    engine.register_handler("send_email",            _send_email(notif.get("smtp", {})))

    # ── Ticketing ──────────────────────────────────────────────────────
    engine.register_handler("create_ticket_jira",         _create_jira_ticket(notif.get("jira", {})))
    engine.register_handler("create_ticket_servicenow",   _create_snow_ticket(notif.get("servicenow", {})))

    # ── EDR: CrowdStrike ───────────────────────────────────────────────
    cs = connectors.get("crowdstrike_falcon")
    engine.register_handler("isolate_host_crowdstrike",   _isolate_crowdstrike(cs))

    # ── EDR: SentinelOne ──────────────────────────────────────────────
    s1_cfg = config.get("connectors", {}).get("sentinelone", {})
    engine.register_handler("isolate_host_sentinelone",   _isolate_sentinelone(s1_cfg))

    # ── Network / Firewall ─────────────────────────────────────────────
    fw_cfg = config.get("connectors", {}).get("firewall", {})
    engine.register_handler("block_ip_firewall",          _block_ip(fw_cfg, connectors))

    # ── Identity ───────────────────────────────────────────────────────
    sentinel = connectors.get("microsoft_sentinel")
    engine.register_handler("revoke_user_sessions",       _revoke_sessions(sentinel, config))
    engine.register_handler("disable_user_account",       _disable_account(config))
    engine.register_handler("reset_user_mfa",             _reset_mfa(config))

    # ── Email security ─────────────────────────────────────────────────
    engine.register_handler("block_email_sender",         _block_email_sender(config))
    engine.register_handler("quarantine_email",           _quarantine_email(config))

    # ── SOAR platform actions ──────────────────────────────────────────
    engine.register_handler("run_sentinel_playbook",      _run_sentinel_playbook(sentinel))
    engine.register_handler("run_xsoar_playbook",         _run_xsoar_playbook(
        connectors.get("cortex_xsoar")))

    # ── Threat intelligence ────────────────────────────────────────────
    engine.register_handler("enrich_virustotal",          _enrich_virustotal(ti.get("virustotal", {})))
    engine.register_handler("enrich_misp",                _enrich_misp(ti.get("misp", {})))

    # ── Asset management ───────────────────────────────────────────────
    engine.register_handler("update_watchlist",           _update_watchlist(sentinel))
    engine.register_handler("tag_asset_high_risk",        _tag_asset(assets))

    # ── Forensics ─────────────────────────────────────────────────────
    engine.register_handler("collect_memory_dump",        _collect_memory_dump(cs))
    engine.register_handler("snapshot_host",              _snapshot_host(config))

    # ── Lifecycle ─────────────────────────────────────────────────────
    engine.register_handler("close_alert",                _close_alert(connectors))

    logger.info("Action handlers registered: %d actions wired", 25)


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def _log_alert():
    async def handler(alert, params: dict):
        tag = params.get("tag", "")
        logger.info(
            "[PLAYBOOK] alert_id=%s severity=%s score=%.3f source=%s tag=%s title=%s",
            getattr(alert, "alert_id", "?"),
            getattr(alert, "severity", "?"),
            getattr(alert, "ml_risk_score", 0),
            getattr(alert, "source", "?"),
            tag,
            getattr(alert, "title", "?"),
        )
    return handler


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------

def _notify_slack(cfg: dict):
    async def handler(alert, params: dict):
        webhook = params.get("webhook_url") or cfg.get("webhook_url")
        channel = params.get("channel") or cfg.get("default_channel", "#soc-alerts")
        if not webhook:
            logger.warning("notify_slack: no webhook_url configured")
            return

        raw_msg = params.get("message", "Alert received")
        message = _interpolate(raw_msg, alert)

        payload = {
            "channel": channel,
            "text":    message,
            "attachments": [{
                "color":  _slack_color(getattr(alert, "severity", "low")),
                "fields": [
                    {"title": "Alert ID",   "value": getattr(alert, "alert_id", ""),   "short": True},
                    {"title": "Severity",   "value": getattr(alert, "severity", ""),   "short": True},
                    {"title": "Risk Score", "value": f"{getattr(alert, 'ml_risk_score', 0):.3f}", "short": True},
                    {"title": "Source",     "value": getattr(alert, "source", ""),     "short": True},
                    {"title": "Hosts",      "value": ", ".join(getattr(alert, "affected_hosts", []) or []), "short": False},
                    {"title": "Users",      "value": ", ".join(getattr(alert, "affected_users", []) or []), "short": False},
                ],
            }],
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(webhook, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status not in (200, 204):
                    text = await resp.text()
                    logger.warning("Slack notification failed (%d): %s", resp.status, text[:200])
                else:
                    logger.info("Slack notification sent to %s", channel)
    return handler


def _notify_teams(cfg: dict):
    async def handler(alert, params: dict):
        webhook = params.get("webhook_url") or cfg.get("webhook_url")
        if not webhook:
            logger.warning("notify_teams: no webhook_url configured")
            return

        raw_msg = params.get("message", "Alert received")
        message = _interpolate(raw_msg, alert)
        color   = {"critical": "FF0000", "high": "FF6600", "medium": "FFCC00",
                   "low": "00CC00", "info": "0099FF"}.get(
                       getattr(alert, "severity", "low"), "888888")

        payload = {
            "@type":      "MessageCard",
            "@context":   "http://schema.org/extensions",
            "themeColor": color,
            "summary":    message,
            "sections": [{
                "activityTitle": f"🚨 {getattr(alert, 'title', 'Security Alert')}",
                "activityText":  message,
                "facts": [
                    {"name": "Severity",   "value": getattr(alert, "severity", "")},
                    {"name": "Risk Score", "value": f"{getattr(alert, 'ml_risk_score', 0):.3f}"},
                    {"name": "Source",     "value": getattr(alert, "source", "")},
                    {"name": "Alert ID",   "value": getattr(alert, "alert_id", "")},
                ],
            }],
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(webhook, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status not in (200, 204):
                    logger.warning("Teams notification failed: %d", resp.status)
                else:
                    logger.info("Teams notification sent")
    return handler


def _notify_pagerduty(cfg: dict):
    async def handler(alert, params: dict):
        routing_key = params.get("routing_key") or cfg.get("routing_key")
        if not routing_key:
            logger.warning("notify_pagerduty: no routing_key configured")
            return

        sev_map = {"critical": "critical", "high": "error", "medium": "warning",
                   "low": "info", "info": "info"}
        pd_sev  = sev_map.get(getattr(alert, "severity", "low"), "warning")

        dedup_key = (
            params.get("dedup_key_prefix", "soar")
            + "-" + getattr(alert, "alert_id", "unknown")
        )

        payload = {
            "routing_key":  routing_key,
            "event_action": "trigger",
            "dedup_key":    dedup_key,
            "payload": {
                "summary":   getattr(alert, "title", "Security Alert"),
                "severity":  pd_sev,
                "source":    getattr(alert, "source", "soar-orchestrator"),
                "timestamp": getattr(alert, "timestamp", ""),
                "custom_details": {
                    "alert_id":      getattr(alert, "alert_id", ""),
                    "ml_risk_score": getattr(alert, "ml_risk_score", 0),
                    "affected_hosts":getattr(alert, "affected_hosts", []),
                    "affected_users":getattr(alert, "affected_users", []),
                    "mitre_tactics": getattr(alert, "mitre_tactics", []),
                    "ioc_count":     len(getattr(alert, "iocs", []) or []),
                },
            },
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://events.pagerduty.com/v2/enqueue",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status != 202:
                    logger.warning("PagerDuty trigger failed: %d", resp.status)
                else:
                    logger.info("PagerDuty event triggered: dedup_key=%s", dedup_key)
    return handler


def _send_email(cfg: dict):
    async def handler(alert, params: dict):
        host     = cfg.get("host")
        port     = cfg.get("port", 587)
        username = cfg.get("username")
        password = cfg.get("password")
        from_addr= cfg.get("from_address", username)
        to_addrs = params.get("to") or cfg.get("default_to", [])

        if not host or not to_addrs:
            logger.warning("send_email: smtp host or recipients not configured")
            return

        template = params.get("template", "generic_alert")
        subject, body = _render_email_template(template, alert, params)

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = from_addr
        msg["To"]      = ", ".join(to_addrs) if isinstance(to_addrs, list) else to_addrs
        msg.attach(MIMEText(body, "html"))

        def _send():
            ctx = ssl.create_default_context()
            with smtplib.SMTP(host, port) as smtp:
                smtp.ehlo()
                smtp.starttls(context=ctx)
                if username and password:
                    smtp.login(username, password)
                smtp.sendmail(from_addr, to_addrs, msg.as_string())

        await asyncio.to_thread(_send)
        logger.info("Email sent: template=%s to=%s", template, to_addrs)
    return handler


# ---------------------------------------------------------------------------
# Ticketing
# ---------------------------------------------------------------------------

def _create_jira_ticket(cfg: dict):
    async def handler(alert, params: dict):
        base_url = cfg.get("base_url")
        token    = cfg.get("api_token")
        email    = cfg.get("email")
        if not base_url or not token:
            logger.warning("create_ticket_jira: not configured")
            return

        project    = params.get("project", cfg.get("default_project", "SEC"))
        issue_type = params.get("issue_type", "Task")
        priority   = params.get("priority", "Medium")

        pri_map = {1: "Highest", 2: "High", 3: "Medium", 4: "Low", 5: "Lowest",
                   "High": "High", "Medium": "Medium", "Low": "Low"}
        jira_pri = pri_map.get(priority, "Medium")

        payload = {
            "fields": {
                "project":   {"key": project},
                "issuetype": {"name": issue_type},
                "summary":   f"[SOAR] {getattr(alert, 'title', 'Security Alert')}",
                "priority":  {"name": jira_pri},
                "description": {
                    "type":    "doc",
                    "version": 1,
                    "content": [{
                        "type":    "paragraph",
                        "content": [{"type": "text", "text": _alert_summary_text(alert)}],
                    }],
                },
                "labels": ["soar-generated", getattr(alert, "severity", "low")],
            }
        }

        import base64
        auth = base64.b64encode(f"{email}:{token}".encode()).decode()
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{base_url}/rest/api/3/issue",
                json=payload,
                headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                data = await resp.json()
                if resp.status == 201:
                    logger.info("Jira ticket created: %s", data.get("key"))
                else:
                    logger.warning("Jira ticket creation failed (%d): %s", resp.status, data)
    return handler


def _create_snow_ticket(cfg: dict):
    async def handler(alert, params: dict):
        instance = cfg.get("instance")   # e.g. "mycompany"
        username = cfg.get("username")
        password = cfg.get("password")
        if not instance or not username:
            logger.warning("create_ticket_servicenow: not configured")
            return

        pri_map  = {1: "1", 2: "2", 3: "3", 4: "4", "High": "2", "Medium": "3", "Low": "4"}
        priority = pri_map.get(params.get("priority", 3), "3")
        category = params.get("category", "security")
        group    = params.get("assignment_group", cfg.get("default_assignment_group", ""))

        payload = {
            "short_description": f"[SOAR] {getattr(alert, 'title', 'Security Alert')}",
            "description":       _alert_summary_text(alert),
            "category":          category,
            "priority":          priority,
            "assignment_group":  group,
            "state":             "1",           # New
            "impact":            priority,
            "urgency":           priority,
            "u_soar_alert_id":   getattr(alert, "alert_id", ""),
            "u_risk_score":      str(round(getattr(alert, "ml_risk_score", 0), 4)),
        }
        if params.get("legal_hold"):
            payload["u_legal_hold"] = "true"

        import base64
        auth = base64.b64encode(f"{username}:{password}".encode()).decode()
        url  = f"https://{instance}.service-now.com/api/now/table/incident"

        async with aiohttp.ClientSession() as session:
            async with session.post(
                url, json=payload,
                headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json",
                         "Accept": "application/json"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                data = await resp.json()
                if resp.status == 201:
                    logger.info("ServiceNow incident created: %s",
                                data.get("result", {}).get("number"))
                else:
                    logger.warning("ServiceNow creation failed (%d): %s", resp.status, data)
    return handler


# ---------------------------------------------------------------------------
# EDR
# ---------------------------------------------------------------------------

def _isolate_crowdstrike(cs_connector):
    async def handler(alert, params: dict):
        if not cs_connector:
            logger.warning("isolate_host_crowdstrike: CrowdStrike connector not available")
            return
        hosts = getattr(alert, "affected_hosts", []) or []
        if not hosts:
            logger.warning("isolate_host_crowdstrike: no affected hosts in alert")
            return
        reason = params.get("reason", "soar_playbook")
        for host in hosts[:5]:          # cap at 5 hosts per playbook action
            try:
                # host may be a hostname; CrowdStrike needs device_id
                # Try to resolve via search first
                device_id = await _resolve_cs_device_id(cs_connector, host)
                if device_id:
                    success = await cs_connector.contain_host(device_id)
                    logger.info("CrowdStrike isolation %s for host=%s device_id=%s",
                                "OK" if success else "FAILED", host, device_id)
                else:
                    logger.warning("Could not resolve CrowdStrike device_id for host=%s", host)
            except Exception as exc:
                logger.error("CrowdStrike isolation error for %s: %s", host, exc)
    return handler


async def _resolve_cs_device_id(cs_connector, hostname: str) -> str | None:
    """Search CrowdStrike for a device by hostname and return its device_id."""
    try:
        resp = await cs_connector._request(
            "GET", "/devices/queries/devices/v1",
            params={"filter": f"hostname:'{hostname}'", "limit": 1},
        )
        ids = resp.get("resources", [])
        return ids[0] if ids else None
    except Exception:
        return None


def _isolate_sentinelone(cfg: dict):
    async def handler(alert, params: dict):
        base_url = cfg.get("management_url") or cfg.get("base_url")
        api_key  = cfg.get("api_key")
        if not base_url or not api_key:
            logger.warning("isolate_host_sentinelone: not configured")
            return

        hosts = getattr(alert, "affected_hosts", []) or []
        for host in hosts[:5]:
            try:
                # Find agent by hostname
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        f"{base_url}/web/api/v2.1/agents",
                        params={"computerName": host, "limit": 1},
                        headers={"Authorization": f"ApiToken {api_key}"},
                        timeout=aiohttp.ClientTimeout(total=10),
                    ) as resp:
                        data = await resp.json()
                        agents = data.get("data", [])

                    if not agents:
                        logger.warning("SentinelOne: agent not found for host=%s", host)
                        continue

                    agent_id = agents[0]["id"]
                    async with session.post(
                        f"{base_url}/web/api/v2.1/agents/actions/disconnect",
                        json={"filter": {"ids": [agent_id]}},
                        headers={"Authorization": f"ApiToken {api_key}",
                                 "Content-Type": "application/json"},
                        timeout=aiohttp.ClientTimeout(total=10),
                    ) as resp:
                        logger.info("SentinelOne isolation %s for host=%s",
                                    "OK" if resp.status == 200 else "FAILED", host)
            except Exception as exc:
                logger.error("SentinelOne isolation error for %s: %s", host, exc)
    return handler


# ---------------------------------------------------------------------------
# Network / Firewall
# ---------------------------------------------------------------------------

def _block_ip(fw_cfg: dict, connectors: dict):
    async def handler(alert, params: dict):
        iocs      = getattr(alert, "iocs", []) or []
        ip_iocs   = [i for i in iocs if _looks_like_ip(i)]
        if not ip_iocs:
            return

        direction = params.get("direction", "both")
        comment   = params.get("comment", f"SOAR block — alert {getattr(alert, 'alert_id', '')}")
        duration  = params.get("duration_hours", 24)

        # 1. Push to Sentinel watchlist (most universal approach)
        sentinel = connectors.get("microsoft_sentinel")
        if sentinel:
            for ip in ip_iocs[:20]:
                try:
                    await sentinel.query_watchlist("BlockedIPs", "IPAddress", ip)
                except Exception:
                    pass

        # 2. Push IOCs to CrowdStrike (blocks at endpoint level)
        cs = connectors.get("crowdstrike_falcon")
        if cs:
            ioc_list = [{"type": "ipv4", "value": ip, "action": "prevent",
                         "severity": "HIGH", "comment": comment}
                        for ip in ip_iocs[:20]]
            try:
                await cs.bulk_upload_iocs(ioc_list)
                logger.info("CrowdStrike: blocked %d IPs", len(ioc_list))
            except Exception as exc:
                logger.warning("CrowdStrike IP block failed: %s", exc)

        # 3. Call custom firewall API if configured
        api_url = fw_cfg.get("api_url")
        api_key = fw_cfg.get("api_key")
        if api_url and api_key:
            payload = {
                "ips":       ip_iocs,
                "direction": direction,
                "comment":   comment,
                "ttl_hours": duration,
            }
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{api_url}/block",
                    json=payload,
                    headers={"Authorization": f"Bearer {api_key}"},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    logger.info("Firewall API: block %d IPs — status=%d", len(ip_iocs), resp.status)

        logger.info("IP block action completed: %d IPs, direction=%s", len(ip_iocs), direction)
    return handler


# ---------------------------------------------------------------------------
# Identity
# ---------------------------------------------------------------------------

def _revoke_sessions(sentinel_connector, config: dict):
    async def handler(alert, params: dict):
        users = getattr(alert, "affected_users", []) or []
        if not users:
            return

        # Revoke via Microsoft Graph API (Azure AD)
        graph_cfg = config.get("connectors", {}).get("sentinel", {})
        tenant_id = graph_cfg.get("tenant_id")
        client_id = graph_cfg.get("client_id")
        client_secret = graph_cfg.get("client_secret")

        if not all([tenant_id, client_id, client_secret]):
            logger.warning("revoke_user_sessions: Azure AD credentials not available")
            return

        # Get Graph token
        token = await _get_graph_token(tenant_id, client_id, client_secret)
        if not token:
            return

        revoke_refresh = params.get("revoke_refresh_tokens", True)
        for user in users[:10]:
            try:
                async with aiohttp.ClientSession() as session:
                    # Revoke all refresh tokens
                    if revoke_refresh:
                        async with session.post(
                            f"https://graph.microsoft.com/v1.0/users/{user}/revokeSignInSessions",
                            headers={"Authorization": f"Bearer {token}"},
                            timeout=aiohttp.ClientTimeout(total=10),
                        ) as resp:
                            logger.info("Session revoke for user=%s status=%d", user, resp.status)
            except Exception as exc:
                logger.error("Session revoke failed for %s: %s", user, exc)
    return handler


def _disable_account(config: dict):
    async def handler(alert, params: dict):
        users = getattr(alert, "affected_users", []) or []
        if not users:
            return

        graph_cfg = config.get("connectors", {}).get("sentinel", {})
        token = await _get_graph_token(
            graph_cfg.get("tenant_id"),
            graph_cfg.get("client_id"),
            graph_cfg.get("client_secret"),
        )
        if not token:
            logger.warning("disable_user_account: could not obtain Graph token")
            return

        for user in users[:5]:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.patch(
                        f"https://graph.microsoft.com/v1.0/users/{user}",
                        json={"accountEnabled": False},
                        headers={"Authorization": f"Bearer {token}",
                                 "Content-Type": "application/json"},
                        timeout=aiohttp.ClientTimeout(total=10),
                    ) as resp:
                        logger.info("Account disable for user=%s status=%d", user, resp.status)
            except Exception as exc:
                logger.error("Account disable failed for %s: %s", user, exc)
    return handler


def _reset_mfa(config: dict):
    async def handler(alert, params: dict):
        users = getattr(alert, "affected_users", []) or []
        if not users:
            return

        graph_cfg = config.get("connectors", {}).get("sentinel", {})
        token = await _get_graph_token(
            graph_cfg.get("tenant_id"),
            graph_cfg.get("client_id"),
            graph_cfg.get("client_secret"),
        )
        if not token:
            logger.warning("reset_user_mfa: could not obtain Graph token")
            return

        for user in users[:5]:
            try:
                async with aiohttp.ClientSession() as session:
                    # Delete all FIDO2 methods and TOTP — forces re-enroll
                    async with session.delete(
                        f"https://graph.microsoft.com/v1.0/users/{user}"
                        f"/authentication/methods",
                        headers={"Authorization": f"Bearer {token}"},
                        timeout=aiohttp.ClientTimeout(total=10),
                    ) as resp:
                        logger.info("MFA reset for user=%s status=%d", user, resp.status)
            except Exception as exc:
                logger.error("MFA reset failed for %s: %s", user, exc)
    return handler


# ---------------------------------------------------------------------------
# Email security
# ---------------------------------------------------------------------------

def _block_email_sender(config: dict):
    async def handler(alert, params: dict):
        # Block via Exchange Online (Graph API)
        iocs    = getattr(alert, "iocs", []) or []
        domains = [i for i in iocs if "." in i and not _looks_like_ip(i) and "/" not in i]
        if not domains:
            return

        graph_cfg = config.get("connectors", {}).get("sentinel", {})
        token = await _get_graph_token(
            graph_cfg.get("tenant_id"),
            graph_cfg.get("client_id"),
            graph_cfg.get("client_secret"),
        )
        if not token:
            logger.warning("block_email_sender: could not obtain Graph token")
            return

        scope = params.get("scope", "tenant")
        for domain in domains[:10]:
            logger.info("Email sender block: domain=%s scope=%s", domain, scope)
            # Actual implementation: POST to Security & Compliance tenant block list
            # Requires Exchange.ManageAsApp permission
    return handler


def _quarantine_email(config: dict):
    async def handler(alert, params: dict):
        reason = params.get("reason", "phishing")
        logger.info("Email quarantine triggered: alert_id=%s reason=%s",
                    getattr(alert, "alert_id", ""), reason)
        # Actual implementation: Microsoft Defender for Office 365 Graph API
        # POST /security/threatSubmissions/emailThreats
    return handler


# ---------------------------------------------------------------------------
# SOAR platform actions
# ---------------------------------------------------------------------------

def _run_sentinel_playbook(sentinel_connector):
    async def handler(alert, params: dict):
        if not sentinel_connector:
            logger.warning("run_sentinel_playbook: Sentinel connector not available")
            return
        playbook_name = params.get("playbook_name")
        if not playbook_name:
            return
        try:
            # Create incident first if no ARM ID available
            result = await sentinel_connector.create_incident(
                {"alert_id": getattr(alert, "alert_id", ""),
                 "title":    getattr(alert, "title", ""),
                 "severity": getattr(alert, "severity", "low"),
                 "description": getattr(alert, "description", ""),
                 "ml_risk_score": getattr(alert, "ml_risk_score", 0)}
            )
            incident_id = result.get("name", "")
            if incident_id:
                await sentinel_connector.trigger_playbook(playbook_name, incident_id)
                logger.info("Sentinel playbook '%s' triggered", playbook_name)
        except Exception as exc:
            logger.error("run_sentinel_playbook failed: %s", exc)
    return handler


def _run_xsoar_playbook(xsoar_connector):
    async def handler(alert, params: dict):
        if not xsoar_connector:
            logger.warning("run_xsoar_playbook: Cortex XSOAR connector not available")
            return
        playbook_name = params.get("playbook_name")
        if not playbook_name:
            return
        try:
            result = await xsoar_connector.create_incident(
                {"alert_id": getattr(alert, "alert_id", ""),
                 "title":    getattr(alert, "title", ""),
                 "severity": getattr(alert, "severity", "low"),
                 "description": getattr(alert, "description", ""),
                 "ml_risk_score": getattr(alert, "ml_risk_score", 0)}
            )
            incident_id = result.get("id")
            if incident_id:
                await xsoar_connector.run_playbook(str(incident_id), playbook_name)
        except Exception as exc:
            logger.error("run_xsoar_playbook failed: %s", exc)
    return handler


# ---------------------------------------------------------------------------
# Threat intelligence enrichment
# ---------------------------------------------------------------------------

def _enrich_virustotal(cfg: dict):
    async def handler(alert, params: dict):
        api_key = cfg.get("api_key")
        if not api_key or not cfg.get("enabled"):
            return

        iocs      = getattr(alert, "iocs", []) or []
        ioc_types = params.get("ioc_types", ["ip", "domain", "sha256"])
        enriched  = {}

        async with aiohttp.ClientSession() as session:
            for ioc in iocs[:10]:        # VirusTotal free tier: 4 req/min
                vt_type = _vt_ioc_type(ioc)
                if vt_type not in ioc_types:
                    continue
                try:
                    url = f"https://www.virustotal.com/api/v3/{vt_type}s/{ioc}"
                    async with session.get(
                        url,
                        headers={"x-apikey": api_key},
                        timeout=aiohttp.ClientTimeout(total=15),
                    ) as resp:
                        if resp.status == 200:
                            data  = await resp.json()
                            stats = data.get("data", {}).get("attributes", {}).get(
                                "last_analysis_stats", {})
                            malicious = stats.get("malicious", 0)
                            enriched[ioc] = {
                                "malicious": malicious,
                                "suspicious": stats.get("suspicious", 0),
                                "verdict": "malicious" if malicious > 3 else
                                           "suspicious" if malicious > 0 else "clean",
                            }
                        await asyncio.sleep(0.25)   # rate limit
                except Exception as exc:
                    logger.debug("VT enrich failed for %s: %s", ioc, exc)

        if enriched:
            existing = getattr(alert, "enrichments", {}) or {}
            existing["virustotal"] = enriched
            malicious_count = sum(1 for v in enriched.values() if v.get("verdict") == "malicious")
            existing.setdefault("threat_intel", {})["malicious_count"] = malicious_count
            object.__setattr__(alert, "enrichments", existing) if hasattr(alert, "__dataclass_fields__") \
                else setattr(alert, "enrichments", existing)
            logger.info("VirusTotal: enriched %d IOCs, %d malicious", len(enriched), malicious_count)
    return handler


def _enrich_misp(cfg: dict):
    async def handler(alert, params: dict):
        misp_url = cfg.get("url")
        api_key  = cfg.get("api_key")
        if not misp_url or not api_key or not cfg.get("enabled"):
            return

        iocs = getattr(alert, "iocs", []) or []
        if not iocs:
            return

        payload = {
            "returnFormat": "json",
            "value":        iocs[:20],
            "limit":        100,
        }
        if params.get("include_related"):
            payload["includeContext"] = True

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{misp_url}/attributes/restSearch",
                    json=payload,
                    headers={"Authorization": api_key, "Accept": "application/json",
                             "Content-Type": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=15),
                    ssl=False,
                ) as resp:
                    if resp.status == 200:
                        data  = await resp.json()
                        attrs = data.get("response", {}).get("Attribute", [])
                        logger.info("MISP: %d matching attributes for %d IOCs",
                                    len(attrs), len(iocs))
                    else:
                        logger.warning("MISP enrich failed: %d", resp.status)
        except Exception as exc:
            logger.warning("MISP enrichment error: %s", exc)
    return handler


# ---------------------------------------------------------------------------
# Asset management
# ---------------------------------------------------------------------------

def _update_watchlist(sentinel_connector):
    async def handler(alert, params: dict):
        if not sentinel_connector:
            logger.warning("update_watchlist: Sentinel connector not available")
            return

        watchlist = params.get("watchlist", "HighValueIOCs")
        field_name= params.get("field", "indicator")
        ioc_types = params.get("ioc_types")

        iocs = getattr(alert, "iocs", []) or []
        hosts= getattr(alert, "affected_hosts", []) or []

        items = iocs if iocs else hosts
        if ioc_types:
            items = _filter_iocs_by_type(items, ioc_types)

        for item in items[:20]:
            try:
                await sentinel_connector.query_watchlist(watchlist, field_name, item)
            except Exception as exc:
                logger.debug("Watchlist update for %s: %s", item, exc)

        logger.info("Watchlist '%s' updated with %d items", watchlist, len(items[:20]))
    return handler


def _tag_asset(cfg: dict):
    async def handler(alert, params: dict):
        tag      = params.get("tag", "HIGH_RISK")
        ttl_h    = params.get("ttl_hours", 24)
        hosts    = getattr(alert, "affected_hosts", []) or []
        alert_id = getattr(alert, "alert_id", "")

        for host in hosts[:10]:
            logger.info("Asset tag: host=%s tag=%s ttl_hours=%d alert_id=%s",
                        host, tag, ttl_h, alert_id)
        # Production implementation: POST to CMDB / Azure Resource Graph tags
    return handler


# ---------------------------------------------------------------------------
# Forensics
# ---------------------------------------------------------------------------

def _collect_memory_dump(cs_connector):
    async def handler(alert, params: dict):
        if not cs_connector:
            logger.warning("collect_memory_dump: CrowdStrike connector not available")
            return
        hosts = getattr(alert, "affected_hosts", []) or []
        for host in hosts[:2]:      # memory dumps are expensive — cap at 2
            logger.info("Memory dump initiated for host=%s via CrowdStrike RTR", host)
            # Production: CrowdStrike Real-Time Response batch init + memdump command
    return handler


def _snapshot_host(config: dict):
    async def handler(alert, params: dict):
        hosts = getattr(alert, "affected_hosts", []) or []
        dest  = params.get("upload_to", "azure_blob")
        for host in hosts[:2]:
            logger.info("Disk snapshot initiated: host=%s destination=%s", host, dest)
        # Production: Azure VM snapshot API / AWS CreateSnapshot
    return handler


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------

def _close_alert(connectors: dict):
    async def handler(alert, params: dict):
        reason   = params.get("reason", "auto_closed")
        alert_id = getattr(alert, "alert_id", "")
        source   = getattr(alert, "source", "")

        xsoar = connectors.get("cortex_xsoar")
        if xsoar and source == "cortex_xsoar":
            try:
                await xsoar.close_incident(alert_id, close_reason=reason)
                logger.info("XSOAR incident %s closed: %s", alert_id, reason)
            except Exception as exc:
                logger.warning("XSOAR close failed: %s", exc)
        else:
            logger.info("Alert close: alert_id=%s reason=%s", alert_id, reason)
    return handler


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _interpolate(template: str, alert) -> str:
    """Replace {{ field_name }} tokens in a string with alert attribute values."""
    import re
    def replacer(m):
        field = m.group(1).strip()
        val   = getattr(alert, field, None)
        if isinstance(val, list):
            return val[0] if val else ""
        return str(val) if val is not None else ""
    return re.sub(r"\{\{\s*(\w+)\s*\}\}", replacer, template)


def _slack_color(severity: str) -> str:
    return {"critical": "#FF0000", "high": "#FF6600",
            "medium": "#FFCC00", "low": "#00CC00", "info": "#808080"}.get(severity, "#808080")


def _alert_summary_text(alert) -> str:
    return (
        f"Alert ID:      {getattr(alert, 'alert_id', '')}\n"
        f"Source:        {getattr(alert, 'source', '')}\n"
        f"Severity:      {getattr(alert, 'severity', '')}\n"
        f"Risk Score:    {getattr(alert, 'ml_risk_score', 0):.4f}\n"
        f"MITRE Tactics: {', '.join(getattr(alert, 'mitre_tactics', []) or [])}\n"
        f"Affected Hosts:{', '.join(getattr(alert, 'affected_hosts', []) or [])}\n"
        f"Affected Users:{', '.join(getattr(alert, 'affected_users', []) or [])}\n"
        f"IOC Count:     {len(getattr(alert, 'iocs', []) or [])}\n"
        f"Timestamp:     {getattr(alert, 'timestamp', '')}\n\n"
        f"{getattr(alert, 'description', '')}"
    )


def _render_email_template(template: str, alert, params: dict) -> tuple[str, str]:
    title   = getattr(alert, "title", "Security Alert")
    sev     = getattr(alert, "severity", "").upper()
    summary = _alert_summary_text(alert)

    subjects = {
        "phishing_user_warning":    f"[SECURITY ALERT] Phishing attempt detected — action required",
        "brute_force_user_alert":   f"[SECURITY ALERT] Unusual sign-in activity on your account",
        "account_security_alert":   f"[SECURITY ALERT] Your account requires immediate attention",
        "generic_alert":            f"[SECURITY ALERT] {sev}: {title}",
    }
    subject = subjects.get(template, f"[SECURITY ALERT] {sev}: {title}")
    body    = f"<pre>{summary}</pre>"
    return subject, body


async def _get_graph_token(tenant_id: str, client_id: str, client_secret: str) -> str | None:
    if not all([tenant_id, client_id, client_secret]):
        return None
    try:
        url  = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
        data = {
            "grant_type":    "client_credentials",
            "client_id":     client_id,
            "client_secret": client_secret,
            "scope":         "https://graph.microsoft.com/.default",
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=data, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                resp.raise_for_status()
                result = await resp.json()
                return result.get("access_token")
    except Exception as exc:
        logger.warning("Graph token fetch failed: %s", exc)
        return None


def _looks_like_ip(value: str) -> bool:
    import re
    return bool(re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", value))


def _vt_ioc_type(ioc: str) -> str:
    if _looks_like_ip(ioc):
        return "ip_address"
    if len(ioc) in (32, 40, 64) and all(c in "0123456789abcdefABCDEF" for c in ioc):
        return "file"
    if ioc.startswith("http"):
        return "url"
    return "domain"


def _filter_iocs_by_type(iocs: list[str], types: list[str]) -> list[str]:
    result = []
    for ioc in iocs:
        if "ip" in types and _looks_like_ip(ioc):
            result.append(ioc)
        elif any(t in types for t in ("sha256", "md5")) and len(ioc) in (32, 64):
            result.append(ioc)
        elif "domain" in types and "." in ioc and not _looks_like_ip(ioc):
            result.append(ioc)
        elif "url" in types and ioc.startswith("http"):
            result.append(ioc)
    return result
