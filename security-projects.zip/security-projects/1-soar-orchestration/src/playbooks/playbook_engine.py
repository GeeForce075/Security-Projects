"""
Playbook Engine
Loads YAML playbook definitions, selects the best-matching playbook for each
normalized alert, and executes the defined action sequence asynchronously.
"""

import asyncio
import logging
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import yaml

logger = logging.getLogger("soar.playbooks.engine")


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class PlaybookAction:
    name:       str
    action:     str                         # e.g. "notify_slack", "isolate_host"
    params:     dict       = field(default_factory=dict)
    condition:  str | None = None           # Python-safe expression evaluated at runtime
    on_failure: str        = "continue"     # "continue" | "abort"
    timeout_s:  int        = 30


@dataclass
class Playbook:
    id:          str
    name:        str
    description: str
    triggers:    list[dict]                 # Matching rules
    actions:     list[PlaybookAction]
    severity:    list[str] = field(default_factory=list)
    priority:    int       = 50             # Lower = higher priority when multiple match
    enabled:     bool      = True


@dataclass
class PlaybookResult:
    playbook_id:    str
    alert_id:       str
    started_at:     float
    completed_at:   float    = 0.0
    actions_run:    list[str] = field(default_factory=list)
    actions_failed: list[str] = field(default_factory=list)
    aborted:        bool     = False
    error:          str      = ""


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class PlaybookEngine:
    """
    Loads playbooks from YAML definitions and provides:
      - select_playbook(alert)  → best-matching playbook ID
      - execute(alert)          → runs matched playbook actions
    """

    def __init__(self, playbook_dir: str = "playbooks/definitions"):
        self._dir      = Path(playbook_dir)
        self._playbooks: dict[str, Playbook] = {}
        # Registry of handler callables; keyed by action name
        self._handlers: dict[str, Callable] = {}
        self._load_all()
        self._register_builtin_handlers()

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def _load_all(self):
        if not self._dir.exists():
            logger.warning("Playbook directory not found: %s", self._dir)
            return

        loaded = 0
        for path in sorted(self._dir.glob("*.yaml")) + sorted(self._dir.glob("*.yml")):
            try:
                self._load_file(path)
                loaded += 1
            except Exception as exc:
                logger.error("Failed to load playbook %s: %s", path.name, exc)

        logger.info("Playbook engine: loaded %d playbooks from %s", loaded, self._dir)

    def _load_file(self, path: Path):
        with open(path) as f:
            raw = yaml.safe_load(f)

        if not isinstance(raw, dict):
            raise ValueError(f"Playbook file must be a YAML mapping: {path.name}")

        actions = [
            PlaybookAction(
                name       = a["name"],
                action     = a["action"],
                params     = a.get("params", {}),
                condition  = a.get("condition"),
                on_failure = a.get("on_failure", "continue"),
                timeout_s  = a.get("timeout_s", 30),
            )
            for a in raw.get("actions", [])
        ]

        pb = Playbook(
            id          = raw["id"],
            name        = raw.get("name", raw["id"]),
            description = raw.get("description", ""),
            triggers    = raw.get("triggers", []),
            actions     = actions,
            severity    = raw.get("severity", []),
            priority    = raw.get("priority", 50),
            enabled     = raw.get("enabled", True),
        )
        self._playbooks[pb.id] = pb

    def reload(self):
        """Hot-reload all playbook definitions from disk."""
        self._playbooks.clear()
        self._load_all()

    # ------------------------------------------------------------------
    # Selection
    # ------------------------------------------------------------------

    def select_playbook(self, alert) -> str | None:
        """
        Return the ID of the highest-priority matching playbook, or None.
        Matching is evaluated in priority order (lowest number wins).
        """
        candidates = sorted(
            [pb for pb in self._playbooks.values() if pb.enabled],
            key=lambda p: p.priority,
        )

        for pb in candidates:
            if self._matches(pb, alert):
                logger.debug("Playbook selected: '%s' for alert [%s]",
                             pb.id, getattr(alert, "alert_id", "?"))
                return pb.id

        logger.debug("No matching playbook for alert [%s]", getattr(alert, "alert_id", "?"))
        return None

    def _matches(self, pb: Playbook, alert) -> bool:
        """Evaluate all trigger conditions; return True if any trigger fires."""
        # Severity gate: if the playbook specifies severities it only applies to those
        if pb.severity:
            if getattr(alert, "severity", "low") not in pb.severity:
                return False

        if not pb.triggers:
            return True  # No trigger constraints — matches everything

        for trigger in pb.triggers:
            if self._evaluate_trigger(trigger, alert):
                return True
        return False

    def _evaluate_trigger(self, trigger: dict, alert) -> bool:
        """
        A trigger is a dict with one or more of:
          - severity: [list of severities]
          - title_contains: "string" or [list of strings]  (case-insensitive)
          - source: "platform" or [list of platforms]
          - mitre_tactic: "TA0008" or [list of tactic IDs]
          - min_score: float
          - ioc_count_gte: int
        All specified keys must match (AND logic within a trigger).
        """
        title_lower = (getattr(alert, "title", "") + " " + getattr(alert, "description", "")).lower()
        severity    = getattr(alert, "severity", "low")
        source      = getattr(alert, "source", "")
        tactics     = set(getattr(alert, "mitre_tactics", []) or [])
        score       = getattr(alert, "ml_risk_score", 0.0)
        ioc_count   = len(getattr(alert, "iocs", []) or [])

        for key, value in trigger.items():
            if key == "severity":
                vals = [value] if isinstance(value, str) else value
                if severity not in vals:
                    return False

            elif key == "title_contains":
                patterns = [value] if isinstance(value, str) else value
                if not any(p.lower() in title_lower for p in patterns):
                    return False

            elif key == "source":
                vals = [value] if isinstance(value, str) else value
                if source not in vals:
                    return False

            elif key == "mitre_tactic":
                required = {value} if isinstance(value, str) else set(value)
                if not (required & tactics):
                    return False

            elif key == "min_score":
                if score < float(value):
                    return False

            elif key == "ioc_count_gte":
                if ioc_count < int(value):
                    return False

        return True

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    async def execute(self, alert) -> PlaybookResult | None:
        """
        Execute the playbook matched to the alert.
        Returns a PlaybookResult or None if no playbook is matched.
        """
        pb_id = getattr(alert, "playbook_id", None)
        if not pb_id:
            return None

        pb = self._playbooks.get(pb_id)
        if not pb:
            logger.warning("Playbook '%s' referenced but not found", pb_id)
            return None

        result = PlaybookResult(
            playbook_id = pb.id,
            alert_id    = getattr(alert, "alert_id", ""),
            started_at  = time.monotonic(),
        )

        logger.info("Executing playbook '%s' for alert [%s]", pb.id, result.alert_id)

        for action in pb.actions:
            # Evaluate optional condition
            if action.condition and not self._eval_condition(action.condition, alert):
                logger.debug("  Skipping action '%s' (condition false)", action.name)
                continue

            try:
                await asyncio.wait_for(
                    self._run_action(action, alert),
                    timeout=action.timeout_s,
                )
                result.actions_run.append(action.name)
                logger.debug("  Action '%s' — OK", action.name)

            except asyncio.TimeoutError:
                msg = f"Action '{action.name}' timed out after {action.timeout_s}s"
                logger.warning("  %s", msg)
                result.actions_failed.append(action.name)
                if action.on_failure == "abort":
                    result.aborted = True
                    result.error   = msg
                    break

            except Exception as exc:
                logger.error("  Action '%s' failed: %s", action.name, exc)
                result.actions_failed.append(action.name)
                if action.on_failure == "abort":
                    result.aborted = True
                    result.error   = str(exc)
                    break

        result.completed_at = time.monotonic()
        elapsed = result.completed_at - result.started_at
        logger.info(
            "Playbook '%s' done — %d OK / %d failed / %.2fs%s",
            pb.id,
            len(result.actions_run),
            len(result.actions_failed),
            elapsed,
            " [ABORTED]" if result.aborted else "",
        )
        return result

    async def _run_action(self, action: PlaybookAction, alert):
        """Dispatch to the registered handler for this action type."""
        handler = self._handlers.get(action.action)
        if not handler:
            logger.warning("No handler registered for action '%s' — skipping", action.action)
            return
        if asyncio.iscoroutinefunction(handler):
            await handler(alert, action.params)
        else:
            handler(alert, action.params)

    def _eval_condition(self, condition: str, alert) -> bool:
        """
        Evaluate a simple condition expression against the alert object.
        Supported variables: severity, score, ioc_count, source, tactics
        Example: "score >= 0.75 and 'TA0010' in tactics"
        """
        try:
            ctx = {
                "severity":  getattr(alert, "severity", "low"),
                "score":     getattr(alert, "ml_risk_score", 0.0),
                "ioc_count": len(getattr(alert, "iocs", []) or []),
                "source":    getattr(alert, "source", ""),
                "tactics":   getattr(alert, "mitre_tactics", []) or [],
            }
            return bool(eval(condition, {"__builtins__": {}}, ctx))  # noqa: S307
        except Exception as exc:
            logger.warning("Condition eval failed ('%s'): %s — defaulting to True", condition, exc)
            return True

    # ------------------------------------------------------------------
    # Built-in action handlers
    # ------------------------------------------------------------------

    def _register_builtin_handlers(self):
        """Register no-op stubs for built-in action types. Override in production."""
        builtins = [
            "log_alert",
            "send_email",
            "notify_slack",
            "notify_teams",
            "notify_pagerduty",
            "create_ticket_jira",
            "create_ticket_servicenow",
            "isolate_host_crowdstrike",
            "isolate_host_sentinelone",
            "block_ip_firewall",
            "revoke_user_sessions",
            "disable_user_account",
            "reset_user_mfa",
            "block_email_sender",
            "quarantine_email",
            "run_sentinel_playbook",
            "run_xsoar_playbook",
            "enrich_virustotal",
            "enrich_misp",
            "snapshot_host",
            "collect_memory_dump",
            "tag_asset_high_risk",
            "update_watchlist",
            "close_alert",
        ]
        for name in builtins:
            if name not in self._handlers:
                self._handlers[name] = self._make_stub(name)

    @staticmethod
    def _make_stub(action_name: str):
        async def _stub(alert, params: dict):
            logger.info(
                "    [%s] alert_id=%s params=%s",
                action_name,
                getattr(alert, "alert_id", "?"),
                params,
            )
        return _stub

    # ------------------------------------------------------------------
    # Handler registration (for production wiring)
    # ------------------------------------------------------------------

    def register_handler(self, action_name: str, handler: Callable):
        """Register a callable for a given action type."""
        self._handlers[action_name] = handler
        logger.debug("Playbook engine: handler registered for '%s'", action_name)

    def list_playbooks(self) -> list[dict]:
        return [
            {
                "id":       pb.id,
                "name":     pb.name,
                "enabled":  pb.enabled,
                "priority": pb.priority,
                "severity": pb.severity,
                "trigger_count": len(pb.triggers),
                "action_count":  len(pb.actions),
            }
            for pb in sorted(self._playbooks.values(), key=lambda p: p.priority)
        ]
